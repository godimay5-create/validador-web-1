// Validador Tributário — versão web. Telas em JavaScript; cálculos no MESMO Python do programa desktop
// (rodando no navegador pelo Pyodide, dentro de motor-worker.js). Dados: Supabase (carteira + simples_dados).
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';
import { CONFIG } from './config.js';

const sb = createClient(CONFIG.url, CONFIG.chave, { auth: { persistSession: true, autoRefreshToken: true } });
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];

// ------------------------------------------------------------------ motor (worker com Pyodide)
const worker = new Worker('/js/motor-worker.js');
let seq = 0;
const esperando = new Map();
worker.onmessage = (ev) => {
  const d = ev.data;
  if (d.tipo === 'progresso') return setCarga(d.txt);
  if (d.tipo === 'cfg') { try { localStorage.setItem('vt_cfg', d.cfg); } catch (_) {} return; }
  const p = esperando.get(d.id);
  if (!p) return;
  esperando.delete(d.id);
  d.ok ? p.res(d.valor) : p.rej(new Error(d.erro));
};
function chamar(fn, ...args) {
  return new Promise((res, rej) => {
    const id = ++seq;
    esperando.set(id, { res, rej });
    worker.postMessage({ id, fn, args, versao: CONFIG.versao });
  });
}
async function M(fn, ...args) {
  const v = await chamar(fn, ...args);
  return v == null ? null : JSON.parse(v);
}
const motorPronto = chamar('__iniciar');

// ------------------------------------------------------------------ utilidades
const nf = new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmt = (v) => (v == null || v === '' ? '—' : nf.format(v));
const brl = (v) => (v == null ? '—' : 'R$ ' + nf.format(v));
const pct = (v, d = 1) => (v == null ? '—' : (v * 100).toFixed(d).replace('.', ',') + '%');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const PONTO = { erro: '#ef4444', alterada: '#ef4444', revisao: '#f59e0b', pronta: '#3b82f6', nao: '#cbd5e1', validada: '#10b981', ressalva: '#10b981', fora: '#e2e8f0' };
const CLS = { erro: 'erro', alterada: 'erro', revisao: 'atencao', pronta: 'info', validada: 'ok', ressalva: 'ok' };
const REG = { SN: 'Simples', LP: 'Presumido', OUTRO: 'Outro' };
const mesAdd = (c, n) => { const [a, m] = c.split('-').map(Number); const d = new Date(a, m - 1 + n, 1); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; };
const MESES = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
const nomeMes = (c) => { const [a, m] = c.split('-'); return `${MESES[+m - 1]}/${a}`; };

function setCarga(txt) { const el = $('#carga-txt'); if (el) el.textContent = txt; }
let tToast;
function avisar(txt, ms = 3500) {
  const t = $('#toast');
  t.textContent = txt; t.hidden = false;
  clearTimeout(tToast); tToast = setTimeout(() => (t.hidden = true), ms);
}
function modal(html, aoAbrir) {
  $('#modal').innerHTML = html;
  $('#modal-fundo').hidden = false;
  aoAbrir && aoAbrir($('#modal'));
}
const fecharModal = () => ($('#modal-fundo').hidden = true);
$('#modal-fundo').addEventListener('click', (e) => { if (e.target.id === 'modal-fundo') fecharModal(); });

// ------------------------------------------------------------------ estado da tela (preferências ficam neste navegador)
const P = (() => { try { return JSON.parse(localStorage.getItem('vt_ui') || '{}'); } catch (_) { return {}; } })();
const UI = {
  filtro: P.filtro || 'sel', busca: '', ordem: P.ordem || { c: 'ordem', dir: 1 }, atual: null, aba: P.aba || 'resumo', etapa: 1,
  tabelaAberta: !!P.tabelaAberta, alturaMestre: P.alturaMestre || null, fs: P.fs || 15, emp: null, linhas: [],
};
const gravarUI = () => { try { localStorage.setItem('vt_ui', JSON.stringify({ filtro: UI.filtro, ordem: UI.ordem, aba: UI.aba, tabelaAberta: UI.tabelaAberta, alturaMestre: UI.alturaMestre, fs: UI.fs })); } catch (_) {} };
document.documentElement.style.setProperty('--fs', UI.fs + 'px');

// ------------------------------------------------------------------ Supabase: leitura paginada
async function lerTudo(tabela, colunas, ordem, lote) {
  const out = [];
  for (let i = 0; ; i += lote) {
    const { data, error } = await sb.from(tabela).select(colunas).order(ordem).range(i, i + lote - 1);
    if (error) throw new Error(traduz(error.message, tabela));
    out.push(...data);
    if (data.length < lote) return out;
  }
}
function traduz(m, tabela) {
  if (/Invalid login credentials/.test(m)) return 'E-mail ou senha não conferem (usuário de Authentication → Users do Supabase).';
  if (/Email not confirmed/.test(m)) return 'Este e-mail ainda não foi confirmado no Supabase.';
  if (/JWT expired/.test(m)) return 'A sessão expirou. Entre de novo.';
  if (/does not exist|Could not find the table/.test(m)) return `A tabela "${tabela}" não existe no banco.`;
  if (/permission denied|row-level security/.test(m)) return 'Sem permissão no banco: confira se está logado e as políticas do seguranca_supabase.sql.';
  return m;
}

// ------------------------------------------------------------------ envio para a nuvem (mesmo formato do .exe)
let tEnvio = null, enviando = false, sujo = false;
function setNuvem(st, det = '') {
  const b = $('#bt-nuvem');
  b.className = 'nuvem ' + st;
  $('#nuvem-txt').textContent = { ok: 'Salvo na nuvem', salvando: 'Salvando…', pendente: 'Alterações pendentes', erro: 'Erro ao salvar' }[st] || st;
  b.title = det || 'Sincronização com a nuvem (simples_dados)';
}
function marcarSujo() {
  sujo = true; setNuvem('pendente');
  clearTimeout(tEnvio); tEnvio = setTimeout(enviar, 1200);
}
async function enviar() {
  if (enviando) { clearTimeout(tEnvio); tEnvio = setTimeout(enviar, 800); return; }
  enviando = true;
  let pac = null;
  try {
    pac = await M('pacote');
    sujo = false;
    if (!pac || (!pac.sobe.length && !pac.apaga.length)) { setNuvem('ok'); return; }
    setNuvem('salvando');
    let i = 0;
    while (i < pac.sobe.length) {
      const lote = []; let t = 0;
      while (i < pac.sobe.length && (!lote.length || t + pac.sobe[i].txt.length < 1.5e6)) {
        const x = pac.sobe[i++]; t += x.txt.length;
        lote.push({ chave: x.chave, dados: JSON.parse(x.txt), atualizado_em: x.atualizado_em });
      }
      const { error } = await sb.from(CONFIG.tabelaNuvem).upsert(lote, { onConflict: 'chave' });
      if (error) throw new Error(traduz(error.message, CONFIG.tabelaNuvem));
    }
    if (pac.apaga.length) {
      const { error } = await sb.from(CONFIG.tabelaNuvem).delete().in('chave', pac.apaga);
      if (error) throw new Error(traduz(error.message, CONFIG.tabelaNuvem));
    }
    await M('confirmar', JSON.stringify({ sobe: pac.sobe.map((x) => [x.chave, x.h]), apaga: pac.apaga }));
    setNuvem(sujo ? 'pendente' : 'ok');
  } catch (e) {
    if (pac) await M('falhou', JSON.stringify(pac.cats));
    setNuvem('erro', String(e.message || e));
    avisar('Não salvou na nuvem: ' + (e.message || e) + ' — tento de novo em 20 s.', 6000);
    clearTimeout(tEnvio); tEnvio = setTimeout(enviar, 20000);
  } finally { enviando = false; }
}
window.addEventListener('beforeunload', (e) => {
  if ($('#bt-nuvem').classList.contains('pendente') || $('#bt-nuvem').classList.contains('salvando') || enviando) { e.preventDefault(); e.returnValue = ''; }
});
/** Executa uma ação que muda dados e, depois, envia para a nuvem e redesenha. */
async function mudar(fn, ...args) {
  const r = await M(fn, ...args);
  if (r && r.ok === false) { avisar(r.erro, 5000); return r; }
  marcarSujo();
  await redesenhar();
  return r;
}

// ------------------------------------------------------------------ início
async function abrir() {
  const { data: { session } } = await sb.auth.getSession();
  if (!session) return mostrarLogin();
  try { await carregar(session); } catch (e) {
    console.error(e);
    mostrarLogin(String(e.message || e));
  }
}
function mostrarLogin(erro) {
  $('#tela-carga').hidden = true; $('#app').hidden = true; $('#tela-login').hidden = false;
  const el = $('#lg-erro'); el.hidden = !erro; el.textContent = erro || '';
  $('#lg-email').focus();
}
$('#form-login').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const bt = $('#form-login button'); bt.disabled = true; bt.textContent = 'Entrando…';
  const { data, error } = await sb.auth.signInWithPassword({ email: $('#lg-email').value.trim(), password: $('#lg-senha').value });
  bt.disabled = false; bt.textContent = 'Entrar';
  if (error) return mostrarLogin(traduz(error.message));
  $('#tela-login').hidden = true; $('#tela-carga').hidden = false;
  try { await carregar(data.session); } catch (e) { mostrarLogin(String(e.message || e)); }
});

async function carregar(session) {
  $('#tela-login').hidden = true; $('#tela-carga').hidden = false;
  setCarga('Carregando o motor de cálculo…');
  await motorPronto;
  setCarga('Lendo a carteira de empresas…');
  const emp = await lerTudo(CONFIG.tabelaCarteira, '*', CONFIG.colNome, 1000);
  const r = await M('iniciar', localStorage.getItem('vt_cfg') || '{}', session.user.email, session.user.id);
  await M('definir_empresas', JSON.stringify(emp));
  setCarga('Baixando as apurações da nuvem…');
  const rows = await lerTudo(CONFIG.tabelaNuvem, 'chave,dados', 'chave', 200);
  setCarga('Calculando as empresas selecionadas…');
  await M('aplicar_nuvem', JSON.stringify(rows));
  $('#comp').value = r.comp;
  $('#menu-user').textContent = session.user.email;
  $('#tela-carga').hidden = true; $('#app').hidden = false;
  setNuvem('ok');
  aplicarLayout();
  await redesenhar();
}

// ------------------------------------------------------------------ desenho geral
async function redesenhar() {
  await desenharTabela();
  if (UI.atual) await desenharEmpresa();
  aplicarLayout();
}

function aplicarLayout() {
  const compacto = UI.atual && UI.aba === 'apuracao' && !UI.tabelaAberta;
  const m = $('#mestre');
  m.classList.toggle('compacto', !!compacto);
  $('#mestre-compacto').hidden = !compacto;
  $('#mestre-cheio').hidden = !!compacto;
  $('#divisor').hidden = !!compacto || !UI.atual;
  $('#bt-recolher').hidden = !(UI.atual && UI.aba === 'apuracao');
  $('#cab').hidden = !!compacto;
  if (!compacto) m.style.height = UI.atual ? (UI.alturaMestre || Math.round(window.innerHeight * 0.38)) + 'px' : 'auto';
  if (!UI.atual) { m.style.flex = '1 1 auto'; } else { m.style.flex = '0 0 auto'; }
  $('#detalhe').hidden = !UI.atual;
  $('#comp-rot').textContent = $('#comp').value ? nomeMes($('#comp').value) : '';
  $('#rot-tam').textContent = { 14: 'Normal', 15: 'Médio', 16.5: 'Grande', 18: 'Muito grande' }[UI.fs] || UI.fs;
}

// ------------------------------------------------------------------ tabela de empresas
const COLS_NUM = new Set(['rec', 'calc', 'decl', 'dif', 'fr', 'rbt', 'fx', 'ordem']);
async function desenharTabela() {
  const d = await M('tabela', UI.filtro, UI.busca);
  UI.linhas = d.linhas;
  $$('#chips button').forEach((b) => {
    b.classList.toggle('on', b.dataset.f === UI.filtro);
    b.textContent = { pend: 'Pendentes' + (d.n_pend ? ' ' + d.n_pend : ''), sel: 'Selecionadas ' + d.n_sel, todas: 'Todas ' + d.n_tot, sn: 'Simples', lp: 'Presumido' }[b.dataset.f];
  });
  const { c, dir } = UI.ordem;
  const L = [...d.linhas].sort((a, b) => {
    const x = a[c], y = b[c];
    if (x == null && y == null) return a.nome.localeCompare(b.nome);
    if (x == null) return 1; if (y == null) return -1;
    const r = COLS_NUM.has(c) ? x - y : String(x).localeCompare(String(y), 'pt-BR');
    return (r || a.nome.localeCompare(b.nome)) * dir;
  });
  UI.ordemIds = L.map((l) => l.id);
  $$('#tabela th').forEach((th) => th.classList.toggle('ord-asc', th.dataset.c === c && dir === 1) || th.classList.toggle('ord-desc', th.dataset.c === c && dir === -1));
  $$('#tabela th').forEach((th) => { th.classList.remove('ord-asc', 'ord-desc'); if (th.dataset.c === c) th.classList.add(dir === 1 ? 'ord-asc' : 'ord-desc'); });
  $('#tabela tbody').innerHTML = L.map((l) => {
    const difCls = l.dif == null ? '' : Math.abs(l.dif) >= 0.01 ? 'c-bad b' : 'c-ok';
    const frCls = l.fr != null && l.fr < 0.28 && l.reg === 'SN' ? 'c-warn' : '';
    const pCls = l.pend_sev === 'erro' ? 'c-bad' : l.pend_sev ? 'c-warn' : l.pend.startsWith('✓') ? 'c-ok' : '';
    return `<tr data-id="${l.id}" class="${l.id === UI.atual ? 'sel' : ''} ${l.na ? '' : 'fora'}">
      <td><span class="dot" style="background:${PONTO[l.cod] || PONTO.fora}"></span>${esc(l.sit)}</td>
      <td class="emp" title="${esc(l.razao)}\n${esc(l.cnpj)}">${esc(l.nome)}</td><td class="col-cnpj">${esc(l.cnpj)}</td>
      <td>${REG[l.reg] || esc(l.reg)}</td><td class="n">${fmt(l.rec)}</td><td class="n">${fmt(l.calc)}</td><td class="n">${fmt(l.decl)}</td>
      <td class="n ${difCls}">${fmt(l.dif)}</td><td class="n ${frCls}">${pct(l.fr)}</td><td class="n">${fmt(l.rbt)}</td>
      <td class="n">${l.fx ? l.fx + 'ª' : '—'}</td><td class="pend ${pCls}" title="${esc(l.pend)}">${esc(l.pend)}</td></tr>`;
  }).join('') || `<tr><td colspan="12" class="mut" style="padding:24px">${
    UI.filtro === 'sel' ? 'Nenhuma empresa selecionada: clique em "Todas" e escolha uma.' : UI.filtro === 'pend' ? 'Nenhuma pendência nas empresas selecionadas.' : 'Nenhuma empresa encontrada.'}</td></tr>`;
  const t = d.tot;
  $('#totais').innerHTML = L.length ? `<b>${L.length}</b> empresa(s) · Receita <b>${brl(t.rec)}</b> · Calculado <b>${brl(t.calc)}</b> · Declarado <b>${brl(t.decl)}</b> · Diferença <b class="${Math.abs(t.dif) >= 0.01 ? 'c-bad' : 'c-ok'}">${brl(t.dif)}</b>${d.n_div ? ` <span class="c-bad">(${d.n_div} com diferença)</span>` : ''} <span class="mut">· duplo clique abre a validação · F8 próxima pendente</span>` : '';
  const sel = $('#tabela tr.sel');
  if (sel) sel.scrollIntoView({ block: 'nearest' });
  desenharCompacto();
}
function desenharCompacto() {
  if (!UI.atual) return;
  const ids = UI.ordemIds || [];
  const i = ids.indexOf(UI.atual);
  const l = UI.linhas.find((x) => x.id === UI.atual);
  $('#c-info').innerHTML = l ? `<b>${esc(l.nome)}</b> &nbsp;<span class="dot" style="background:${PONTO[l.cod]}"></span>${esc(l.sit)}${i >= 0 ? ` <span class="mut">· ${i + 1} de ${ids.length} na tabela</span>` : ''}` : '';
  $('#c-ant').disabled = i <= 0; $('#c-prox').disabled = i < 0 || i >= ids.length - 1;
}

$('#tabela thead').addEventListener('click', (e) => {
  const th = e.target.closest('th'); if (!th) return;
  const c = th.dataset.c;
  UI.ordem = { c, dir: UI.ordem.c === c ? -UI.ordem.dir : (COLS_NUM.has(c) && c !== 'ordem' ? -1 : 1) };
  gravarUI(); desenharTabela();
});
$('#tabela tbody').addEventListener('click', (e) => { const tr = e.target.closest('tr[data-id]'); if (tr) abrirEmpresa(tr.dataset.id); });
$('#tabela tbody').addEventListener('dblclick', (e) => {
  const tr = e.target.closest('tr[data-id]'); if (!tr) return;
  const l = UI.linhas.find((x) => x.id === tr.dataset.id);
  UI.aba = 'apuracao'; UI.etapa = l && l.cod === 'nao' ? 1 : 5; abrirEmpresa(tr.dataset.id);
});
$('#chips').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; UI.filtro = b.dataset.f; gravarUI(); desenharTabela(); });
let tBusca;
$('#busca').addEventListener('input', () => { clearTimeout(tBusca); tBusca = setTimeout(() => { UI.busca = $('#busca').value; desenharTabela(); }, 200); });

async function abrirEmpresa(id) {
  UI.atual = String(id);
  $$('#tabela tbody tr').forEach((tr) => tr.classList.toggle('sel', tr.dataset.id === UI.atual));
  await desenharEmpresa();
  desenharCompacto();
  aplicarLayout();
}
function andar(d) {
  const ids = UI.ordemIds || []; const i = ids.indexOf(UI.atual);
  const j = Math.max(0, Math.min(ids.length - 1, i + d));
  if (ids[j] && ids[j] !== UI.atual) abrirEmpresa(ids[j]);
}
async function proximaPendente() {
  const a = await M('proxima_pendente');
  if (!a) return avisar('Todas as empresas selecionadas estão validadas.');
  UI.aba = 'apuracao'; UI.etapa = a.cod === 'nao' ? 1 : 5; abrirEmpresa(a.id);
}

// ------------------------------------------------------------------ empresa
async function desenharEmpresa() {
  const e = await M('empresa', UI.atual);
  if (!e || e.ok === false) return;
  UI.emp = e;
  $('#vazio').hidden = true; $('#emp').hidden = false;
  $('#cab-nome').textContent = e.nome;
  $('#cab-sub').textContent = `${e.cnpj}${e.uf ? ' · ' + e.uf : ''} · ${e.reg_rot} · competência ${e.comp_rot}`;
  $('#cab-chips').innerHTML = `<span class="chip ${CLS[e.s.cod] || ''}">${esc(e.s.rot)}</span>` + (e.n_pend ? `<span class="chip ${e.pend[0].sev === 'erro' ? 'erro' : 'atencao'}">${e.n_pend} pendência(s)</span>` : '') + (e.salva ? '<span class="chip">apuração salva</span>' : '');
  $$('#abas button').forEach((b) => b.classList.toggle('on', b.dataset.aba === UI.aba));
  $('#pag-resumo').hidden = UI.aba !== 'resumo';
  $('#pag-apuracao').hidden = UI.aba !== 'apuracao';
  if (UI.aba === 'resumo') desenharResumo(e); else await desenharApuracao(e);
}
$('#abas').addEventListener('click', (ev) => { const b = ev.target.closest('button[data-aba]'); if (!b) return; UI.aba = b.dataset.aba; gravarUI(); desenharEmpresa().then(aplicarLayout); });
const irValidar = () => { UI.aba = 'apuracao'; UI.etapa = 5; gravarUI(); desenharEmpresa().then(aplicarLayout); };
$('#cab-validar').addEventListener('click', irValidar);
$('#c-validar').addEventListener('click', irValidar);

function kpi(r, v, s = '', cls = '') { return `<div class="kpi"><div class="r">${r}</div><div class="v ${cls}">${v}</div>${s ? `<div class="s">${s}</div>` : ''}</div>`; }
function desenharResumo(e) {
  const r = e.res || {};
  const difCls = r.dif == null ? '' : Math.abs(r.dif) >= 0.01 ? 'c-bad' : 'c-ok';
  $('#pag-resumo').innerHTML = `
    <div class="kpis">
      ${kpi('Receita do mês', brl(r.rpa))}
      ${kpi('Tributos calculados', brl(r.calc), r.aliq != null ? 'alíquota efetiva ' + pct(r.aliq, 2) : '')}
      ${kpi('Declarado', brl(r.decl))}
      ${kpi('Diferença', brl(r.dif), '', difCls)}
      ${e.reg === 'SN' ? kpi('Fator R', pct(r.fr), r.rbt12 != null ? 'RBT12 ' + brl(r.rbt12) + (r.faixa ? ' · ' + r.faixa + 'ª faixa' : '') : '') : kpi('Regime', e.reg_rot, r.regra || '')}
    </div>
    <div class="bloco"><h3>O que resolver</h3>${e.pend.length ? e.pend.map((p) => `<div class="pend-item" data-x="${esc(p.id)}">
        <span class="chip ${p.sev === 'erro' ? 'erro' : 'atencao'}">${p.sev === 'erro' ? 'ERRO' : 'ATENÇÃO'}</span>
        <div class="flex1"><b>${esc(p.titulo)}</b><div class="mut">${esc(p.causa || p.cat || '')}</div></div>
        ${p.impacto ? `<b class="c-bad">${brl(p.impacto)}</b>` : ''}</div>`).join('')
      : `<p class="mut">${e.s.cod === 'nao' ? 'Sem dados do mês: importe XML/PGDAS-D ou lance as receitas na Apuração.' : 'Nada pendente nesta competência.'}</p>`}</div>
    <div class="bloco"><h3>Histórico de apurações</h3><div class="doc">${e.historico}</div></div>
    <div class="bloco"><h3>Trilha da competência</h3><div class="doc">${e.trilha}</div></div>`;
  $$('#pag-resumo .pend-item').forEach((el) => el.addEventListener('click', irValidar));
  ligarLinks($('#pag-resumo'));
}

// ------------------------------------------------------------------ apuração (5 etapas)
const ETAPAS = { SN: ['Arquivos', 'Receitas do mês', 'RBT12 e folha', 'Memória de cálculo', 'Validação'],
                 LP: ['Arquivos', 'Receitas do mês', 'Tributos e retenções', 'Memória de cálculo', 'Validação'] };
async function desenharApuracao(e) {
  const nomes = ETAPAS[e.reg] || ETAPAS.SN;
  $('#ap-regime').value = e.reg;
  $('#ap-sub').textContent = `${e.cnpj} · competência ${e.comp_rot}`;
  $('#passos').innerHTML = nomes.map((n, i) => `<button data-et="${i + 1}" class="${UI.etapa === i + 1 ? 'on' : ''}">${i + 1}. ${n}${
    i === 0 && e.xml.qtd ? ` · ${e.xml.qtd} notas` : i === 4 ? ' · ' + esc(e.s.rot.toLowerCase()) : ''}</button>`).join('');
  const r = e.res || {};
  const dif = r.dif;
  $('#faixa').innerHTML = `
    <div><div class="r">${e.reg === 'LP' ? 'Tributos do mês' : 'DAS recalculado'}</div><div class="v">${brl(r.calc)}</div><div class="s">${r.calc == null ? 'Lance as receitas do mês' : r.aliq != null ? 'alíquota ' + pct(r.aliq, 2) : ''}</div></div>
    <div><div class="r">Declarado</div><div class="v">${brl(r.decl)}</div><div class="s">${e.pgdas ? 'PGDAS-D importado' : ''}</div></div>
    <div><div class="r">Diferença</div><div class="v ${dif == null ? '' : Math.abs(dif) >= 0.01 ? 'c-bad' : 'c-ok'}">${brl(dif)}</div></div>
    <div><div class="r">Receita do mês</div><div class="v">${brl(r.rpa)}</div></div>
    <div><div class="r">${e.reg === 'SN' ? 'Fator R · RBT12' : 'Regra'}</div><div class="v">${e.reg === 'SN' ? pct(r.fr) : esc(r.regra || '—')}</div><div class="s">${e.reg === 'SN' && r.rbt12 != null ? brl(r.rbt12) + (r.faixa ? ' · ' + r.faixa + 'ª faixa' : '') : ''}</div></div>`;
  $('#et-ant').disabled = UI.etapa <= 1;
  $('#et-prox').hidden = UI.etapa >= 5;
  $('#et-prox').textContent = UI.etapa < 5 ? nomes[UI.etapa] + ' →' : '';
  $('#et-status').innerHTML = `<span class="dot" style="background:${PONTO[e.s.cod]}"></span><b>${esc(e.s.rot)}</b> · ${e.s.pendErros || 0} erro(s) · ${e.s.pendAlert || 0} alerta(s) · ${e.s.aprov || 0} aprovada(s)`;
  $('#ap-salvar').hidden = e.travada;
  const el = $('#etapa');
  if (UI.etapa === 1) return etapaArquivos(e, el);
  if (UI.etapa === 2 || UI.etapa === 3) {
    if (e.reg !== 'SN') {
      el.innerHTML = e.reg === 'LP'
        ? '<p>O lançamento do <b>Lucro Presumido</b> (receitas por atividade, tributos e retenções) ainda é feito no programa desktop. Aqui no site você vê a memória de cálculo e valida a competência com o que já está na nuvem.</p>'
        : '<p>Regime "Outro": o Validador não apura esta empresa. Troque o regime no seletor acima se ela for do Simples ou do Presumido.</p>';
      return;
    }
    return UI.etapa === 2 ? etapaReceitas(e, el) : etapaRbt12(e, el);
  }
  if (UI.etapa === 4) { const m = await M('memoria', e.id); el.innerHTML = `<div class="doc">${m.html}</div>`; return; }
  return etapaValidacao(e, el);
}
$('#passos').addEventListener('click', (ev) => { const b = ev.target.closest('button[data-et]'); if (!b) return; UI.etapa = +b.dataset.et; desenharEmpresa(); });
$('#et-ant').addEventListener('click', () => { UI.etapa = Math.max(1, UI.etapa - 1); desenharEmpresa(); });
$('#et-prox').addEventListener('click', () => { UI.etapa = Math.min(5, UI.etapa + 1); desenharEmpresa(); });
$('#ap-regime').addEventListener('change', async (ev) => { await mudar('definir_regime', UI.atual, ev.target.value); avisar('Regime alterado: vale para todas as competências desta empresa.'); });
$('#ap-salvar').addEventListener('click', async () => { const r = await mudar('salvar_apuracao', UI.atual); if (r && r.ok) avisar('Apuração salva.'); });

// etapa 1 — arquivos
function etapaArquivos(e, el) {
  el.innerHTML = `
    <div class="drop" id="drop"><b>Arraste aqui os XML (NF-e, NFC-e, NFS-e), o PDF do PGDAS-D ou um .zip</b><br>
      <span>ou</span> <button id="bt-arq" class="pri" style="margin-top:8px">Escolher arquivos…</button>
      <input id="in-arq" type="file" multiple accept=".xml,.pdf,.zip,.txt,.csv" hidden>
      <p class="mut" style="margin:10px 0 0">As notas vão para a empresa certa pelo CNPJ, mesmo que você esteja em outra.</p></div>
    <div id="log-imp"></div>
    <div class="bloco" style="margin-top:14px"><h3>Notas desta empresa em ${esc(e.comp_rot)}</h3>
      ${e.xml.qtd ? `<p><b>${e.xml.qtd}</b> nota(s) · total <b>${brl(e.xml.total)}</b></p>
        <table class="form"><tr><th>Grupo</th><th class="n" style="text-align:right">Valor</th></tr>${e.xml.grupos.map((g) => `<tr><td>${esc(g.rot)}</td><td class="n">${fmt(g.valor)}</td></tr>`).join('')}</table>`
        : '<p class="mut">Nenhuma nota importada nesta competência.</p>'}
      <p class="mut">PGDAS-D da competência: <b>${e.pgdas ? 'importado' : 'não importado'}</b></p></div>`;
  const inp = $('#in-arq', el), drop = $('#drop', el);
  $('#bt-arq', el).addEventListener('click', () => inp.click());
  inp.addEventListener('change', () => importar([...inp.files]));
  drop.addEventListener('dragover', (ev) => { ev.preventDefault(); drop.classList.add('sobre'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('sobre'));
  drop.addEventListener('drop', (ev) => { ev.preventDefault(); drop.classList.remove('sobre'); importar([...ev.dataTransfer.files]); });
}
async function importar(files) {
  if (!files.length) return;
  const log = $('#log-imp');
  if (log) log.innerHTML = `<p class="mut">Lendo ${files.length} arquivo(s)…</p>`;
  const lista = await Promise.all(files.map(async (f) => [f.name, new Uint8Array(await f.arrayBuffer())]));
  try {
    const r = await M('importar', lista);
    const sem = Object.entries(r.semEmpresa || {});
    const html = `<div class="bloco" style="margin-top:12px"><h3>Importação concluída</h3>
      <p><b>${r.nfe}</b> NF-e/NFC-e · <b>${r.nfse}</b> NFS-e · <b>${r.pgdas.length}</b> PGDAS-D${r.canc ? ` · ${r.canc} cancelada(s)` : ''}${r.compras ? ` · ${r.compras} nota(s) de compra` : ''}</p>
      ${sem.length ? `<p class="c-warn">CNPJ fora da carteira: ${sem.map(([k, v]) => esc(k) + ' (' + esc(v) + ')').join(', ')}</p>` : ''}
      ${r.erros.length ? `<p class="c-bad">Com erro: ${r.erros.map(esc).join(' · ')}</p>` : ''}
      ${r.ignorados.length ? `<p class="mut">Ignorados: ${r.ignorados.map(esc).join(' · ')}</p>` : ''}</div>`;
    marcarSujo();
    await redesenhar();
    const l2 = $('#log-imp'); if (l2) l2.innerHTML = html;
    avisar('Arquivos importados.');
  } catch (e) { if (log) log.innerHTML = `<p class="erro">${esc(e.message)}</p>`; }
}

// etapa 2 — receitas do mês (Simples)
async function etapaReceitas(e, el) {
  const f = await M('form_sn', e.id);
  const trava = e.travada ? 'disabled' : '';
  const optAnexo = (a) => f.anexos.map((x) => `<option ${x === a ? 'selected' : ''}>${x}</option>`).join('');
  el.innerHTML = `
    ${f.xml.length ? `<h3 style="margin-top:0">Receitas das notas (XML)</h3>
      <table class="form"><tr><th>Grupo</th><th style="width:120px">Anexo</th><th class="n" style="width:160px">Valor</th></tr>
      ${f.xml.map((x) => `<tr><td>${esc(x.descricao)}</td><td><select data-xml="${esc(x.g)}" ${trava}>${optAnexo(x.anexo)}</select></td><td class="n">${fmt(x.valor)}</td></tr>`).join('')}</table>` : ''}
    ${f.declaradas.length ? `<p class="mut">Sem lançamento manual: usando o que foi declarado no PGDAS-D (${f.declaradas.length} atividade(s)).</p>` : ''}
    <h3>${f.xml.length ? 'Outras receitas (lançamento manual)' : 'Receitas do mês'}</h3>
    <table class="form" id="tb-rec"><tr><th>Descrição</th><th style="width:110px">Anexo</th><th style="width:150px" class="n">Valor</th>
      <th class="c" title="ICMS por substituição tributária">ST</th><th class="c" title="PIS/Cofins monofásico">Mono</th><th class="c" title="ISS retido na fonte">ISS ret.</th><th class="c" title="Exportação">Exp.</th><th></th></tr>
      ${f.receitas.map((r, i) => `<tr data-i="${i}"><td><input data-k="descricao" value="${esc(r.descricao)}" placeholder="Ex.: Revenda de peças" ${trava}></td>
        <td><select data-k="anexo" ${trava}>${optAnexo(r.anexo || 'I')}</select></td>
        <td><input data-k="valor" class="n" value="${esc(r.valor)}" placeholder="0,00" inputmode="decimal" ${trava}></td>
        ${['icms_st', 'monofasico', 'iss_retido', 'exportacao'].map((k) => `<td class="c"><input type="checkbox" data-k="${k}" ${r[k] ? 'checked' : ''} ${trava}></td>`).join('')}
        <td><button class="ico" data-del="${i}" title="Remover" ${trava}>×</button></td></tr>`).join('')}
    </table>
    <button id="bt-add" class="sec" style="margin-top:8px" ${trava}>+ Adicionar receita</button>
    <div class="linha-campos">
      <label>DAS informado (se não importar o PGDAS-D)<input id="in-das" class="n" value="${esc(f.dasInf)}" placeholder="${f.das_pgdas != null ? fmt(f.das_pgdas) + ' (PGDAS-D)' : '0,00'}" ${trava}></label>
    </div>
    <p class="mut">ST = ICMS por substituição tributária · Mono = PIS/Cofins monofásico · ISS ret. = retido na fonte · Exp. = exportação.
      ${e.travada ? '<br><b>Competência validada:</b> reabra na etapa 5 para alterar.' : ''}</p>`;
  const coletar = () => ({
    receitas: $$('#tb-rec tr[data-i]', el).map((tr) => {
      const o = {}; $$('[data-k]', tr).forEach((i) => (o[i.dataset.k] = i.type === 'checkbox' ? i.checked : i.value)); return o;
    }),
    dasInf: $('#in-das', el).value,
    anexoXml: Object.fromEntries($$('[data-xml]', el).map((s) => [s.dataset.xml, s.value])),
  });
  const salvar = async (patch) => { await mudar('salvar_form_sn', e.id, JSON.stringify(patch || coletar())); };
  el.addEventListener('change', (ev) => { if (ev.target.matches('input,select')) salvar(); });
  $('#bt-add', el).addEventListener('click', () => { const p = coletar(); p.receitas.push({ descricao: '', anexo: 'I', valor: '' }); salvar(p); });
  $$('[data-del]', el).forEach((b) => b.addEventListener('click', () => { const p = coletar(); p.receitas.splice(+b.dataset.del, 1); salvar(p); }));
}

// etapa 3 — RBT12 e folha (Simples)
async function etapaRbt12(e, el) {
  const f = await M('form_sn', e.id);
  const trava = e.travada ? 'disabled' : '';
  const tot = f.meses.reduce((s, m) => s + (m.hist_ef || 0), 0);
  el.innerHTML = `
    <div class="linha-campos">
      <label>Início das atividades<input id="in-ini" type="month" value="${esc(f.inicio)}" ${trava}></label>
      <span class="mut">${f.inicio_ef ? 'em uso: ' + esc(f.inicio_ef) : ''}</span>
      <label>RBT12 informada (opcional)<input id="in-rbt" class="n" value="${esc(f.rbt12)}" placeholder="calculada pelos meses" ${trava}></label>
      <label>Folha 12 meses — total (opcional)<input id="in-f12" class="n" value="${esc(f.folha12)}" placeholder="pelos meses abaixo" ${trava}></label>
    </div>
    <table class="form" id="tb-meses"><tr><th>Mês</th><th class="n" style="width:200px">Receita bruta</th><th>Origem</th><th class="n" style="width:200px">Folha (salários + pró-labore + encargos)</th><th></th></tr>
      ${f.meses.map((m) => `<tr data-m="${m.m}"><td><b>${esc(m.rot)}</b></td>
        <td><input data-k="hist" class="n" value="${esc(m.hist)}" placeholder="${m.hist_ef != null ? fmt(m.hist_ef) : '0,00'}" ${trava}></td>
        <td class="origem">${esc(m.hist)?'manual':esc(m.hist_or || '')}</td>
        <td><input data-k="folha" class="n" value="${esc(m.folha)}" placeholder="${m.folha_ef != null ? fmt(m.folha_ef) : '0,00'}" ${trava}></td><td></td></tr>`).join('')}
      <tr><td><b>Total 12 meses</b></td><td class="n"><b>${fmt(tot)}</b></td><td></td><td class="n"><b>${fmt(f.folha_12m)}</b></td><td class="origem">${esc(f.origemFolha || '')}</td></tr>
    </table>
    <p class="mut">Os valores em cinza vêm do PGDAS-D, de apurações salvas ou dos XML. Digite só o que quiser corrigir; apagar volta para a origem automática.</p>`;
  const coletar = () => {
    const hist = {}, folha = {};
    $$('#tb-meses tr[data-m]', el).forEach((tr) => { hist[tr.dataset.m] = $('[data-k=hist]', tr).value; folha[tr.dataset.m] = $('[data-k=folha]', tr).value; });
    return { inicio: $('#in-ini', el).value, rbt12: $('#in-rbt', el).value, folha12: $('#in-f12', el).value, hist, folha };
  };
  el.addEventListener('change', (ev) => { if (ev.target.matches('input')) mudar('salvar_form_sn', e.id, JSON.stringify(coletar())); });
}

// etapa 5 — validação
async function etapaValidacao(e, el) {
  const v = await M('validacao', e.id);
  el.innerHTML = `<div style="display:flex;gap:8px;justify-content:flex-end;margin-bottom:8px">
      ${v.travada ? '<button id="bt-reabrir" class="sec">Reabrir competência</button>' : '<button id="bt-concluir" class="pri">Concluir validação</button>'}
      <button id="bt-rel" class="sec">Imprimir relatório</button></div>
    <div class="doc">${v.html}</div>`;
  ligarLinks(el);
  const c = $('#bt-concluir', el), ra = $('#bt-reabrir', el);
  c && c.addEventListener('click', async () => { const r = await mudar('concluir', e.id); if (r && r.ok) avisar('Competência validada.'); });
  ra && ra.addEventListener('click', async () => { await mudar('reabrir', e.id); avisar('Competência reaberta.'); });
  $('#bt-rel', el).addEventListener('click', () => imprimir('validacao', e.id));
}

/** Links dentro do HTML do motor: just:, desjust:, acao:, irpa: (iguais aos do programa). */
function ligarLinks(el) {
  el.querySelectorAll('.doc a[href]').forEach((a) => a.addEventListener('click', async (ev) => {
    const h = a.getAttribute('href');
    if (/^https?:/.test(h)) return;
    ev.preventDefault();
    if (h.startsWith('just:')) return justificar(h.slice(5));
    if (h.startsWith('desjust:')) return mudar('desfazer_just', UI.atual, h.slice(8));
    if (h.startsWith('irpa:')) return irComp(h.slice(5));
    if (h.startsWith('acao:')) {
      const x = h.slice(5);
      if (/^\d$/.test(x)) { UI.aba = 'apuracao'; UI.etapa = +x; return desenharEmpresa().then(aplicarLayout); }
      if (x === 'aba:memoria') { UI.aba = 'apuracao'; UI.etapa = 4; return desenharEmpresa().then(aplicarLayout); }
      if (x.startsWith('aba:')) { UI.aba = 'apuracao'; UI.etapa = 5; return desenharEmpresa().then(aplicarLayout); }
      if (x.startsWith('comp:')) return irComp(x.slice(5));
      if (x === 'importar') { UI.aba = 'apuracao'; UI.etapa = 1; return desenharEmpresa().then(aplicarLayout); }
      return avisar('Esta ação fica no programa desktop (' + x + ').');
    }
    if (h.startsWith('delap:') || h.startsWith('delpg:')) return avisar('Excluir apurações/PGDAS continua no programa desktop.');
  }));
}
async function justificar(xid) {
  const x = await M('checagem', UI.atual, xid);
  if (!x) return;
  const erro = x.sev === 'erro';
  modal(`<h3>${erro ? 'Justificar divergência' : 'Marcar como revisado'}</h3><p><b>${esc(x.titulo)}</b></p>
    <textarea id="txt-just" placeholder="${erro ? 'Descreva o motivo (mínimo 10 caracteres)' : 'Observação (opcional)'}"></textarea>
    <p id="err-just" class="erro" hidden></p>
    <div class="modal-bts"><button class="sec" id="mj-c">Cancelar</button><button class="pri" id="mj-ok">${erro ? 'Justificar' : 'Marcar revisado'}</button></div>`,
  (m) => {
    $('#txt-just', m).focus();
    $('#mj-c', m).onclick = fecharModal;
    $('#mj-ok', m).onclick = async () => {
      const t = $('#txt-just', m).value.trim();
      if (erro && t.length < 10) { const p = $('#err-just', m); p.hidden = false; p.textContent = 'Descreva a justificativa (mínimo 10 caracteres).'; return; }
      const r = await M('justificar', UI.atual, xid, t);
      if (r.ok === false) { const p = $('#err-just', m); p.hidden = false; p.textContent = r.erro; return; }
      fecharModal(); marcarSujo(); await redesenhar();
    };
  });
}
async function imprimir(tipo, id) {
  const w = window.open('', '_blank');
  const r = await M('relatorio', tipo, id || null);
  if (!r.ok) { w && w.close(); return avisar(r.erro); }
  if (!w) return avisar('O navegador bloqueou a nova aba. Libere pop-ups para este site.');
  w.document.open(); w.document.write(r.html); w.document.close();
}

// ------------------------------------------------------------------ competência
async function irComp(c) {
  $('#comp').value = c;
  $('#comp-rot').textContent = nomeMes(c);
  await M('definir_comp', c);
  await redesenhar();
}
$('#comp').addEventListener('change', () => $('#comp').value && irComp($('#comp').value));
$('#comp-rot').addEventListener('click', () => { try { $('#comp').showPicker(); } catch (_) { $('#comp').focus(); } });
$('#comp-ant').addEventListener('click', () => irComp(mesAdd($('#comp').value, -1)));
$('#comp-prox').addEventListener('click', () => irComp(mesAdd($('#comp').value, 1)));

// ------------------------------------------------------------------ menu, nuvem, layout, atalhos
$('#bt-menu').addEventListener('click', (e) => { e.stopPropagation(); $('#menu').hidden = !$('#menu').hidden; });
document.addEventListener('click', () => ($('#menu').hidden = true));
$('#menu').addEventListener('click', async (e) => {
  const a = e.target.closest('button')?.dataset.acao; if (!a) return;
  if (a === 'sair') { await enviar(); await sb.auth.signOut(); location.reload(); }
  if (a === 'atualizar') atualizarNuvem();
  if (a === 'rel-carteira') imprimir('carteira');
  if (a === 'tamanho') {
    const op = [14, 15, 16.5, 18]; UI.fs = op[(op.indexOf(UI.fs) + 1) % op.length];
    document.documentElement.style.setProperty('--fs', UI.fs + 'px'); gravarUI(); aplicarLayout();
  }
});
async function atualizarNuvem() {
  await enviar();
  setNuvem('salvando', 'Baixando…');
  try {
    const rows = await lerTudo(CONFIG.tabelaNuvem, 'chave,dados', 'chave', 200);
    await M('atualizar_nuvem', JSON.stringify(rows));
    setNuvem('ok'); await redesenhar(); avisar('Dados atualizados da nuvem.');
  } catch (e) { setNuvem('erro', e.message); avisar(e.message, 6000); }
}
$('#bt-nuvem').addEventListener('click', () => (sujo ? enviar() : atualizarNuvem()));
$('#bt-proxima').addEventListener('click', proximaPendente);
$('#c-pend').addEventListener('click', proximaPendente);
$('#c-ant').addEventListener('click', () => andar(-1));
$('#c-prox').addEventListener('click', () => andar(1));
$('#bt-mostrar').addEventListener('click', () => { UI.tabelaAberta = true; gravarUI(); aplicarLayout(); });
$('#bt-recolher').addEventListener('click', () => { UI.tabelaAberta = false; gravarUI(); aplicarLayout(); });
const ampliar = (on) => document.body.classList.toggle('ampliado', on ?? !document.body.classList.contains('ampliado'));
$('#ap-ampliar').addEventListener('click', () => ampliar());

// divisória arrastável entre a tabela e a empresa
$('#divisor').addEventListener('mousedown', (ev) => {
  ev.preventDefault();
  const m = $('#mestre'), y0 = ev.clientY, h0 = m.getBoundingClientRect().height;
  const mover = (e) => { const h = Math.max(140, Math.min(window.innerHeight - 220, h0 + e.clientY - y0)); m.style.height = h + 'px'; UI.alturaMestre = h; };
  const soltar = () => { document.removeEventListener('mousemove', mover); document.removeEventListener('mouseup', soltar); gravarUI(); };
  document.addEventListener('mousemove', mover); document.addEventListener('mouseup', soltar);
});

document.addEventListener('keydown', (e) => {
  const digitando = /INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName);
  if (e.key === 'F8') { e.preventDefault(); proximaPendente(); }
  else if (e.key === 'F11') { e.preventDefault(); ampliar(); }
  else if (e.key === 'Escape') { if (!$('#modal-fundo').hidden) fecharModal(); else ampliar(false); }
  else if (e.altKey && e.key === 'ArrowLeft') { e.preventDefault(); andar(-1); }
  else if (e.altKey && e.key === 'ArrowRight') { e.preventDefault(); andar(1); }
  else if (e.ctrlKey && (e.key === 't' || e.key === 'T') && UI.aba === 'apuracao') { e.preventDefault(); UI.tabelaAberta = !UI.tabelaAberta; gravarUI(); aplicarLayout(); }
  else if (!digitando && e.key === '/') { e.preventDefault(); $('#busca').focus(); }
  else if (!digitando && (e.key === 'ArrowDown' || e.key === 'ArrowUp') && !$('#mestre-cheio').hidden) { e.preventDefault(); andar(e.key === 'ArrowDown' ? 1 : -1); }
});
window.addEventListener('resize', aplicarLayout);
sb.auth.onAuthStateChange((ev) => { if (ev === 'SIGNED_OUT') location.reload(); });

abrir().catch((e) => mostrarLogin(String(e.message || e)));
