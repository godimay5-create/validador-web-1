"""Empacota o motor do Validador (o mesmo Python do .exe) em motor.zip (raiz do site) para o navegador.

Uso:  python fonte/tools/montar_motor.py  <pasta do projeto desktop validador_tributario>
Rode de novo sempre que o motor do desktop mudar (regras, cálculos, importação) e faça o deploy.
"""
import sys
import zipfile
from pathlib import Path

SITE = Path(__file__).resolve().parent.parent.parent      # raiz do site (onde fica o index.html)
FONTE = SITE / 'fonte'
MODULOS = ['__init__', 'servico', 'store', 'util', 'importacao', 'motor_sn', 'lp', 'regras_sn', 'atividades', 'ncm', 'relatorios']


def main(origem):
    vt = Path(origem) / 'vt'
    if not (vt / 'servico.py').exists():
        sys.exit(f'Não achei {vt / "servico.py"} — informe a pasta validador_tributario do desktop.')
    destino = SITE / 'motor.zip'
    with zipfile.ZipFile(destino, 'w', zipfile.ZIP_DEFLATED) as z:
        for m in MODULOS:
            z.write(vt / f'{m}.py', f'vt/{m}.py')
        z.write(FONTE / 'py' / 'supabase_rest_web.py', 'vt/supabase_rest.py')   # versão sem rede (a rede é do JavaScript)
        z.write(FONTE / 'py' / 'web.py', 'web.py')
    print('ok:', destino, destino.stat().st_size // 1024, 'KB')


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else '../validador_tributario')
