"""Ponte entre o site (JavaScript) e o motor do Validador (o MESMO Python do programa desktop).

Roda dentro do Pyodide, num Web Worker. Tudo entra e sai como texto JSON.
A conversa com o Supabase é feita pelo JavaScript: aqui o motor só recebe as linhas
da nuvem (`simples_dados`) e devolve os pacotes a enviar — no mesmo formato do .exe,
então o programa desktop e o site usam os mesmos dados ao mesmo tempo.
"""
from __future__ import annotations

import json
import threading

from vt import store as ST
from vt import servico as S
from vt import relatorios as R
from vt import lp as LPM
from vt.util import num, r2, brl, valN, pctN, fmt_cnpj, dig, raiz_de, nome_mes, data_hora, mes_add, esc
from vt.importacao import GRUPOS

APP = None          # Validador
EST = None          # EstadoWeb
_CFG_SALVA = None   # callback JS (grava a config no navegador)


def _js(v):
    return json.dumps(v, ensure_ascii=False, default=lambda o: sorted(o) if isinstance(o, set) else str(o))


def _ok(**kw):
    return _js({'ok': True, **kw})


def _erro(msg):
    return _js({'ok': False, 'erro': str(msg)})


# ---------------------------------------------------------------- estado sem disco
class EstadoWeb(ST.Estado):
    """O mesmo Estado do desktop, sem arquivos: a cópia de segurança é a própria nuvem."""

    def __init__(self, cfg):  # noqa: D401 — não chama o __init__ do disco
        self.forms, self.imp, self.cancel, self.apur, self.log = {}, {}, set(), {}, {}
        self.cfg = dict(cfg or {})
        self.lock = threading.RLock()
        self.ver = 0
        self.disco_sujo = set()
        self.sb = None
        self.nuvem_on = False
        self.sujo = set()
        self.hash = {}
        self.ao_mudar_nuvem = None

    def carregar(self):
        pass

    def gravar(self, cats=None):
        self.disco_sujo.clear()

    def gravar_cfg(self):
        if _CFG_SALVA:
            try:
                _CFG_SALVA(_js(self.cfg))
            except Exception:  # noqa: BLE001
                pass


# ---------------------------------------------------------------- início / nuvem
def iniciar(cfg_json, email, user_id, salvar_cfg=None):
    global APP, EST, _CFG_SALVA
    _CFG_SALVA = salvar_cfg
    EST = EstadoWeb(json.loads(cfg_json or '{}'))
    APP = S.Validador(EST)
    APP.sb.email, APP.sb.user_id = email or '', user_id or ''
    if not APP.comp:
        from datetime import date
        d = date.today()
        APP.comp = mes_add(f'{d.year:04d}-{d.month:02d}', -1)      # padrão: mês anterior
    return _ok(comp=APP.comp)


def definir_empresas(rows_json):
    APP.empresas = json.loads(rows_json)
    APP._idx = {str(e.get(S.CFG_CARTEIRA['colId'])): e for e in APP.empresas}
    return _ok(n=len(APP.empresas))


def aplicar_nuvem(rows_json):
    """Primeira carga: aplica tudo o que veio do banco e liga o envio automático."""
    rows = json.loads(rows_json)
    EST.nuvem_on = False
    EST.aplicar_nuvem(rows, False)
    EST.nuvem_on = True
    EST.sujo.clear()
    if not APP.sel:
        APP.sel = _ids_com_dados()
        APP.salvar_cfg()
    n = APP.validar_ids(APP.ids_sel())
    return _ok(linhas=len(rows), apuradas=n, sel=len(APP.ids_sel()))


def atualizar_nuvem(rows_json):
    """Recarga (botão Atualizar / outro computador mexeu): junta o que veio por cima."""
    rows = json.loads(rows_json)
    EST.aplicar_nuvem(rows, True)
    APP.RES.clear(); APP.CHK.clear(); APP.HASH.clear()
    APP.validar_ids(APP.ids_sel())
    return _ok(linhas=len(rows))


def _ids_com_dados():
    """Seleção inicial no navegador: empresas que já têm algo na nuvem (formulário, importação ou apuração)."""
    ids = set()
    raizes = set(EST.imp) | set(EST.apur)
    for k in EST.forms:
        if '|' in k and k[:4].isdigit():
            ids.add(k.split('|', 1)[1])
    for e in APP.empresas:
        i = str(e.get(S.CFG_CARTEIRA['colId']))
        if raiz_de(e.get(S.CFG_CARTEIRA['colCnpj'])) in raizes:
            ids.add(i)
    return {i for i in ids if APP.emp(i)}


def pacote():
    """Linhas alteradas desde o último envio: {sobe:[{chave, txt, atualizado_em, h}], apaga:[...], cats:[...]}."""
    pac = EST.preparar_envio()
    if not pac:
        return _js(None)
    return _js({'cats': pac['cats'], 'apaga': pac['apaga'],
                'sobe': [{'chave': x[0]['chave'], 'txt': x[0]['txt'], 'atualizado_em': x[0]['atualizado_em'], 'h': x[1]} for x in pac['sobe']]})


def confirmar(conf_json):
    c = json.loads(conf_json)
    for k, h in c.get('sobe') or []:
        EST.hash[k] = h
    for k in c.get('apaga') or []:
        EST.hash.pop(k, None)
    return _ok()


def falhou(cats_json):
    for c in json.loads(cats_json) or []:
        EST.sujo.add(c)
    return _ok()


# ---------------------------------------------------------------- competência / seleção
def definir_comp(comp):
    APP.comp = comp
    APP.RES.clear(); APP.CHK.clear(); APP.HASH.clear()
    APP.salvar_cfg()
    APP.validar_ids(APP.ids_sel())
    return _ok(comp=comp)


def selecionar(id_, sim):
    id_ = str(id_)
    if sim:
        APP.sel.add(id_)
        APP.apurar_caso(id_)
    else:
        APP.sel.discard(id_)
    APP.salvar_cfg()
    return _ok()


# ---------------------------------------------------------------- tabela de empresas
PEND = ('erro', 'alterada', 'revisao')
ORDEM = {'erro': 0, 'alterada': 0, 'revisao': 1, 'pronta': 2, 'nao': 3, 'ressalva': 4, 'validada': 4}


def tabela(filtro='sel', busca=''):
    q = (busca or '').strip().upper()
    qd = dig(q)
    sel = set(APP.ids_sel())
    L, n_pend = [], 0
    tot = {'rec': 0.0, 'calc': 0.0, 'decl': 0.0, 'dif': 0.0}
    n_div = 0
    for e in APP.empresas:
        id_ = str(e.get(S.CFG_CARTEIRA['colId']))
        na = id_ in sel
        s = APP.situacao(id_) if na else None
        cod = s['cod'] if s else 'fora'
        if na and cod in PEND:
            n_pend += 1
        if filtro == 'pend' and not (na and cod in PEND):
            continue
        if filtro == 'sel' and not na:
            continue
        reg = APP.regime_de(id_)
        if filtro in ('sn', 'lp') and reg != filtro.upper():
            continue
        nome = e.get('nome_fantasia') or APP.nome(id_)
        if q and q not in nome.upper() and q not in (APP.nome(id_) or '').upper() and not (qd and qd in dig(APP.cnpj(id_))):
            continue
        r = (APP.res(id_) or {}) if na else {}
        pend = []
        if na:
            pend = [x for x in APP.CHK.get(APP.chave(id_)) or [] if APP.pendente(id_, x)]
            pend.sort(key=lambda x: (0 if x['sev'] == 'erro' else 1, -(x.get('impacto') or 0)))
        lin = {'id': id_, 'nome': nome, 'razao': APP.nome(id_), 'cnpj': fmt_cnpj(APP.cnpj(id_)), 'reg': reg, 'na': na,
               'cod': cod, 'sit': s['rot'] if s else 'Fora da seleção', 'ordem': ORDEM.get(cod, 9),
               'rec': r.get('rpa'), 'calc': r.get('total_calculado'), 'decl': r.get('das_informado'), 'dif': r.get('diferenca'),
               'fr': r.get('fator_r'), 'rbt': r.get('rbt12'), 'fx': r.get('faixa'),
               'pend': (pend[0]['titulo'] + (f'  (+{len(pend) - 1})' if len(pend) > 1 else '')) if pend else
                       ('fora da seleção' if not na else 'Sem dados do mês' if cod == 'nao' else '✓ sem pendências'),
               'pend_sev': pend[0]['sev'] if pend else ''}
        for k, kk in (('rec', 'rec'), ('calc', 'calc'), ('decl', 'decl'), ('dif', 'dif')):
            if lin[kk] is not None:
                tot[k] += lin[kk]
        if lin['dif'] not in (None, 0) and abs(lin['dif']) >= 0.01:
            n_div += 1
        L.append(lin)
    return _js({'linhas': L, 'n_pend': n_pend, 'n_sel': len(sel), 'n_tot': len(APP.empresas), 'comp': APP.comp,
                'tot': {k: r2(v) for k, v in tot.items()}, 'n_div': n_div})


def proxima_pendente():
    a = APP.proxima_pendente()
    return _js({'id': a['id'], 'cod': a['s']['cod']} if a else None)


# ---------------------------------------------------------------- empresa
MSG_SIT = {'erro': 'Há erros críticos: corrija os dados ou justifique antes de concluir.',
           'revisao': 'Sem erros críticos. Revise os alertas para concluir.',
           'pronta': 'Tudo conferido. Conclua a validação para gravar os dados e a regra usada.'}


def _msg(s):
    v = s.get('v') or {}
    if s['cod'] == 'alterada':
        return f"Validada por {v.get('por')} em {data_hora(v.get('em', ''))}, mas os dados mudaram depois. Revise e conclua de novo."
    if s['cod'] in ('validada', 'ressalva'):
        return (f"Validada por {v.get('por')} em {data_hora(v.get('em', ''))} · regra {v.get('regra')}"
                + (f" · {s['just']} ressalva(s)." if s['cod'] == 'ressalva' else '.'))
    return MSG_SIT.get(s['cod'], '')


def empresa(id_):
    id_ = str(id_)
    if not APP.emp(id_):
        return _erro('Empresa não encontrada.')
    if id_ not in APP.sel:
        APP.sel.add(id_)
        APP.salvar_cfg()
    APP.atual = id_
    r = APP.res(id_) or APP.apurar_caso(id_)
    s = APP.situacao(id_)
    k = APP.chave(id_)
    reg = APP.regime_de(id_)
    pend = [x for x in APP.CHK.get(k) or [] if APP.pendente(id_, x)]
    pend.sort(key=lambda x: (0 if x['sev'] == 'erro' else 1, -(x.get('impacto') or 0)))
    e = APP.emp(id_) or {}
    caso = None
    try:
        caso = APP.montar_caso(id_) if reg == 'SN' else None
    except Exception:  # noqa: BLE001
        caso = None
    xml = (caso or {}).get('_xml') or {}
    return _js({
        'id': id_, 'nome': APP.nome(id_), 'fantasia': e.get('nome_fantasia') or '', 'cnpj': fmt_cnpj(APP.cnpj(id_)), 'uf': APP.uf_de(id_),
        'reg': reg, 'reg_rot': S.REG_ROT.get(reg, reg), 'comp': APP.comp, 'comp_rot': nome_mes(APP.comp),
        's': s, 'msg': _msg(s), 'travada': APP.travada(s),
        'res': None if not r else {'rpa': r.get('rpa'), 'calc': r.get('total_calculado'), 'decl': r.get('das_informado'),
                                   'dif': r.get('diferenca'), 'fr': r.get('fator_r'), 'rbt12': r.get('rbt12'), 'faixa': r.get('faixa'),
                                   'aliq': r.get('aliquota_efetiva'), 'regra': (r.get('regra') or {}).get('versao')},
        'pend': [{'id': x['id'], 'sev': x['sev'], 'titulo': x['titulo'], 'cat': x.get('cat'), 'impacto': x.get('impacto'),
                  'causa': x.get('causa')} for x in pend[:8]],
        'n_pend': len(pend),
        'xml': {'qtd': xml.get('qtd') or 0, 'total': xml.get('total') or 0,
                'grupos': [{'g': g, 'rot': GRUPOS[g]['rot'], 'valor': v} for g, v in (xml.get('grupos') or {}).items() if v]},
        'pgdas': bool((caso or {}).get('_pg')),
        'historico': R.historico(APP, id_),
        'trilha': R.trilha_html(APP.trilha(id_, True), True),
        'salva': bool(APP.apur_salva(id_)),
    })


# ---------------------------------------------------------------- Simples Nacional: formulário (etapas 2 e 3)
CAMPOS_REC = ('descricao', 'anexo', 'valor', 'icms_st', 'monofasico', 'iss_retido', 'exportacao', 'atividade')


def form_sn(id_):
    id_ = str(id_)
    f = APP.form(id_)
    caso = APP.montar_caso(id_)
    c = APP.comp
    meses = [mes_add(c, -i) for i in range(12, 0, -1)]
    from vt import atividades as ATV
    return _js({
        'receitas': [{k: r.get(k) for k in CAMPOS_REC} for r in f['receitas']],
        'xml': [{'descricao': r['descricao'], 'anexo': r['anexo'], 'valor': r['valor'], 'g': next((g for g, d in GRUPOS.items() if d['rot'] == r['descricao']), '')}
                for r in caso['receitas'] if r.get('origem') == 'XML'],
        'declaradas': [{'descricao': r['descricao'], 'anexo': r['anexo'], 'valor': r['valor']} for r in caso['receitas'] if r.get('origem') == 'PGDAS-D'],
        'dasInf': f.get('dasInf') or '', 'das_pgdas': ((caso.get('_pg') or {}).get('das') or {}).get('total'),
        'inicio': f.get('inicio') or '', 'inicio_ef': caso.get('inicio_atividade'), 'rbt12': f.get('rbt12') or '',
        'folha12': f.get('folha12') or '', 'folhaMes': f.get('folhaMes') or '',
        'meses': [{'m': m, 'rot': nome_mes(m), 'hist': (f.get('hist') or {}).get(m, ''), 'hist_ef': caso['hist'].get(m),
                   'hist_or': caso['origemHist'].get(m, ''), 'folha': (f.get('folha') or {}).get(m, ''),
                   'folha_ef': caso['folhaMeses'].get(m)} for m in meses],
        'folha_12m': caso.get('folha_12m'), 'origemFolha': caso.get('origemFolha'),
        'atividades': caso.get('atividades') or [],
        'lista_atividades': [{'cod': k, 'nome': ATV.rotulo(k), 'anexo': v['anexo']} for k, v in ATV.ATIVIDADES.items()],
        'anexos': ['I', 'II', 'III', 'IV', 'V'],
    })


def salvar_form_sn(id_, patch_json):
    """Grava o que foi editado nas etapas 2/3 (mesmos campos do desktop) e recalcula."""
    id_ = str(id_)
    p = json.loads(patch_json)
    f = APP.form(id_)
    mud = []
    if 'receitas' in p:
        novas = []
        for r in p['receitas']:
            x = {k: r.get(k) for k in CAMPOS_REC if r.get(k) not in (None, '') or k in ('descricao', 'valor', 'anexo')}
            for b in ('icms_st', 'monofasico', 'iss_retido', 'exportacao'):
                x[b] = bool(r.get(b))
            novas.append(x)
        f['receitas'] = novas or [{'descricao': '', 'anexo': 'I', 'valor': ''}]
        mud.append('Receitas do mês')
    for campo, rot in (('dasInf', 'DAS informado'), ('inicio', 'Início das atividades'), ('rbt12', 'RBT12 informada'),
                       ('folha12', 'Folha 12 meses (total)'), ('folhaMes', 'Folha do mês')):
        if campo in p and str(p[campo] or '') != str(f.get(campo) or ''):
            f[campo] = p[campo] or ''
            mud.append(rot)
    for campo, rot in (('hist', 'Receitas dos meses anteriores'), ('folha', 'Folha dos meses anteriores')):
        if campo in p:
            d = {m: v for m, v in (p[campo] or {}).items() if str(v or '').strip() != ''}
            if d != {m: v for m, v in (f.get(campo) or {}).items() if str(v or '').strip() != ''}:
                f[campo] = d
                mud.append(rot)
    if 'anexoXml' in p:
        f['anexoXml'] = {g: a for g, a in (p['anexoXml'] or {}).items() if a}
    APP.salvar_forms()
    if mud:
        APP.registrar(id_, 'Alteração', campo=', '.join(mud), para='site')
    APP.apurar_caso(id_)
    return _ok(mudou=mud)


def definir_atividades(id_, cods_json):
    APP.definir_atividades(str(id_), json.loads(cods_json))
    APP.apurar_caso(str(id_))
    return _ok()


def definir_regime(id_, reg):
    APP.definir_regime(str(id_), reg)
    return _ok()


# ---------------------------------------------------------------- memória, validação, ações
def memoria(id_):
    id_ = str(id_)
    r = APP.res(id_) or APP.apurar_caso(id_)
    if not r:
        return _js({'html': '<p class=mut>Lance as receitas do mês (ou importe XML/PGDAS-D) para ver a memória de cálculo.</p>'})
    nome, cnpj = APP.nome(id_), APP.cnpj(id_)
    h = R.memoria_lp(r, nome, cnpj) if r.get('regime') == 'LP' else R.memoria_sn(r, nome, cnpj, APP.comp)
    return _js({'html': h})


def validacao(id_):
    id_ = str(id_)
    r = APP.res(id_) or APP.apurar_caso(id_)
    s = APP.situacao(id_)
    if not r:
        return _js({'html': '<p class=mut>Lance as receitas do mês (ou importe XML/PGDAS-D) para validar a competência.</p>', 's': s, 'travada': False})
    h = R.centro(APP.CHK.get(APP.chave(id_)) or [], lambda x: APP.just_de(id_, x), APP.travada(s), _msg(s), s)
    return _js({'html': h, 's': s, 'travada': APP.travada(s)})


def justificar(id_, xid, texto):
    e = APP.justificar(str(id_), xid, texto)
    return _erro(e) if e else _ok()


def desfazer_just(id_, xid):
    APP.desfazer_just(str(id_), xid)
    return _ok()


def concluir(id_):
    e = APP.concluir_validacao(str(id_))
    return _erro(e) if e else _ok()


def reabrir(id_):
    APP.reabrir(str(id_))
    APP.apurar_caso(str(id_))
    return _ok()


def salvar_apuracao(id_):
    e = APP.salvar_apuracao(str(id_))
    return _erro(e) if e else _ok()


def checagem(id_, xid):
    x = next((y for y in APP.CHK.get(APP.chave(str(id_))) or [] if y['id'] == xid), None)
    return _js(x and {'id': x['id'], 'sev': x['sev'], 'titulo': x['titulo']})


# ---------------------------------------------------------------- importação (XML / PDF do PGDAS-D / ZIP)
def importar(lista):
    """lista: [[nome, bytes], ...] vinda do navegador."""
    arqs = [(str(n), b.to_bytes() if hasattr(b, 'to_bytes') else bytes(b)) for n, b in lista]
    log = APP.importar(arqs)
    sem = log.get('semEmpresa') or {}
    return _js({'ok': True, 'nfe': log.get('nfe', 0), 'nfse': log.get('nfse', 0), 'canc': log.get('canc', 0),
                'pgdas': [str(x) for x in log.get('pgdas') or []], 'compras': log.get('compras', 0),
                'raizes': sorted(log.get('raizes') or []), 'erros': [str(x) for x in log.get('erros') or []][:30],
                'ignorados': [str(x) for x in log.get('ignorados') or []][:30], 'semEmpresa': {str(k): str(v) for k, v in sem.items()},
                'semReceita': log.get('semReceita', 0), 'lacunas': [str(x) for x in log.get('lacunas') or []][:12]})


# ---------------------------------------------------------------- relatórios para imprimir (abrem em nova aba)
_REL = {}


def _captura(titulo, corpo, usuario, logo_path=None, paisagem=False):
    from datetime import datetime
    pag = '@page{size:A4 landscape}' if paisagem else ''
    _REL['html'] = (f'<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>{esc(titulo)}</title>'
                    f'<style>{R.CSS_PRINT}{pag}</style></head><body><img src="/img/logo_navy.png" style="height:38px;margin:0 0 14px" alt="Contrato">'
                    f'{corpo}<p class="mut" style="font-size:10px">Contrato · Contabilidade e Consultoria — gerado em '
                    f'{datetime.now().strftime("%d/%m/%Y %H:%M")} por {esc(usuario)}</p>'
                    '<script>window.onload=()=>window.print()</script></body></html>')
    return None


R.abrir_impressao = _captura


def relatorio(tipo, id_=None):
    _REL.clear()
    msg = None
    if tipo == 'validacao':
        msg = R.relatorio_validacao(APP, str(id_), None)
    elif tipo == 'memoria':
        msg = R.relatorio_memoria(APP, str(id_), None)
    elif tipo == 'carteira':
        msg = R.relatorio_carteira(APP, None)
    if _REL.get('html'):
        return _js({'ok': True, 'html': _REL['html']})
    return _erro(msg or 'Nada para imprimir.')
