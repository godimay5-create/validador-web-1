"""Importação de documentos fiscais: NF-e/NFC-e, NFS-e (nacional/ABRASF/GISS),
eventos de cancelamento, TXT e CSV de NFS-e da Prefeitura de São Paulo,
declaração/extrato do PGDAS-D em PDF e arquivos ZIP.

Tudo é agrupado pela raiz do CNPJ (8 dígitos): o Simples é apurado pela
matriz, somando as filiais.
"""
from __future__ import annotations

import io
import re
import zipfile
import xml.etree.ElementTree as ET

from .util import r2, dig, raiz_de, fmt_cnpj, br_num, iso_data, brl
from . import ncm as NCM
from .ncm import ncm_limpo

GRUPOS = {
    'merc':         {'rot': 'Mercadorias', 'anexo': 'I'},
    'merc_st':      {'rot': 'Mercadorias com ICMS-ST (CSOSN 500)', 'anexo': 'I', 'icms_st': True},
    'merc_mono':    {'rot': 'Mercadorias monofásicas PIS/Cofins', 'anexo': 'I', 'monofasico': True},
    'merc_st_mono': {'rot': 'Mercadorias com ICMS-ST e monofásicas', 'anexo': 'I', 'icms_st': True, 'monofasico': True},
    'exp':          {'rot': 'Exportação de mercadorias', 'anexo': 'I', 'exportacao': True},
    'serv':         {'rot': 'Serviços', 'anexo': 'III'},
    'serv_ret':     {'rot': 'Serviços com ISS retido', 'anexo': 'III', 'iss_retido': True},
}
FIM_VENDA = set('101 102 103 104 105 106 109 110 111 112 113 114 115 116 117 118 119 120 122 123 124 125 401 402 403 405 501 502 651 652 653 654 655 656 667'.split())
FIM_EXPORT = set('101 102 105 106 127 501'.split())
FIM_DEVOL = set('201 202 203 204 410 411 503 504 660 661 662'.split())


# ---------------- helpers de XML independentes de namespace ----------------
def _ln(tag) -> str:
    return tag.rsplit('}', 1)[-1] if isinstance(tag, str) else ''


def TA(el, n, incl_self=False):
    if el is None:
        return []
    out = [x for x in el.iter() if _ln(x.tag) == n]
    if not incl_self and out and out[0] is el:
        out = out[1:]
    return out


def T(el, n, incl_self=False):
    a = TA(el, n, incl_self)
    return a[0] if a else None


def V(el, n) -> str:
    x = T(el, n)
    return (x.text or '').strip() if x is not None else ''


def NV(el, n) -> float:
    v = V(el, n)
    try:
        return float(v) if v else 0.0
    except ValueError:
        return 0.0


def aliq_pct(a) -> float:
    """Alíquota de ISS em %: aceita 2, 2.00 ou 0.02 (alguns layouts gravam a fração)."""
    try:
        a = float(a or 0)
    except (TypeError, ValueError):
        return 0.0
    return round(a * 100, 4) if 0 < a < 1 else round(a, 4)


def nfse_n(cnpj, n) -> str:
    n = str(n)
    return f"NFSEN-{cnpj}-{int(n) if n.isdigit() else n}"


def novo_log():
    return {'nfe': 0, 'nfse': 0, 'canc': 0, 'pgdas': [], 'semReceita': 0, 'semReceitaLista': [], 'lacunas': [], 'compras': 0, 'ignorados': [],
            'semEmpresa': {}, 'erros': [], 'raizes': set()}


# ---------------- NF-e / NFC-e ----------------
def ler_nfe(root, arq):
    """Receita = vProd − vDesc + vFrete + vSeg + vOutro (sem IPI e sem ICMS-ST cobrado)."""
    out = []
    for inf in TA(root, 'infNFe', True):
        ide, emit, dest = T(inf, 'ide'), T(inf, 'emit'), T(inf, 'dest')
        ch = (inf.get('Id') or '').replace('NFe', '', 1) if (inf.get('Id') or '').startswith('NFe') else (inf.get('Id') or '')
        tpNF = V(ide, 'tpNF')
        mod = 'NFC-e' if V(ide, 'mod') == '65' else 'NF-e'
        data = iso_data(V(ide, 'dhEmi') or V(ide, 'dEmi'))
        numero = V(ide, 'nNF')
        c_emit = dig(V(emit, 'CNPJ'))
        c_dest = dig(V(dest, 'CNPJ')) if dest is not None else ''
        p_emit, p_dest = {}, {}
        ignorado = 0.0
        tx = {'ICMS': 0.0, 'ST': 0.0, 'IPI': 0.0}
        vei = []
        itens = []          # itens da venda (para classificar por NCM na apuração)
        compra = []         # itens com ICMS-ST/monofásico, vistos pelo lado do comprador
        tpEntrada = tpNF == '1' and bool(c_dest)
        for det in TA(inf, 'det'):
            prod, imp = T(det, 'prod'), T(det, 'imposto')
            cfop = V(prod, 'CFOP')
            d1, fim = cfop[:1], cfop[1:]
            valor = NV(prod, 'vProd') - NV(prod, 'vDesc') + NV(prod, 'vFrete') + NV(prod, 'vSeg') + NV(prod, 'vOutro')
            icms = T(imp, 'ICMS')
            st = V(icms, 'CSOSN') == '500' or V(icms, 'CST') == '60'
            pis_cst, cof_cst = V(T(imp, 'PIS'), 'CST'), V(T(imp, 'COFINS'), 'CST')
            mono = pis_cst in ('04', '05') or cof_cst in ('04', '05')
            gm = 'merc' + ('_st' if st else '') + ('_mono' if mono else '')
            ncm, cest = V(prod, 'NCM'), V(prod, 'CEST')
            cst_icms = V(icms, 'CSOSN') or V(icms, 'CST')
            if tpEntrada:
                st_compra = (cst_icms in ('10', '30', '60', '70', '201', '202', '203', '500') or NV(icms, 'vICMSST') > 0
                             or NV(icms, 'vICMSSTRet') > 0 or NV(icms, 'vBCSTRet') > 0 or NV(icms, 'vICMSSubstituto') > 0)
                if st_compra or mono:
                    compra.append({'ncm': ncm, 'st': st_compra, 'mono': mono, 'x': V(prod, 'xProd')[:50], 'cst': cst_icms})
            g, sinal, alvo = None, 1, p_emit
            if tpNF == '1' and d1 in ('5', '6') and fim in FIM_VENDA:
                g = gm
            elif tpNF == '1' and d1 in ('5', '6') and fim == '933':
                g = 'serv'
            elif tpNF == '1' and d1 == '7' and fim in FIM_EXPORT:
                g = 'exp'
            elif tpNF == '0' and d1 in ('1', '2', '3') and fim in FIM_DEVOL:
                g = 'exp' if d1 == '3' else gm
                sinal = -1
            elif tpNF == '1' and d1 in ('5', '6') and fim in FIM_DEVOL:
                g, sinal, alvo = gm, -1, p_dest
            # veículo (chassi): revenda de usados — base pela margem no Lucro Presumido
            chassi = V(T(prod, 'veicProd'), 'chassi').upper()
            if not chassi:
                mm = re.search(r'\b[A-HJ-NPR-Z0-9]{17}\b', (V(prod, 'xProd') + ' ' + V(det, 'infAdProd')).upper())
                if mm and re.search(r'\d', mm.group(0)) and re.search(r'[A-Z]', mm.group(0)):
                    chassi = mm.group(0)
            bc_pis = NV(T(imp, 'PIS'), 'vBC')
            margem_nota = tpNF == '1' and 0 < bc_pis < valor - 0.01
            if chassi or margem_nota:
                vei.append({'chassi': chassi or f'NF{numero}-{len(vei) + 1}', 'semChassi': True if not chassi else None,
                            'bc': r2(bc_pis) if bc_pis else None, 'v': r2(valor), 'cfop': cfop,
                            'tp': 'D' if tpNF == '0' and fim in FIM_DEVOL else tpNF,
                            'g': g if (g and sinal > 0 and alvo is p_emit) else None,
                            'mono': mono or pis_cst in ('06', '07', '09'), 'desc': V(prod, 'xProd')[:80]})
            if not g:
                ignorado += valor
                continue
            alvo[g] = r2(alvo.get(g, 0) + sinal * valor)
            if alvo is p_emit:
                itens.append({'ncm': ncm, 'cest': cest, 'cst': cst_icms, 'pis': pis_cst, 'x': V(prod, 'xProd')[:50],
                              't': 'merc' if g.startswith('merc') else g, 'v': r2(sinal * valor)})
                tx['ICMS'] = r2(tx['ICMS'] + sinal * NV(icms, 'vICMS'))
                tx['ST'] = r2(tx['ST'] + sinal * NV(icms, 'vICMSST'))
                tx['IPI'] = r2(tx['IPI'] + sinal * NV(T(imp, 'IPI'), 'vIPI'))
        base = {'mod': mod, 'n': numero, 'serie': V(ide, 'serie'), 'd': data, 'arq': arq, 'ign': r2(ignorado)}
        if p_emit:
            n = {**base, 'k': ch, 'ch': ch, 'cnpj': c_emit, 'p': p_emit}
            if tx['ICMS'] or tx['ST'] or tx['IPI']:
                n['tx'] = tx
            if vei:
                n['vei'] = vei
            if itens:
                n['itens'] = itens
            out.append(n)
        if compra:
            out.append({'compra': True, 'cnpj': c_dest, 'emit': c_emit, 'n': numero, 'd': data, 'itens': compra, 'mod': mod, 'k': ch + '#compra'})
        if p_dest and c_dest:
            out.append({**base, 'k': ch + '#dev', 'ch': ch, 'cnpj': c_dest, 'p': p_dest, 'dev': True})
        if not p_emit and not p_dest:
            n = {**base, 'k': ch, 'ch': ch, 'cnpj': c_emit, 'p': {}, 'semReceita': True,
                 'cfops': sorted({V(T(det, 'prod'), 'CFOP') for det in TA(inf, 'det')}), 'nat': V(ide, 'natOp')[:60]}
            if vei:
                n['vei'] = vei
            out.append(n)
    return out


# ---------------- NFS-e ----------------
def _nfse_cancelada(b) -> bool:
    """Indicadores de NFS-e cancelada usados pelos layouts municipais (ABRASF, GISS, Betha, Ginfes...)."""
    for tag in ('DataCancelamento', 'dhCanc', 'DataHoraCancelamento', 'MotivoCancelamento'):
        if V(b, tag):
            return True
    for tag in ('SituacaoNfse', 'StatusNfse', 'Situacao', 'Status', 'SituacaoNota'):
        v = V(b, tag).strip().lower()
        if v in ('2', 'c', 'cancelada', 'cancelado', 'canc'):
            return True
    v = V(b, 'Cancelada').strip().lower() or V(b, 'NfseCancelada').strip().lower()
    return v in ('s', 'sim', '1', 'true')



# ---------------- NFS-e: retenções federais, atividade e tomador ----------------
LEITURA_NFSE = 2          # versão da leitura: notas importadas antes desta versão não têm atividade nem retenção pela NT 007
# NFS-e Nacional, NT 007/2025 (vigente desde 09/02/2026): tpRetPisCofins → (PIS, Cofins, CSLL) retidos.
# Nesses códigos o campo vRetCSLL traz a SOMA de PIS + Cofins + CSLL retidos; vPis/vCofins são só da apuração própria.
TP_RET_NAC = {'0': (0, 0, 0), '3': (1, 1, 1), '4': (1, 1, 0), '5': (1, 0, 0), '6': (0, 1, 0),
              '7': (0, 1, 1), '8': (0, 0, 1), '9': (1, 0, 1)}
TP_RET_ROT = {'0': 'PIS/Cofins/CSLL não retidos', '1': 'PIS/Cofins retidos (código anterior à NT 007)',
              '2': 'PIS/Cofins não retidos (código anterior à NT 007)', '3': 'PIS, Cofins e CSLL retidos',
              '4': 'PIS e Cofins retidos; CSLL não', '5': 'só PIS retido', '6': 'só Cofins retida', '7': 'Cofins e CSLL retidas; PIS não',
              '8': 'só CSLL retida', '9': 'PIS e CSLL retidos; Cofins não'}
ALIQ_CSRF = {'PIS': 0.0065, 'COFINS': 0.03, 'CSLL': 0.01}      # Lei 10.833/2003, art. 31


def _ratear(total, tributos, base):
    """Separa o total retido (vRetCSLL da NT 007) entre os tributos marcados, pelas alíquotas da Lei 10.833/2003.
    Se o total bate com base × alíquotas, usa os valores exatos; se não, rateia proporcionalmente."""
    if not tributos or not total:
        return {t: 0.0 for t in tributos}, ''
    esp = {t: base * ALIQ_CSRF[t] for t in tributos}
    soma = sum(esp.values())
    if base and abs(soma - total) <= max(0.05, total * 0.002):
        out = {t: r2(v) for t, v in esp.items()}
        modo = 'separado pela base × alíquota (confere com o total retido)'
    else:
        pesos = {t: ALIQ_CSRF[t] for t in tributos}
        sp = sum(pesos.values())
        out = {t: r2(total * p / sp) for t, p in pesos.items()}
        modo = 'rateado pelas alíquotas 0,65% / 3% / 1% (total não bate com a base)'
    dif = r2(total - sum(out.values()))
    if dif:
        ult = tributos[-1]
        out[ult] = r2(out[ult] + dif)
    return out, modo


def retencoes_nfse(b, valor):
    """Retenções federais lidas do próprio XML. Devolve ({'IRRF','CSLL','PIS','COFINS'}, detalhe da leitura)."""
    pc = T(b, 'piscofins')
    nacional = pc is not None or T(b, 'tribFed') is not None or T(b, 'infDPS') is not None
    if not nacional:          # ABRASF / municipais: valores retidos em campos próprios
        rf = {'IRRF': NV(b, 'ValorIr') or NV(b, 'ValorIR') or NV(b, 'ValorIrrf'), 'CSLL': NV(b, 'ValorCsll'),
              'PIS': NV(b, 'ValorPis'), 'COFINS': NV(b, 'ValorCofins')}
        inss = NV(b, 'ValorInss')
        if not any(rf.values()) and not inss:
            return rf, None
        return rf, {'leiaute': 'ABRASF / municipal', 'modo': 'campos ValorIr, ValorCsll, ValorPis e ValorCofins', 'inss': r2(inss),
                    'campos': {k: v for k, v in (('ValorIr', rf['IRRF']), ('ValorCsll', rf['CSLL']), ('ValorPis', rf['PIS']),
                                                 ('ValorCofins', rf['COFINS']), ('ValorInss', inss)) if v}}
    tp = V(pc, 'tpRetPisCofins') if pc is not None else ''
    v_csll, v_ir, v_cp = NV(b, 'vRetCSLL'), NV(b, 'vRetIRRF'), NV(b, 'vRetCP')
    v_pis, v_cof = NV(pc, 'vPis'), NV(pc, 'vCofins')
    base = NV(pc, 'vBCPisCofins') or valor
    campos = {k: v for k, v in (('tpRetPisCofins', tp), ('vRetIRRF', v_ir), ('vRetCSLL', v_csll), ('vPis', v_pis), ('vCofins', v_cof),
                                ('vBCPisCofins', NV(pc, 'vBCPisCofins')), ('vRetCP', v_cp)) if v not in ('', 0, 0.0)}
    aviso = ''
    if tp in TP_RET_NAC:
        marc = [t for t, f in zip(('PIS', 'COFINS', 'CSLL'), TP_RET_NAC[tp]) if f]
        sep, modo = _ratear(v_csll, marc, base)
        rf = {'IRRF': v_ir, 'PIS': sep.get('PIS', 0.0), 'COFINS': sep.get('COFINS', 0.0), 'CSLL': sep.get('CSLL', 0.0)}
        if not marc and v_csll:
            aviso = f'tpRetPisCofins = 0 (nada retido), mas vRetCSLL = {v_csll:.2f}: confira a nota com o tomador.'
        if marc and not v_csll:
            aviso = 'O código diz que houve retenção, mas vRetCSLL está zerado.'
        modo = 'NT 007: vRetCSLL = PIS + Cofins + CSLL retidos; ' + (modo or 'sem retenção de PIS/Cofins/CSLL')
    else:                     # leiaute anterior (1/2 ou sem o grupo piscofins): vRetCSLL é só a CSLL
        pis, cof = (v_pis, v_cof) if tp == '1' else (0.0, 0.0)
        csll = v_csll
        modo = 'leiaute anterior à NT 007: vPis/vCofins retidos quando tpRetPisCofins = 1; vRetCSLL = CSLL'
        if v_csll and base and abs(v_csll - base * 0.0465) <= max(0.05, base * 0.0005):
            if tp == '1' and abs(v_csll - (v_pis + v_cof) - base * 0.01) <= max(0.05, base * 0.0005):
                csll = r2(v_csll - v_pis - v_cof)
                modo = 'vRetCSLL somava PIS + Cofins + CSLL (já no formato da NT 007): separado'
            elif tp != '1':
                sep, _ = _ratear(v_csll, ['PIS', 'COFINS', 'CSLL'], base)
                pis, cof, csll = sep['PIS'], sep['COFINS'], sep['CSLL']
                modo = 'vRetCSLL = 4,65% da base: tratado como PIS + Cofins + CSLL retidos (formato da NT 007)'
                aviso = f'Código {tp or "ausente"} sem PIS/Cofins retidos, mas vRetCSLL equivale a 4,65% da base: confira a nota.'
        rf = {'IRRF': v_ir, 'PIS': pis, 'COFINS': cof, 'CSLL': csll}
    rf = {k: r2(v) for k, v in rf.items()}
    if not any(rf.values()) and not campos.get('vRetCP') and not aviso and tp in ('', '0', '2'):
        return rf, None
    return rf, {'leiaute': 'NFS-e Nacional', 'tp': tp, 'tpRot': TP_RET_ROT.get(tp, 'não informado'), 'modo': modo,
                'inss': r2(v_cp), 'campos': campos, 'aviso': aviso}


def item_lc116(cod) -> str:
    """'140101' (cTribNac), '14.01', '1401', '14.01.01' ou '701' → '14.01' / '7.01'."""
    s = str(cod or '').strip()
    if not s:
        return ''
    if '.' in s:
        a, b = (s.split('.') + [''])[:2]
        a, b = dig(a), dig(b)
        return f'{int(a)}.{b[:2].zfill(2)}' if a and b else ''
    d = dig(s)
    if len(d) == 6:
        return f'{int(d[:2])}.{d[2:4]}'
    if len(d) in (3, 4):
        return f'{int(d[:-2])}.{d[-2:]}'
    return ''


def servico_nfse(b):
    """Atividade da nota: item da lista da LC 116 (cTribNac ou ItemListaServico), código municipal, CNAE e descrição."""
    raw = V(b, 'cTribNac') or V(b, 'ItemListaServico') or V(b, 'CodigoServico') or V(b, 'ItemServico')
    it = item_lc116(raw)
    desc = (V(b, 'xTribNac') or V(b, 'xDescServ') or V(b, 'Discriminacao') or '').strip()
    desc = re.sub(r'\s+', ' ', desc)[:160]
    cnae = dig(V(b, 'CodigoCnae') or V(b, 'cCNAE'))
    mun = V(b, 'cTribMun') or V(b, 'CodigoTributacaoMunicipio')
    if not (it or cnae or mun):
        return None
    o = {'it': it, 'cod': raw, 'x': desc}
    if cnae:
        o['cnae'] = cnae
    if mun:
        o['mun'] = mun
    nbs = V(b, 'cNBS')
    if nbs:
        o['nbs'] = nbs
    return o


def tomador_nfse(b):
    for x in (T(b, 'toma'), T(b, 'TomadorServico'), T(b, 'Tomador'), T(b, 'DadosTomador')):
        if x is None:
            continue
        doc = dig(V(x, 'CNPJ') or V(x, 'Cnpj') or V(x, 'CPF') or V(x, 'Cpf'))
        nome = V(x, 'xNome') or V(x, 'RazaoSocial') or V(x, 'NomeRazaoSocial')
        if doc or nome:
            return {'doc': doc, 'nome': nome[:80]}
    return None


def ler_nfse(root, arq, cancel: set):
    out, canc = [], 0
    blocos = TA(root, 'CompNfse', True) or TA(root, 'NFSe', True) or [root]
    for b in blocos:
        inf = T(b, 'InfNfse') or T(b, 'infNFSe') or b
        cnpj = ''
        for x in (T(b, 'IdentificacaoPrestador'), T(b, 'Prestador'), T(b, 'PrestadorServico'), T(b, 'prest'), T(b, 'emit')):
            v = V(x, 'Cnpj') or V(x, 'CNPJ')
            if v:
                cnpj = dig(v)
                break
        numero = V(inf, 'Numero') or V(b, 'nNFSe') or V(b, 'Numero')
        if T(b, 'NfseCancelamento') is not None or T(b, 'CancelamentoNfse') is not None:
            if cnpj and numero:
                cancel.add(nfse_n(cnpj, numero))
                canc += 1
            continue
        if _nfse_cancelada(b) and cnpj and numero:      # guarda a nota, mas marcada como cancelada
            cancel.add(nfse_n(cnpj, numero))
            canc += 1
        subst = V(inf, 'NfseSubstituida')
        if cnpj and subst:
            cancel.add(nfse_n(cnpj, subst))
            canc += 1
        valor = NV(b, 'ValorServicos') or NV(b, 'vServ')
        data = iso_data(V(b, 'Competencia') or V(b, 'dCompet') or V(b, 'DataEmissao') or V(b, 'dhEmi') or V(b, 'dhProc'))
        ret = V(b, 'IssRetido') == '1' or V(b, 'tpRetISSQN') in ('2', '3')
        k_ant = f"NFSE-{cnpj}-{numero}-{V(inf, 'CodigoVerificacao')}"
        idc = str(inf.get('Id') or '') if inf is not None else ''
        ch_id = dig(idc) if idc[:3].upper() == 'NFS' else ''
        # NFS-e Nacional: a chave de 50 dígitos fica no Id do infNFSe (é ela que os eventos de cancelamento citam)
        k = V(b, 'chNFSe') or (ch_id if len(ch_id) == 50 else '') or k_ant
        if not cnpj or not valor:
            continue
        rf, rf_info = retencoes_nfse(b, valor)
        n = {'k': k, 'ch': k, 'mod': 'NFS-e', 'n': numero, 'd': data, 'arq': arq, 'cnpj': cnpj,
             'p': {('serv_ret' if ret else 'serv'): r2(valor)}}
        if ret:     # alíquota e ISS retido informados na nota (conferência do art. 21, § 4º, LC 123)
            n['iss'] = {'aliq': aliq_pct(V(b, 'Aliquota') or V(b, 'pAliqAplic') or V(b, 'pAliq')),
                        'v': r2(NV(b, 'ValorIssRetido') or NV(b, 'ValorIss') or NV(b, 'vISSQN'))}
        if subst:
            n['subst'] = subst
        if any(rf.values()):
            n['rf'] = rf
        if rf_info:
            n['rfInfo'] = rf_info
        sv = servico_nfse(b)
        if sv:
            n['sv'] = sv
        tom = tomador_nfse(b)
        if tom:
            n['tom'] = tom
        n['lv'] = LEITURA_NFSE
        if k != k_ant:
            n['kAnt'] = k_ant             # chave usada por versões anteriores: sai ao reimportar (evita nota em dobro)
        out.append(n)
    return out, canc


def _guarda(imp, raizes, log, n):
    r = raiz_de(n['cnpj'])
    if n.get('compra'):
        if r in raizes:
            cp = imp.setdefault(r, {'notas': {}, 'pgdas': {}}).setdefault('compras', {})
            for it in n['itens']:
                k = ncm_limpo(it['ncm'])
                if not k:
                    continue
                ant = cp.get(k) or {}
                if (ant.get('d') or '') <= (n.get('d') or ''):
                    cp[k] = {'st': it['st'] or ant.get('st', False), 'mono': it['mono'] or ant.get('mono', False), 'n': n['n'], 'd': n['d'],
                             'emit': n['emit'], 'x': it['x'], 'cst': it['cst']}
            log['compras'] += 1
            log['raizes'].add(r)
        return
    if r not in raizes:
        if not n.get('semReceita'):
            k = fmt_cnpj(n['cnpj'])
            log['semEmpresa'][k] = log['semEmpresa'].get(k, 0) + 1
        return
    if n.get('semReceita'):
        log['semReceita'] += 1
        log['semReceitaLista'].append(f"{n['mod']} {n['n']}" + (f" (CFOP {', '.join(n.get('cfops') or [])}" + (f" — {n['nat']}" if n.get('nat') else '') + ')'
                                                               if n.get('cfops') else ''))
    notas = imp.setdefault(r, {'notas': {}, 'pgdas': {}})['notas']
    if n.get('kAnt'):
        notas.pop(n['kAnt'], None)
    notas[n['k']] = n
    log['raizes'].add(r)
    if n.get('semReceita'):
        return
    if n['mod'] == 'NFS-e':
        log['nfse'] += 1
    else:
        log['nfe'] += 1


EV_CANC_NFE = {'110111', '110112'}            # cancelamento / cancelamento por substituição (NFC-e)
EV_CANC_NFSE = ('e101101', 'e105102')         # NFS-e Nacional: cancelamento / cancelamento por substituição
OK_EVENTO = {'135', '136', '155'}             # evento registrado (no prazo, sem vínculo, fora do prazo)
NFE_VALIDA = {'100', '150'}                   # autorizada / autorizada fora do prazo


def ler_cancelamentos(root, cancel: set) -> int:
    """Procura cancelamentos em QUALQUER XML (arquivo só de evento, ou evento junto da nota).
    NF-e/NFC-e: evento 110111/110112, layout antigo procCancNFe, protNFe com situação cancelada/denegada.
    NFS-e Nacional: evento e101101/e105102 (chNFSe)."""
    n = 0
    # retornos de evento com status de rejeição não cancelam
    rejeitados = set()
    for ret in TA(root, 'retEvento', True):
        cs = V(ret, 'cStat')
        if cs and cs not in OK_EVENTO:
            rejeitados.add(V(ret, 'chNFe'))
    for ev in TA(root, 'infEvento', True):
        tp = V(ev, 'tpEvento')
        ch = V(ev, 'chNFe')
        if tp in EV_CANC_NFE and ch and ch not in rejeitados and ch not in cancel:
            cancel.add(ch)
            n += 1
    # NFS-e Nacional (pedido de registro de evento)
    for ped in TA(root, 'infPedReg', True) + TA(root, 'infEvento', True):
        if any(T(ped, t) is not None for t in EV_CANC_NFSE):
            ch = V(ped, 'chNFSe')
            if ch and ch not in cancel:
                cancel.add(ch)
                n += 1
    # layout antigo (NF-e 2.00): procCancNFe / cancNFe / infCanc
    for ic in TA(root, 'infCanc', True):
        ch = V(ic, 'chNFe')
        if ch and ch not in cancel:
            cancel.add(ch)
            n += 1
    # protocolo da própria nota com situação cancelada (101, 151, 135, 155) ou denegada (110, 301, 302, 303)
    for prot in TA(root, 'infProt', True):
        cs, ch = V(prot, 'cStat'), V(prot, 'chNFe')
        if ch and cs and cs not in NFE_VALIDA and ch not in cancel:
            cancel.add(ch)
            n += 1
    return n


def processar_xml(txt, arq, imp, cancel, raizes, log):
    try:
        root = ET.fromstring(txt.lstrip('\ufeff').encode('utf-8') if isinstance(txt, str) else txt)
    except ET.ParseError:
        log['erros'].append(f'{arq}: XML inválido')
        return
    log['canc'] += ler_cancelamentos(root, cancel)
    if TA(root, 'infNFe', True):
        notas = ler_nfe(root, arq)
    elif re.search(r'nfse|dps', _ln(root.tag), re.I) or TA(root, 'InfNfse', True) or TA(root, 'infNFSe', True):
        notas, c = ler_nfse(root, arq, cancel)
        log['canc'] += c
    elif TA(root, 'infEvento', True) or TA(root, 'infCanc', True) or TA(root, 'infPedReg', True):
        return                       # arquivo só de evento: já tratado acima
    else:
        log['ignorados'].append(arq)
        return
    compra_de = {raiz_de(n['cnpj']) for n in notas if n.get('compra')}
    for n in notas:
        if not n.get('compra') and raiz_de(n['cnpj']) not in raizes and compra_de & raizes:
            continue        # nota de fornecedor (entrada do cliente): só interessa o lado da compra
        _guarda(imp, raizes, log, n)


# ---------------- NFS-e São Paulo — TXT ----------------
def ler_txt_sp(txt, arq, imp, cancel, raizes, log) -> bool:
    linhas = re.split(r'\r?\n', txt)
    if not re.match(r'^1\d{3}\d{8}\d{16}', linhas[0] if linhas else ''):
        return False

    def c(l, i, n):
        return l[i - 1:i - 1 + n]

    def cent(s):
        return float(s) / 100
    lidas = canc = 0
    soma = 0.0
    padrao = re.compile(r'^\d{15}\d{15}\d{5}\d{4}\d{15}\d{15}[SN]\d\d{14}$')
    for l in linhas:
        if not l.startswith('2') or len(l) < 540:
            continue
        k = next((d for d in (0, 2, 1, -1, -2) if padrao.match(c(l, 448 + d, 85))), None)
        if k is None:
            log['erros'].append(f"{arq}: linha da NFS-e {c(l, 2, 8)} fora do layout")
            continue
        numero = str(int(c(l, 2, 8)))
        cod = c(l, 24, 8).strip()
        cnpj = dig(c(l, 71, 14))
        dh = c(l, 10, 8)
        sit = c(l, 419 + k, 1)
        d_canc = c(l, 420 + k, 8).strip()
        valor = cent(c(l, 448 + k, 15))
        ret = c(l, 517 + k, 1) == 'S'
        key = f'NFSE-{cnpj}-{numero}-{cod}'
        if d_canc or sit == 'C':
            cancel.add(key)
            canc += 1
            log['canc'] += 1
            continue
        if not cnpj or not valor:
            continue
        r = raiz_de(cnpj)
        if r not in raizes:
            log['semEmpresa'][fmt_cnpj(cnpj)] = log['semEmpresa'].get(fmt_cnpj(cnpj), 0) + 1
            continue
        imp.setdefault(r, {'notas': {}, 'pgdas': {}})['notas'][key] = {
            'k': key, 'ch': key, 'mod': 'NFS-e', 'n': numero, 'd': f'{dh[:4]}-{dh[4:6]}-{dh[6:8]}', 'arq': arq, 'cnpj': cnpj,
            'p': {('serv_ret' if ret else 'serv'): r2(valor)},
            'sp': {'cs': c(l, 448 + k + 30, 5), 'aliq': cent(c(l, 448 + k + 35, 4)), 'iss': cent(c(l, 448 + k + 39, 15)),
                   'tom': dig(c(l, 519 + k, 14))}}
        if ret:
            sp = imp[r]['notas'][key]['sp']
            imp[r]['notas'][key]['iss'] = {'aliq': aliq_pct(sp['aliq']), 'v': r2(sp['iss'])}
        log['raizes'].add(r)
        log['nfse'] += 1
        lidas += 1
        soma = r2(soma + valor)
    rod = next((l for l in linhas if l.startswith('9')), None)
    if rod:
        try:
            qtd, tot = int(c(rod, 2, 7)), cent(c(rod, 9, 15))
        except ValueError:
            qtd, tot = 0, 0
        if qtd and qtd != lidas + canc:
            log['erros'].append(f'{arq}: rodapé indica {qtd} nota(s), lidas {lidas + canc}')
        elif tot and abs(tot - soma) > 0.01 and not canc:
            log['erros'].append(f'{arq}: total do rodapé {brl(tot)} difere do lido {brl(soma)}')
    return True


# ---------------- NFS-e São Paulo — CSV ----------------
def ler_csv_sp(txt, arq, imp, cancel, raizes, log) -> bool:
    import unicodedata
    linhas = [l for l in re.split(r'\r?\n', txt.lstrip('﻿')) if l.strip()]

    def campos(l):
        o, cur, q, i = [], '', False, 0
        while i < len(l):
            ch = l[i]
            if q:
                if ch == '"' and i + 1 < len(l) and l[i + 1] == '"':
                    cur += '"'
                    i += 1
                elif ch == '"':
                    q = False
                else:
                    cur += ch
            elif ch == '"':
                q = True
            elif ch == ';':
                o.append(cur)
                cur = ''
            else:
                cur += ch
            i += 1
        o.append(cur)
        return [x.strip() for x in o]

    def norm(x):
        x = unicodedata.normalize('NFD', x)
        x = ''.join(ch for ch in x if unicodedata.category(ch) != 'Mn').lower()
        return re.sub(r'[^a-z0-9]', '', x)
    cab = [norm(h) for h in campos(linhas[0] if linhas else '')]
    if not cab or cab[0] != 'tipoderegistro' or not any(h.startswith('valordosserv') for h in cab):
        return False

    def col(pref, padrao):
        for i, h in enumerate(cab):
            if h.startswith(pref):
                return i
        return padrao
    C = {'num': col('nnfse', 1), 'dh': col('datahoranf', 2), 'cod': col('codigodeverif', 3), 'cnpj': col('cpfcnpjdoprest', 10),
         'sit': col('situacaodanota', 22), 'canc': col('datadecancel', 23), 'serv': col('valordosserv', 26),
         'ret': col('issretido', 32), 'tom': col('cpfcnpjdotomador', 34), 'pis': col('pispasep', 55),
         'cofins': col('cofins', 56), 'ir': col('ir', 58), 'csll': col('csll', 59),
         'aliq': col('aliquota', -1), 'viss': col('valordoiss', -1)}
    if C['ir'] >= len(cab) or cab[C['ir']] != 'ir':
        C['ir'] = cab.index('ir') if 'ir' in cab else -1

    def nb(v):
        v = str(v or '').strip()
        return br_num(v) if v else 0.0

    def g(v, i):
        return v[i] if 0 <= i < len(v) else ''
    lidas = canc = 0
    soma = 0.0
    tot = None
    for l in linhas[1:]:
        v = campos(l)
        if re.match(r'^total$', v[0], re.I):
            tot = {'qtd': int(dig(g(v, 1)) or 0), 'valor': nb(g(v, C['serv']))}
            continue
        if v[0] != '2':
            continue
        dn = dig(g(v, C['num']))
        numero = str(int(dn)) if dn else g(v, C['num'])
        cod, cnpj = g(v, C['cod']), dig(g(v, C['cnpj']))
        key = f'NFSE-{cnpj}-{numero}-{cod}'
        valor = nb(g(v, C['serv']))
        if g(v, C['canc']) or g(v, C['sit']) == 'C':
            cancel.add(key)
            canc += 1
            log['canc'] += 1
            continue
        if not cnpj or not valor:
            continue
        r = raiz_de(cnpj)
        if r not in raizes:
            log['semEmpresa'][fmt_cnpj(cnpj)] = log['semEmpresa'].get(fmt_cnpj(cnpj), 0) + 1
            continue
        rf = {'IRRF': nb(g(v, C['ir'])) if C['ir'] >= 0 else 0, 'CSLL': nb(g(v, C['csll'])),
              'PIS': nb(g(v, C['pis'])), 'COFINS': nb(g(v, C['cofins']))}
        n = {'k': key, 'ch': key, 'mod': 'NFS-e', 'n': numero, 'd': iso_data(g(v, C['dh'])), 'arq': arq, 'cnpj': cnpj,
             'p': {('serv_ret' if g(v, C['ret']).upper() == 'S' else 'serv'): r2(valor)}, 'sp': {'tom': dig(g(v, C['tom']))}}
        if g(v, C['ret']).upper() == 'S' and (C['aliq'] >= 0 or C['viss'] >= 0):
            n['iss'] = {'aliq': aliq_pct(nb(g(v, C['aliq']))), 'v': r2(nb(g(v, C['viss'])))}
        if any(rf.values()):
            n['rf'] = rf
        imp.setdefault(r, {'notas': {}, 'pgdas': {}})['notas'][key] = n
        log['raizes'].add(r)
        log['nfse'] += 1
        lidas += 1
        soma = r2(soma + valor)
    if tot:
        if tot['qtd'] and tot['qtd'] != lidas + canc:
            log['erros'].append(f"{arq}: linha Total indica {tot['qtd']} nota(s), lidas {lidas + canc}")
        elif not canc and tot['valor'] and abs(tot['valor'] - soma) > 0.01:
            log['erros'].append(f"{arq}: total da planilha {brl(tot['valor'])} difere do lido {brl(soma)}")
    return True


# ---------------- PGDAS-D (PDF) ----------------
def texto_pdf(data: bytes) -> str:
    from pypdf import PdfReader
    rd = PdfReader(io.BytesIO(data))
    t = ' '.join((p.extract_text() or '') for p in rd.pages)
    return re.sub(r'\s+', ' ', t)


def classificar_atividade(desc, por):
    d = desc.lower()
    o = {}
    ax = re.search(r'anexo\s+(v|iv|iii|ii|i)\b', d, re.I)
    if re.search(r'fator\s*[“"\']?\s*r', d) and not re.search(r'n[ãa]o sujeit', d):
        o['anexo'] = 'FATOR_R'
    elif ax:
        o['anexo'] = ax.group(1).upper()
    elif re.search(r'revenda de mercadorias', d):
        o['anexo'] = 'I'
    elif re.search(r'industrializ', d):
        o['anexo'] = 'II'
    else:
        o['anexo'] = 'III'
    if re.search(r'(^|[^o] )para o exterior', d) and not re.search(r'exceto para o exterior', d):
        o['exportacao'] = True
    if o['anexo'] in ('I', 'II') and re.search(r'com substitui', d):
        if not por.get('ICMS'):
            o['icms_st'] = True
        if not por.get('PIS') and not por.get('COFINS'):
            o['monofasico'] = True
    if re.search(r'com reten[çc][ãa]o', d) and not por.get('ISS'):
        o['iss_retido'] = True
    if re.search(r'loca[çc][ãa]o de bens m[óo]veis', d):
        o['iss_retido'] = True
    return o


RE_NUM = re.compile(r'-?[\d.]+,\d{2}')
NOMES_PG = ['IRPJ', 'CSLL', 'COFINS', 'PIS', 'CPP', 'ICMS', 'IPI', 'ISS']


def ler_pgdas(t: str):
    pa = re.search(r'Per[ií]odo de Apura[çc][ãa]o(?:\s*\(PA\))?\s*:?\s*(?:\d{2}/)?(\d{2})/(\d{4})', t, re.I)
    if not pa:
        return None
    cn = re.search(r'\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}', t)
    raiz = dig(cn.group(0))[:8] if cn else None
    if not raiz:
        cb = re.search(r'CNPJ\s*B[áa]sico\s*:?\s*(\d{2}\.?\d{3}\.?\d{3})', t, re.I)
        if not cb:
            return None
        raiz = dig(cb.group(1))[:8]
    r = {'pa': f'{pa.group(2)}-{pa.group(1)}', 'raiz': raiz}
    ab = re.search(r'Data de abertura no CNPJ\s*:?\s*(\d{2})/(\d{2})/(\d{4})', t, re.I)
    if ab:
        r['abertura'] = f'{ab.group(3)}-{ab.group(2)}'
        r['aberturaData'] = f'{ab.group(3)}-{ab.group(2)}-{ab.group(1)}'
    NUM = r'(-?[\d.]+,\d{2})'

    def nums_apos(pos, n):
        return [br_num(m.group(0)) for m in RE_NUM.finditer(t[pos:])][:n]

    def trio(rot):
        m = re.search(rot + r'[^\d-]{0,80}' + NUM + r'\s+' + NUM + r'\s+' + NUM, t)
        return [br_num(x) for x in m.groups()] if m else None
    rpa = trio(r'\(RPA\)\s*-\s*Compet[êe]ncia') or trio(r'\(RPA\)')
    if rpa:
        r['rpa'] = rpa[2]
    rbt = trio(r'\(RBT12\)')
    if rbt:
        r['rbt12'] = rbt[2]
    rba = trio(r'\(RBA\)')
    if rba:
        r['rba'] = rba[2]
    fr = re.search(r'Fator r\s*=\s*([\d,]+)', t, re.I)
    if fr:
        try:
            r['fatorR'] = br_num(fr.group(1))
        except ValueError:
            pass

    def secao(ini, fim):
        m = re.search(ini, t, re.I)
        if not m:
            return ''
        resto = t[m.start() + 5:]
        j = re.search(fim, resto, re.I)
        return resto[:3000] if not j else resto[:j.start()]

    def meses(s):
        ms = [f'{m.group(2)}-{m.group(1)}' for m in re.finditer(r'(\d{2})/(\d{4})', s)]
        vs = [br_num(m.group(0)) for m in RE_NUM.finditer(s)]
        o = {}
        if ms and len(ms) == len(vs):
            for i, m in enumerate(ms):
                o[m] = o.get(m, 0) + vs[i]
        else:
            for m in re.finditer(r'(\d{2})/(\d{4})\s+(-?[\d.]+,\d{2})', s):
                k = f'{m.group(2)}-{m.group(1)}'
                o[k] = o.get(k, 0) + br_num(m.group(3))
        return o
    mi = meses(secao(r'2\.2\.1\)\s*Mercado Interno', r'2\.2\.2\)|(?:^|\s)2\.3\)|(?:^|\s)2\.4\)'))
    me = meses(secao(r'2\.2\.2\)\s*Mercado Externo', r'(?:^|\s)2\.3\)|(?:^|\s)2\.4\)'))
    r['hist'] = dict(mi)
    for k, v in me.items():
        r['hist'][k] = r['hist'].get(k, 0) + v
    r['folha'] = meses(secao(r'(?:^|\s)2\.3\)\s*Folha de Sal[áa]rios', r'2\.3\.1\)|(?:^|\s)2\.4\)|(?:^|\s)2\.5\)|(?:^|\s)3\.?\s'))

    def por_trib(v):
        return {n: v[i] for i, n in enumerate(NOMES_PG)}
    for rot, totais in ((r'Total Geral da Empresa', False), (r'Totais do Estabelecimento', True)):
        m = re.search(rot, t, re.I)
        if not m:
            continue
        v = nums_apos(m.start(), 10 if totais else 9)
        if totais:
            v = v[1:]
        if len(v) == 9:
            r['das'] = {'total': v[8], 'por': por_trib(v)}
            break
    if 'das' not in r:
        td = re.search(r'Valor Total do D[ée]bito Declarado[^\d]{0,20}(-?[\d.]+,\d{2})\s+(-?[\d.]+,\d{2})', t, re.I)
        if td:
            r['das'] = {'total': br_num(td.group(2))}
    r['atividades'] = []
    partes = re.split(r'Valor do D[ée]bito por Tributo para a Atividade \(R\$\)\s*:?', t, flags=re.I)
    estab = ''
    for k, p in enumerate(partes):
        if k > 0:
            desc = re.split(r'Receita Bruta Informada', p, flags=re.I)[0].strip()
            rec = re.search(r'Receita Bruta Informada\s*:?\s*R\$\s*(-?[\d.]+,\d{2})', p, re.I)
            it = re.search(r'\bTotal\b', p)
            v = [br_num(m.group(0)) for m in RE_NUM.finditer(p[it.start():])][:9] if it else []
            if rec and len(v) == 9:
                pt = por_trib(v)
                r['atividades'].append({**classificar_atividade(desc, pt), 'descricao': desc, 'valor': br_num(rec.group(1)),
                                        'por': pt, 'total': v[8], 'estab': estab})
        ce = list(re.finditer(r'CNPJ Estabelecimento\s*:?\s*(\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2})', p, re.I))
        if ce:
            estab = dig(ce[-1].group(1))
    return r


# ---------------- orquestração ----------------
def _decodificar(buf: bytes) -> str:
    try:
        return buf.decode('utf-8')
    except UnicodeDecodeError:
        return buf.decode('iso-8859-1')


def importar_arquivos(arquivos, imp: dict, cancel: set, raizes: set):
    """arquivos: lista de (nome, bytes). Retorna o log da importação."""
    limpar_cache()
    log = novo_log()
    fila = list(arquivos)
    i = 0
    while i < len(fila):
        nome_arq, dados = fila[i]
        i += 1
        nome = nome_arq.lower()
        try:
            if nome.endswith('.zip'):
                with zipfile.ZipFile(io.BytesIO(dados)) as z:
                    for info in z.infolist():
                        if not info.is_dir() and re.search(r'\.(xml|pdf|zip|txt|csv)$', info.filename, re.I):
                            fila.append((info.filename.split('/')[-1], z.read(info)))
            elif nome.endswith('.pdf'):
                p = ler_pgdas(texto_pdf(dados))
                if not p:
                    log['erros'].append(f'{nome_arq}: não reconheci como declaração/extrato do PGDAS-D')
                elif p['raiz'] not in raizes:
                    log['semEmpresa'][p['raiz'] + ' (PGDAS)'] = 1
                else:
                    p['arquivo'] = nome_arq
                    imp.setdefault(p['raiz'], {'notas': {}, 'pgdas': {}})['pgdas'][p['pa']] = p
                    log['pgdas'].append(p)
                    log['raizes'].add(p['raiz'])
            elif nome.endswith('.txt') or nome.endswith('.csv'):
                txt = _decodificar(dados)
                if not ler_csv_sp(txt, nome_arq, imp, cancel, raizes, log) and not ler_txt_sp(txt, nome_arq, imp, cancel, raizes, log):
                    log['erros'].append(f'{nome_arq}: arquivo não reconhecido (esperado TXT ou CSV de exportação de NFS-e da Prefeitura de São Paulo)')
            elif nome.endswith('.xml'):
                processar_xml(dados, nome_arq, imp, cancel, raizes, log)
            else:
                log['ignorados'].append(nome_arq)
        except Exception as e:  # noqa: BLE001
            log['erros'].append(f'{nome_arq}: {e}')
    for r in log['raizes']:
        log['lacunas'] += lacunas((imp.get(r) or {}).get('notas', {}).values(), cancel)
    return log


def _de_chave(ch):
    """Chave de 44 dígitos → (cnpj, mod, série, número)."""
    ch = dig(ch)
    if len(ch) != 44:
        return None
    return ch[6:20], 'NFC-e' if ch[20:22] == '65' else 'NF-e', str(int(ch[22:25])), int(ch[25:34])


def lacunas(notas, cancel=(), mes=None):
    """Números que faltam na sequência de NF-e/NFC-e de cada emitente/série (entre o menor e o maior importado).
    Números com cancelamento conhecido (evento importado) não entram como falta."""
    grupos = {}
    for n in notas:
        if n.get('mod') not in ('NF-e', 'NFC-e') or n.get('dev') or not str(n.get('n') or '').isdigit():
            continue
        if mes and (n.get('d') or '')[:7] != mes:
            continue
        serie = str(int(n['serie'])) if str(n.get('serie') or '').isdigit() else (n.get('serie') or '?')
        grupos.setdefault((n['cnpj'], n['mod'], serie), set()).add(int(n['n']))
    conhecidos = {}
    for ch in cancel:
        x = _de_chave(ch)
        if x:
            conhecidos.setdefault(x[:3], set()).add(x[3])
    out = []
    for (cnpj, mod, serie), nums in grupos.items():
        if len(nums) < 2:
            continue
        falta = sorted(set(range(min(nums), max(nums) + 1)) - nums - conhecidos.get((cnpj, mod, serie), set()))
        if falta and len(falta) <= 500:
            out.append({'cnpj': cnpj, 'mod': mod, 'serie': serie, 'faltam': falta, 'de': min(nums), 'ate': max(nums)})
    return out





def xml_mes(imp_raiz, mes, cancel: set, uf: str = '', regras=None):
    """Soma das notas do mês, com os itens reclassificados pelo NCM (monofásico / ICMS-ST).
    Cache: só refaz quando notas, cancelamentos, compras, UF ou regras mudam.
    (Antes a chave usava o id() de um {} novo quando a empresa não tinha compras: o cache nunca
    acertava e cada validação relia todas as notas 13 vezes, travando a tela.)"""
    vazio = {'grupos': {}, 'total': 0.0, 'qtd': 0, 'notas': [], 'estab': {}, 'canceladas': [], 'ncm': {}, 'alertas': {}}
    if not imp_raiz:
        return vazio
    notas = imp_raiz.get('notas') or {}
    compras = imp_raiz.get('compras')
    k = (_GEN[0], id(notas), len(notas), id(cancel), len(cancel), id(compras) if compras else 0, len(compras or ()),
         mes, uf, _regras_chave(regras))
    c = _CACHE_XML.get(k)
    if c is None:
        if len(_CACHE_XML) > 60000:
            _CACHE_XML.clear()
        c = _CACHE_XML[k] = _xml_mes(imp_raiz, mes, cancel, uf, regras)
    return {'grupos': dict(c['grupos']), 'total': c['total'], 'qtd': c['qtd'], 'notas': list(c['notas']), 'estab': dict(c['estab']),
            'canceladas': list(c['canceladas']), 'ncm': c['ncm'], 'alertas': dict(c['alertas'])}


def _regras_chave(regras) -> str:
    if not regras:
        return ''
    import json as _j
    return _j.dumps(regras, sort_keys=True)


def _classificar_cache(it, uf, regras, compras, memo):
    """NCM.classificar com memória: o mesmo produto (NCM/CST/PIS/CEST) aparece em centenas de notas.
    Devolve (classificação, grupo, NCM limpo, CEST válido)."""
    k = (it.get('ncm'), it.get('cst'), it.get('pis'), it.get('cest'))
    x = memo.get(k) if memo is not None else None
    if x is None:
        cl = NCM.classificar(it, uf, regras, compras)
        x = (cl, NCM.grupo('merc', cl['st'], cl['mono']), ncm_limpo(it.get('ncm')) or '(sem NCM)', NCM.cest_valido(it.get('cest')))
        if memo is not None:
            memo[k] = x
    return x


def grupos_da_nota(n, uf='', regras=None, compras=None, acum=None, memo=None):
    """Grupos de receita da nota. Com itens gravados, cada item é reclassificado pelo NCM."""
    if not n.get('itens'):
        return n.get('p') or {}
    p = {}
    for it in n['itens']:
        v = it['v']
        if it.get('t') == 'merc':
            cl, g, k, cest = _classificar_cache(it, uf, regras, compras, memo)
        else:
            cl, g = None, it.get('t')
        p[g] = p.get(g, 0) + v
        if acum is not None and cl:
            a = acum['ncm'].get(k)
            if a is None:
                a = acum['ncm'][k] = {'ncm': k, 'x': it.get('x', ''), 'v': 0.0, 'qtd': 0, 'mono': cl['mono'], 'st': cl['st'],
                                      'mono_xml': cl['mono_xml'], 'st_xml': cl['st_xml'], 'f_mono': cl['f_mono'], 'f_st': cl['f_st'],
                                      'cest': cest, 'alertas': set()}
            a['v'] += v
            a['qtd'] += 1
            if cl['alertas']:
                a['alertas'].update(cl['alertas'])
                for al in cl['alertas']:
                    acum['alertas'][al] = acum['alertas'].get(al, 0) + v
    return {g: r2(v) for g, v in p.items()}


_CACHE_XML: dict = {}
_CACHE_IDX: dict = {}
_GEN = [0]          # muda a cada limpar_cache(): invalida tudo que foi calculado antes


def _notas_por_mes(notas: dict) -> dict:
    """Índice {AAAA-MM: [notas]} — cada mês percorre só as próprias notas (não todas, 13 vezes)."""
    k = (_GEN[0], id(notas), len(notas))
    idx = _CACHE_IDX.get(k)
    if idx is None:
        if len(_CACHE_IDX) > 20000:
            _CACHE_IDX.clear()
        idx = {}
        for n in notas.values():
            d = n.get('d')
            if d:
                idx.setdefault(d[:7], []).append(n)
        _CACHE_IDX[k] = idx
    return idx


def chave_cancel(n) -> str:
    """Chave usada no conjunto de cancelamentos para esta nota."""
    if n.get('mod') == 'NFS-e' and not str(n.get('ch') or '').isdigit():
        return nfse_n(n['cnpj'], n['n'])
    return n.get('ch')


def nota_cancelada(n, cancel: set) -> bool:
    return n.get('ch') in cancel or (n.get('mod') == 'NFS-e' and nfse_n(n['cnpj'], n['n']) in cancel)


def limpar_cache():
    _CACHE_XML.clear()
    _CACHE_IDX.clear()
    _GEN[0] += 1


def _xml_mes(imp_raiz, mes, cancel: set, uf='', regras=None):
    o = {'grupos': {}, 'total': 0.0, 'qtd': 0, 'notas': [], 'estab': {}, 'canceladas': [], 'ncm': {}, 'alertas': {}}
    compras = imp_raiz.get('compras') or {}
    memo = {}
    for n in _notas_por_mes(imp_raiz.get('notas') or {}).get(mes, ()):
        if n.get('semReceita'):
            continue
        if nota_cancelada(n, cancel):
            o['canceladas'].append(n)
            continue
        o['qtd'] += 1
        o['notas'].append(n)
        for g, v in grupos_da_nota(n, uf, regras, compras, o, memo).items():
            o['grupos'][g] = o['grupos'].get(g, 0) + v
            o['total'] += v
            o['estab'][n['cnpj']] = o['estab'].get(n['cnpj'], 0) + v
    o['grupos'] = {g: r2(v) for g, v in o['grupos'].items()}
    o['estab'] = {c: r2(v) for c, v in o['estab'].items()}
    o['total'] = r2(o['total'])
    for a in o['ncm'].values():
        a['v'] = r2(a['v'])
        a['alertas'] = sorted(a['alertas'])
    o['alertas'] = {k: r2(v) for k, v in o['alertas'].items()}
    return o


def meses_do_pgdas(imp_raiz, campo):
    h = {}
    if not imp_raiz or not imp_raiz.get('pgdas'):
        return h
    for pa in sorted(imp_raiz['pgdas']):
        h.update(imp_raiz['pgdas'][pa].get(campo) or {})
    if campo == 'hist':
        for pa, p in imp_raiz['pgdas'].items():
            if p.get('rpa') is not None and pa not in h:
                h[pa] = p['rpa']
    return h
