"""Regras de negócio do painel: montagem do caso, apuração, validações,
situação da competência, justificativas, trilha e lixeira.

É o equivalente aos "globais" do painel HTML, sem nenhuma dependência de tela.
"""
from __future__ import annotations

import re

from . import lp as LPM
from .importacao import GRUPOS, xml_mes, meses_do_pgdas, importar_arquivos, nfse_n
from .motor_sn import validar, projetar_prox, aliq_iss_retencao, ALIQ_RET_INICIO
from . import atividades as ATV

FOLHA_COMP = ('prov', 'fgts', 'inss')


def FOLHA_DET_TOTAL(d):
    """{'prov','fgts','inss'} digitados → (total, detalhe numérico) ou (None, None) se vazio."""
    if not isinstance(d, dict):
        return None, None
    det = {k: num(d.get(k)) for k in FOLHA_COMP}
    if all(v is None for v in det.values()):
        return None, None
    det = {k: (v or 0.0) for k, v in det.items()}
    return r2(sum(det.values())), det
from .regras_sn import regra_vigente, aliq_efetiva, ef_tributo
from .supabase_rest import Supabase, URL_PADRAO, CHAVE_PADRAO
from .util import (r2, num, brl, valN, pct, pctN, mes_add, meses_entre, nome_mes, data_br, data_hora,
                   agora_iso, dig, raiz_de, fmt_log, hash_str)

PARAM_PADRAO = {'tolerancia': 0.05, 'frAlerta': 0.31, 'subAlerta': 0.8, 'faixaAlerta': 0.1, 'metaFr': 0.29}
SEV_ROT = {'erro': 'ERRO', 'atencao': 'ATENÇÃO', 'ok': 'OK', 'na': 'N/A'}
ORD_SIT = {'erro': 0, 'alterada': 1, 'revisao': 2, 'pronta': 3, 'nao': 4, 'ressalva': 5, 'validada': 6}
GRP_SIT = {'erro': 'erro', 'alterada': 'erro', 'revisao': 'atencao', 'pronta': 'atencao', 'validada': 'validado',
           'ressalva': 'validado', 'nao': 'nao'}
ROT_SIT = {'erro': 'com erro', 'alterada': 'alterada(s) após validação', 'revisao': 'em revisão',
           'pronta': 'pronta(s) para validar', 'nao': 'não iniciada(s)', 'ressalva': 'validada(s) c/ ressalvas',
           'validada': 'validada(s)'}
REG_ROT = {'SN': 'Simples Nacional', 'LP': 'Lucro Presumido', 'OUTRO': 'Outro regime'}

CFG_CARTEIRA = {'tabela': 'companies', 'colId': 'id', 'colNome': 'razao_social', 'colCnpj': 'cnpj',
                'colRegime': 'regime_tributario', 'regimePadrao': 'Simples Nacional'}


def assinatura(x) -> str:
    return hash_str([x.get('sev'), x.get('esperado'), x.get('encontrado'), x.get('diferenca')])


class Validador:
    def __init__(self, estado):
        self.est = estado
        self.empresas: list = []
        self.comp: str = estado.cfg.get('comp') or ''
        self.sel: set = set(estado.cfg.get('sel') or [])
        self.atual = None
        self.RES, self.CHK, self.HASH = {}, {}, {}
        self.sb = Supabase(estado.cfg.get('url') or URL_PADRAO, estado.cfg.get('key') or CHAVE_PADRAO)
        estado.sb = self.sb
        CFG_CARTEIRA.update({k: v for k, v in (estado.cfg.get('carteira') or {}).items() if v})

    # ---------------- atalhos de estado ----------------
    @property
    def forms(self):
        return self.est.forms

    def salvar_forms(self):
        self.est.salvar('forms')

    def salvar_cfg(self):
        self.est.cfg['comp'] = self.comp
        self.est.cfg['sel'] = sorted(self.sel)
        self.est.gravar_cfg()

    def chave(self, id_, comp=None):
        return f'{comp or self.comp}|{id_}'

    def usuario(self):
        return self.sb.email if self.est.nuvem_on and self.sb.email else 'este computador'

    def uf_de(self, id_):
        e = self.emp(id_) or {}
        return str(e.get('uf') or '').upper()

    def regras_ncm(self):
        return (self.forms.get('ncm|global') or {}).get('regras') or []

    def param(self):
        return {**PARAM_PADRAO, **(self.forms.get('param|global') or {})}

    # ---------------- carteira ----------------
    def carregar_empresas(self):
        self.empresas = self.sb.selecionar_tudo(CFG_CARTEIRA['tabela'], '*', ordem=CFG_CARTEIRA['colNome'])
        self._idx = {str(e.get(CFG_CARTEIRA['colId'])): e for e in self.empresas}

    def emp(self, id_):
        if not hasattr(self, '_idx'):
            self._idx = {}
        return self._idx.get(str(id_))

    def nome(self, id_):
        e = self.emp(id_)
        return (e or {}).get(CFG_CARTEIRA['colNome']) or ''

    def cnpj(self, id_):
        e = self.emp(id_)
        return (e or {}).get(CFG_CARTEIRA['colCnpj']) or ''

    def ids_sel(self):
        return [i for i in self.sel if self.emp(i)]

    def raizes_carteira(self):
        return {raiz_de(e.get(CFG_CARTEIRA['colCnpj'])) for e in self.empresas if len(raiz_de(e.get(CFG_CARTEIRA['colCnpj']))) == 8}

    def import_de(self, id_):
        r = raiz_de(self.cnpj(id_))
        return r, self.est.imp.get(r)

    def nome_raiz(self, r):
        es = [e for e in self.empresas if raiz_de(e.get(CFG_CARTEIRA['colCnpj'])) == r]
        alvo = next((e for e in es if dig(e.get(CFG_CARTEIRA['colCnpj']))[8:12] == '0001'), es[0] if es else None)
        return (alvo or {}).get(CFG_CARTEIRA['colNome']) or ''

    def ids_raiz(self, r):
        return [str(e.get(CFG_CARTEIRA['colId'])) for e in self.empresas if raiz_de(e.get(CFG_CARTEIRA['colCnpj'])) == r]

    # ---------------- regime ----------------
    def regime_carteira(self, id_):
        v = str((self.emp(id_) or {}).get(CFG_CARTEIRA['colRegime']) or '').lower()
        if 'presumido' in v:
            return 'LP'
        if not v or re.search(r'simples|n[ãa]o definido', v):
            return 'SN'
        return 'OUTRO'

    def regime_de(self, id_):
        return (self.forms.get('empresa|' + str(id_)) or {}).get('regime') or self.regime_carteira(id_)

    def definir_regime(self, id_, novo):
        antes = self.regime_de(id_)
        cad = self.cad_emp(id_)
        if novo == self.regime_carteira(id_):
            cad.pop('regime', None)
        else:
            cad['regime'] = novo
        self._limpa_cad(id_)
        self.salvar_forms()
        self.registrar(id_, 'Regime alterado', campo='Regime tributário', de=REG_ROT.get(antes, antes), para=REG_ROT.get(novo, novo))
        self.apurar_caso(id_)

    # ---------------- formulários ----------------
    def cad_emp(self, id_):
        return self.forms.setdefault('empresa|' + str(id_), {})

    def _limpa_cad(self, id_):
        k = 'empresa|' + str(id_)
        if k in self.forms and not self.forms[k]:
            del self.forms[k]

    def data_carteira(self, id_):
        v = str(((self.emp(id_) or {}).get('metadata') or {}).get('data_abertura') or '').strip()
        m = re.match(r'^(\d{2})/(\d{2})/(\d{4})$', v)
        if m:
            return f'{m.group(3)}-{m.group(2)}-{m.group(1)}'
        m = re.match(r'^(\d{4})-(\d{2})-(\d{2})', v)
        return f'{m.group(1)}-{m.group(2)}-{m.group(3)}' if m else ''

    def inicio_emp(self, id_, pg=None):
        cad = (self.forms.get('empresa|' + str(id_)) or {}).get('inicio')
        if cad:
            return [cad, 'cadastro']
        dc = self.data_carteira(id_)
        if dc:
            return [dc, 'carteira']
        if pg and pg.get('aberturaData'):
            return [pg['aberturaData'], 'PGDAS-D']
        if pg and pg.get('abertura'):
            return [pg['abertura'], 'PGDAS-D']
        f = self.forms.get(self.chave(id_))
        if f and f.get('inicio'):
            return [f['inicio'], 'informado']
        return ['', '']

    def form(self, id_, comp=None):
        k = self.chave(id_, comp)
        if k not in self.forms:
            self.forms[k] = self.novo_form(id_, comp or self.comp)
        f = self.forms[k]
        # formulários vindos de backups de versões antigas do painel podem não ter todos os campos
        for campo, padrao in (('inicio', ''), ('rbt12', ''), ('acumulado', ''), ('folha12', ''), ('folhaMes', ''), ('dasInf', '')):
            if f.get(campo) is None:
                f[campo] = padrao
        for campo in ('hist', 'folha', 'folhaDet', 'anexoXml'):
            if not isinstance(f.get(campo), dict):
                f[campo] = {}
        if not isinstance(f.get('receitas'), list):
            f['receitas'] = []
        return f

    def novo_form(self, id_, c):
        dc = self.data_carteira(id_)
        f = {'inicio': dc[:7] if dc else '', 'rbt12': '', 'acumulado': '', 'folha12': '', 'folhaMes': '', 'dasInf': '',
             'receitas': [], 'hist': {}, 'folha': {}, 'folhaDet': {}, 'anexoXml': {}}
        ant = self.forms.get(mes_add(c, -1) + '|' + str(id_))
        if ant:
            f['inicio'] = ant.get('inicio') or f['inicio']
            f['anexoXml'] = dict(ant.get('anexoXml') or {})
        f['receitas'] = self.modelo_receitas(id_, c) or [{'descricao': '', 'anexo': 'I', 'valor': ''}]
        return f

    def modelo_receitas(self, id_, c):
        raiz, imp = self.import_de(id_)

        def limpa(r):
            return {'descricao': str(r.get('descricao') or '').replace('Declarado: ', '', 1)[:90], 'anexo': r.get('anexo'),
                    'icms_st': bool(r.get('icms_st')), 'monofasico': bool(r.get('monofasico')),
                    'iss_retido': bool(r.get('iss_retido')), 'exportacao': bool(r.get('exportacao')), 'valor': ''}
        for i in range(1, 13):
            m = mes_add(c, -i)
            ap = (self.est.apur.get(raiz) or {}).get(m)
            if ap and any(r.get('origem') != 'XML' for r in ap.get('receitas') or []):
                return [limpa(r) for r in ap['receitas'] if r.get('origem') != 'XML']
            pg = ((imp or {}).get('pgdas') or {}).get(m)
            if pg and pg.get('atividades'):
                return [limpa(a) for a in pg['atividades']]
        return []

    # ---------------- atividades (LC 123/2006, art. 18) ----------------
    def atividades(self, id_):
        """Códigos das atividades da empresa (a primeira é a principal). Vale para todas as competências."""
        return [c for c in (self.forms.get('empresa|' + str(id_)) or {}).get('atividades') or [] if c in ATV.ATIVIDADES]

    def definir_atividades(self, id_, cods):
        antes = self.atividades(id_)
        cad = self.cad_emp(id_)
        cods = [c for c in dict.fromkeys(cods) if c in ATV.ATIVIDADES]
        if cods:
            cad['atividades'] = cods
        else:
            cad.pop('atividades', None)
            self._limpa_cad(id_)
        self.salvar_forms()
        self.registrar(id_, 'Alteração', campo='Atividades (LC 123/2006)', de=fmt_log(', '.join(ATV.rotulo(c) for c in antes)),
                       para=fmt_log(', '.join(ATV.rotulo(c) for c in cods)))

    def anexo_padrao(self, id_, grupo_xml):
        """Anexo das receitas das notas pelo que a empresa faz: serviço → anexo da 1ª atividade de serviço; mercadoria → I ou II."""
        ats = self.atividades(id_)
        if grupo_xml.startswith('serv'):
            a = next((ATV.ATIVIDADES[c]['anexo'] for c in ats if ATV.ATIVIDADES[c]['anexo'] not in ('I', 'II')), None)
            return a or GRUPOS[grupo_xml]['anexo']
        if 'IND' in ats and 'COM' not in ats:
            return 'II'
        return GRUPOS[grupo_xml]['anexo']

    # ---------------- sócios e funcionários (folha por pessoa) ----------------
    ORIGEM_PESSOAS = 'sócios e funcionários'

    def pessoas(self, id_):
        """Cadastro da empresa (vale para todas as competências): [{'id','nome','tipo': 'socio'|'func','ativo'}]."""
        return (self.forms.get('empresa|' + str(id_)) or {}).get('pessoas') or []

    def folha_pessoas_mes(self, id_, m):
        """Soma da folha lançada por pessoa no mês (só quem está marcado para entrar) → (total, detalhe, linhas)."""
        cad = self.forms.get('empresa|' + str(id_)) or {}
        ativos = {p['id']: p for p in cad.get('pessoas') or [] if p.get('ativo', True)}
        lanc = (cad.get('folhaPessoas') or {}).get(m) or {}
        det, linhas = {k: 0.0 for k in FOLHA_COMP}, []
        for pid, d in lanc.items():
            p = ativos.get(pid)
            if not p:
                continue
            tot, dd = FOLHA_DET_TOTAL(d)
            if tot is None:
                continue
            for k in FOLHA_COMP:
                det[k] += dd[k]
            linhas.append({'id': pid, 'nome': p.get('nome') or '(sem nome)', 'tipo': p.get('tipo') or 'func', 'total': tot, **dd})
        if not linhas:
            return None, None, []
        det = {k: r2(v) for k, v in det.items()}
        return r2(sum(det.values())), det, linhas

    def pessoas_janela(self, id_, meses):
        """Folha de cada pessoa ativa somada nos meses dados (para o relatório do Fator R)."""
        acc = {}
        for p in self.pessoas(id_):
            if p.get('ativo', True):
                acc[p['id']] = {'nome': p.get('nome') or '(sem nome)', 'tipo': p.get('tipo') or 'func', 'meses': 0, 'por_mes': {},
                                **{k: 0.0 for k in FOLHA_COMP}, 'total': 0.0}
        for m in meses:
            _, _, linhas = self.folha_pessoas_mes(id_, m)
            for l in linhas:
                a = acc.get(l['id'])
                if not a:
                    continue
                for k in FOLHA_COMP + ('total',):
                    a[k] = r2(a[k] + l[k])
                a['meses'] += 1
                a['por_mes'][m] = l['total']
        return [a for a in acc.values()]

    # ---------------- folha (Fator R) ----------------
    def cpp_do_mes(self, id_, m, ap=None):
        """CPP (INSS patronal) da apuração do Simples Nacional feita pelo Validador para a competência m.

        Competência aberta: resultado atual; meses anteriores: apuração salva do mês. Sem apuração → None."""
        if m == self.comp:
            r = self.RES.get(self.chave(id_))
            return r2(r['tributos'].get('CPP') or 0) or None if r and r.get('regime', 'SN') == 'SN' else None
        if ap is None:
            raiz, _ = self.import_de(id_)
            ap = self.est.apur.get(raiz) or {}
        trib = ((ap.get(m) or {}).get('resultado') or {}).get('tributos') or {}
        v = trib.get('CPP')
        return r2(v) if v else None

    def folha_do_mes_cpp(self, id_, m, f=None, f_pg=None, ap=None, com_cpp=True):
        """Folha de salários com encargos de um mês, com o CPP da apuração do SN na coluna INSS/CPP.

        Retorna {'total', 'det', 'fonte', 'base', 'cpp', 'aceita_cpp'}:
        base = folha sem o CPP automático; cpp = CPP somado (None se não entrou); aceita_cpp = o mês admite o CPP
        automático (INSS/CPP não informado e folha vinda do PGDAS-D, de proventos/FGTS ou de sócios e funcionários).
        Total digitado como valor único é tratado como folha completa (não recebe CPP).
        Ordem da folha: sócios e funcionários → digitado nesta competência → PGDAS-D → apuração salva → digitado em outra competência.
        """
        c = self.comp
        f = f if f is not None else self.form(id_)
        if f_pg is None or ap is None:
            raiz, imp = self.import_de(id_)
            f_pg = meses_do_pgdas(imp, 'folha') if f_pg is None else f_pg
            ap = (self.est.apur.get(raiz) or {}) if ap is None else ap

        def so_inss(bruto):
            return isinstance(bruto, dict) and num(bruto.get('inss')) is not None and \
                num(bruto.get('prov')) is None and num(bruto.get('fgts')) is None

        def total_digitado(fx, pa):
            return num(fx.get('folhaMes')) if pa else num((fx.get('folha') or {}).get(m))

        def do_form(fx, pa):
            v = total_digitado(fx, pa)
            if v is not None:                        # total digitado manda (folha completa), mesmo com as partes preenchidas
                return v, None, False
            bruto = (fx.get('folhaDet') or {}).get(m)
            if so_inss(bruto):                       # só o INSS/CPP digitado: substitui o INSS da folha encontrada
                bruto = None
            tot, det = FOLHA_DET_TOTAL(bruto)
            if tot is not None:
                return tot, det, num((bruto or {}).get('inss')) is None
            v = num(fx.get('folhaMes')) if pa else num((fx.get('folha') or {}).get(m))
            return v, None, False

        def achar():
            v, det, _ = self.folha_pessoas_mes(id_, m)
            if v is not None:
                return v, det, self.ORIGEM_PESSOAS, not (det or {}).get('inss')
            v, det, ok = do_form(f, m == c)
            if v is not None:
                return v, det, 'manual', ok
            if m in f_pg:
                return f_pg[m], None, 'PGDAS-D', True
            a = ap.get(m) or {}
            if a.get('folhaMes') is not None:
                det = a.get('folhaDet') or None
                return a['folhaMes'], det, 'apurações salvas', bool(det) and not det.get('inss')
            for j in range(0, 13):
                cj = mes_add(m, j)
                if cj == c:
                    continue
                fx = self.forms.get(f'{cj}|{id_}')
                if fx:
                    v, det, ok = do_form(fx, j == 0)
                    if v is not None:
                        return v, det, 'digitado em ' + nome_mes(cj), ok
            return None, None, '', False
        v, det, fonte, aceita = achar()
        base_sem_inss = None if v is None else r2(v - ((det or {}).get('inss') or 0))
        out = {'total': v, 'det': det, 'fonte': fonte, 'base': v, 'base_sem_inss': base_sem_inss, 'cpp': None,
               'aceita_cpp': bool(aceita and v is not None), 'inss_digitado': None}
        bruto = (f.get('folhaDet') or {}).get(m)
        if so_inss(bruto) and fonte != self.ORIGEM_PESSOAS and total_digitado(f, m == c) is None:
            inss = num(bruto['inss'])
            d = dict(det) if det else {'prov': None, 'fgts': None}
            d['inss'] = inss
            out.update(total=r2((base_sem_inss or 0) + inss), det=d, fonte=fonte or 'manual', aceita_cpp=False, inss_digitado=inss)
            return out
        if com_cpp and out['aceita_cpp']:
            cpp = self.cpp_do_mes(id_, m, ap)
            if cpp:
                d = dict(det) if det else {'prov': None, 'fgts': None}
                d['inss'] = cpp
                out.update(total=r2(v + cpp), det=d, cpp=cpp)
        return out

    def folha_do_mes(self, id_, m, f=None, f_pg=None, ap=None):
        """Folha de salários com encargos de um mês → (total, detalhe, origem). Já inclui o CPP da apuração do SN quando cabível."""
        x = self.folha_do_mes_cpp(id_, m, f, f_pg, ap)
        return x['total'], x['det'], x['fonte']

    # ---------------- caso SN ----------------
    def montar_caso(self, id_):
        f = self.form(id_)
        c = self.comp
        raiz, imp = self.import_de(id_)
        ap = self.est.apur.get(raiz) or {}
        pg = ((imp or {}).get('pgdas') or {}).get(c)
        h_pg, f_pg = meses_do_pgdas(imp, 'hist'), meses_do_pgdas(imp, 'folha')
        pg_ab = pg if (pg and pg.get('abertura')) else next((x for x in ((imp or {}).get('pgdas') or {}).values() if x and x.get('abertura')), None)
        hist, origem = {}, {}
        for i in range(1, 13):
            m = mes_add(c, -i)
            if num(f['hist'].get(m)) is not None:
                hist[m] = num(f['hist'][m])
                origem[m] = 'manual'
            elif m in h_pg:
                hist[m] = h_pg[m]
                origem[m] = 'PGDAS'
            elif (ap.get(m) or {}).get('rpa') is not None:
                hist[m] = ap[m]['rpa']
                origem[m] = 'Apuração salva'
            else:
                x = xml_mes(imp, m, self.est.cancel, self.uf_de(id_), self.regras_ncm())
                if x['qtd']:
                    hist[m] = x['total']
                    origem[m] = 'XML'
        folha12, origem_folha, folha_meses, folha_det = None, '', {}, {}
        cpp_meses, cpp_faltam = {}, []
        tem_mes = any(num(v) is not None for v in (f.get('folha') or {}).values()) or \
            any(m != c and FOLHA_DET_TOTAL(d)[0] is not None for m, d in (f.get('folhaDet') or {}).items())
        if num(f.get('folha12')) is not None and not tem_mes:
            folha12 = num(f['folha12'])
            origem_folha = 'manual (total)'
        else:
            s, n, fontes = 0, 0, []
            for i in range(1, 13):
                m = mes_add(c, -i)
                x = self.folha_do_mes_cpp(id_, m, f, f_pg, ap)
                v, det, fonte = x['total'], x['det'], x['fonte']
                if x['cpp']:
                    cpp_meses[m] = x['cpp']
                elif x['aceita_cpp']:
                    cpp_faltam.append(m)
                if v is None:
                    continue
                folha_meses[m] = v
                if det:
                    folha_det[m] = det
                fontes.append(fonte)
                s += v
                n += 1
            if n:
                folha12 = r2(s)
                origem_folha = ' + '.join(dict.fromkeys(fontes)) + f' ({n} meses)'
        # folha do próprio PA: entra na janela do Fator R da competência seguinte
        x_pa = self.folha_do_mes_cpp(id_, c, f, f_pg, ap, com_cpp=False)     # CPP do PA entra depois de apurar o mês
        folha_mes, det_pa, origem_fm = x_pa['total'], x_pa['det'], x_pa['fonte']
        if det_pa:
            folha_det[c] = det_pa
        x = xml_mes(imp, c, self.est.cancel, self.uf_de(id_), self.regras_ncm())
        receitas_xml = []
        for g, v in x['grupos'].items():
            if v > 0:
                d = GRUPOS[g]
                receitas_xml.append({**d, 'descricao': d['rot'], 'anexo': (f.get('anexoXml') or {}).get(g) or self.anexo_padrao(id_, g),
                                     'valor': v, 'origem': 'XML'})
        manuais = []
        for r in f['receitas']:
            if (num(r.get('valor')) or 0) <= 0:
                continue
            rec = {**r, 'valor': num(r.get('valor')), 'origem': 'manual'}
            atv = ATV.ATIVIDADES.get(r.get('atividade'))
            if atv:                                # a atividade (LC 123) define o anexo
                rec['anexo'] = atv['anexo']
                rec['descricao'] = r.get('descricao') or atv['nome']
            manuais.append(rec)
        declaradas = []
        if not receitas_xml and not manuais and pg and pg.get('atividades'):
            for a in pg['atividades']:
                declaradas.append({'anexo': a['anexo'], 'icms_st': a.get('icms_st'), 'monofasico': a.get('monofasico'),
                                   'iss_retido': a.get('iss_retido'), 'exportacao': a.get('exportacao'), 'valor': a['valor'],
                                   'origem': 'PGDAS-D', 'descricao': 'Declarado: ' + re.sub(r'\s*-\s*', ' – ', a['descricao'], count=1)[:90]})
        das_manual = num(f.get('dasInf'))
        ini = self.inicio_emp(id_, pg_ab)
        rb = num(f.get('rbt12'))
        return {
            '_id': str(id_),
            'competencia': c, 'atividades': [{'cod': k, 'nome': ATV.rotulo(k), 'anexo': ATV.ATIVIDADES[k]['anexo'], 'regra': ATV.regra_texto(k)}
                                             for k in self.atividades(id_)],
            'hist': hist, 'origemHist': origem, 'rbt12': rb if rb is not None else (pg or {}).get('rbt12'),
            'acumulado_ano': None if hist else num(f.get('acumulado')), 'folha_12m': folha12, 'origemFolha': origem_folha,
            'folhaMeses': folha_meses, 'folhaDet': folha_det, 'folha_mes': folha_mes, 'origemFolhaMes': origem_fm,
            'folha_mes_base': folha_mes, 'rpa_fr': num(f.get('rpaFR')), '_pa_aceita_cpp': x_pa['aceita_cpp'], 'cppMeses': cpp_meses, 'cppFaltam': cpp_faltam,
            'inicio_atividade': (ini[0] or '')[:7] or None, '_inicio': ini,
            '_pgAbertura': (pg_ab or {}).get('abertura'),
            'das_informado': das_manual if das_manual is not None else ((pg or {}).get('das') or {}).get('total'),
            'das_por_tributo': ((pg or {}).get('das') or {}).get('por') if das_manual is None else None,
            'rpa_declarada': (pg or {}).get('rpa'), 'receitas': receitas_xml + manuais + declaradas, '_xml': x, '_pg': pg,
        }

    def hash_caso(self, caso):
        return hash_str([caso['competencia'], caso['hist'],
                         [[r.get('descricao'), r.get('anexo'), r.get('valor'), bool(r.get('icms_st')), bool(r.get('monofasico')),
                           bool(r.get('iss_retido')), bool(r.get('exportacao'))] for r in caso['receitas']],
                         caso['rbt12'], caso['folha_12m'], caso['das_informado'], caso['rpa_declarada'], caso['inicio_atividade']])

    def apurar_caso(self, id_, caso=None):
        reg = self.regime_de(id_)
        k = self.chave(id_)
        if reg == 'LP':
            return LPM.apurar_caso(self, id_)
        if reg == 'OUTRO':
            for d in (self.RES, self.CHK, self.HASH):
                d.pop(k, None)
            return None
        caso = caso or self.montar_caso(id_)
        if not caso['receitas']:
            for d in (self.RES, self.CHK, self.HASH):
                d.pop(k, None)
            return None
        r = validar(caso, self.param()['tolerancia'])
        self._cpp_no_pa(caso, r)
        try:
            r['prox'] = projetar_prox(r, caso)
        except Exception as e:  # noqa: BLE001 — a projeção nunca pode impedir a apuração do mês
            print('erro ao projetar PA seguinte', id_, e)
            r['prox'] = None
        self.RES[k] = r
        self.CHK[k] = self.checagens(r, caso)
        self.HASH[k] = self.hash_caso(caso)
        return r

    @staticmethod
    def _cpp_no_pa(caso, r):
        """Soma o CPP apurado no próprio PA à folha do PA (entra na janela do Fator R da competência seguinte)."""
        c = caso['competencia']
        cpp = r2((r.get('tributos') or {}).get('CPP') or 0)
        caso['folha_mes'] = caso.get('folha_mes_base')
        if caso.get('_pa_aceita_cpp') and caso['folha_mes'] is not None and cpp:
            caso['folha_mes'] = r2(caso['folha_mes'] + cpp)
            d = dict((caso.get('folhaDet') or {}).get(c) or {'prov': None, 'fgts': None})
            d['inss'] = cpp
            caso.setdefault('folhaDet', {})[c] = d
            caso.setdefault('cppMeses', {})[c] = cpp
        m = r.setdefault('memo', {})
        m['folha_mes'] = caso['folha_mes']
        m['folhaDet'] = dict(caso.get('folhaDet') or {})
        m['cppMeses'] = dict(caso.get('cppMeses') or {})
        m['cppFaltam'] = list(caso.get('cppFaltam') or [])

    def validar_ids(self, ids):
        n = 0
        for i in ids:
            try:
                if self.apurar_caso(i):
                    n += 1
            except Exception as e:  # noqa: BLE001
                print('erro ao apurar', i, e)
        return n

    def res(self, id_):
        return self.RES.get(self.chave(id_))

    # ---------------- checagens SN ----------------
    @staticmethod
    def _origens_receita(caso):
        o = {}
        for r in caso['receitas']:
            k = r.get('origem') or 'manual'
            o[k] = r2(o.get(k, 0) + r['valor'])
        return ' + '.join(f'{k} {valN(v)}' for k, v in o.items())

    def checagens(self, r, caso):
        P = self.param()
        R = regra_vigente(caso['competencia'])
        FRM = R['fatorRMin']
        m = r['memo']
        c = caso['competencia']
        L = []
        aliq_med = r['total_calculado'] / r['rpa'] if r['rpa'] else 0

        def add(**o):
            base = {'esperado': None, 'encontrado': None, 'diferenca': None, 'impacto': None, 'origem': '', 'causa': '', 'acao': None}
            base.update(o)
            L.append(base)
        sem_decl = {'das_informado': None, 'das_por_tributo': None, 'rpa_declarada': None}

        # 1. Receita do mês × RPA declarada
        t1 = 'Receita do mês × RPA declarada no PGDAS-D'
        if m['rpa_declarada'] is not None:
            d = r2(m['rpa_declarada'] - r['rpa'])
            err = abs(d) > 0.01
            add(id='REC-PGDAS', cat='Receita', titulo=t1, sev='erro' if err else 'ok', esperado=r['rpa'], encontrado=m['rpa_declarada'],
                diferenca=d, impacto=r2(abs(d) * aliq_med) if err else 0,
                origem='Sistema: ' + self._origens_receita(caso) + ' · Declarado: PGDAS-D importado',
                causa='' if not err else ('Há receita no sistema que não foi declarada: nota de outra competência, cancelamento sem o evento importado ou operação que não é venda.'
                                          if d < 0 else 'Falta receita no sistema: documento não importado, nota emitida por outro sistema ou estabelecimento, ou receita declarada sem documento.'),
                acao=['Ver documentos', '1'] if err else None)
        else:
            add(id='REC-PGDAS', cat='Receita', titulo=t1, sev='na', esperado=r['rpa'], resumo='PGDAS-D não importado',
                causa='Sem declaração da competência para confrontar. Se o PGDAS-D ainda não foi transmitido, use os valores do sistema.',
                acao=['Importar PGDAS-D', 'importar'])

        # 2. Meses do RBT12
        if m['mesesRbt']:
            falt = [x for x in m['mesesRbt'] if x not in m['hist']]
            fontes = {}
            for x in m['mesesRbt']:
                o = m['origemHist'].get(x)
                if o:
                    fontes[o] = fontes.get(o, 0) + 1
            add(id='RBT12-MESES', cat='RBT12', titulo=f"Receita dos {len(m['mesesRbt'])} meses que formam o RBT12", sev='erro' if falt else 'ok',
                rotEsp='Necessário', rotEnc='Com dado', esperado=f"{len(m['mesesRbt'])} meses", encontrado=f"{len(m['mesesRbt']) - len(falt)} meses",
                resumo=('Faltam ' + ', '.join(nome_mes(x) for x in falt)) if falt else 'Completo',
                origem=' · '.join(f'{k}: {v}' for k, v in fontes.items()),
                causa='Meses sem PGDAS-D, sem apuração salva e sem XML entram como zero: o RBT12 fica menor e a faixa pode estar errada.' if falt else '',
                acao=['Completar meses' if falt else 'Ver meses', '3'])
        elif r['origem_rbt12'] == 'Não informado':
            add(id='RBT12-MESES', cat='RBT12', titulo='RBT12', sev='erro', resumo='Não informado',
                causa='Sem histórico nem RBT12 informado o cálculo usa a 1ª faixa.', acao=['Informar RBT12', '3'])
        else:
            add(id='RBT12-MESES', cat='RBT12', titulo='RBT12', sev='ok', rotEnc='RBT12', encontrado=r['rbt12'], resumo=r['origem_rbt12'],
                origem=r['origem_rbt12'], acao=['Ver meses', '3'])

        # 3. RBT12 declarado × soma
        if m['rbt12_informado'] is not None and m['mesesRbt'] and all(x in m['hist'] for x in m['mesesRbt']):
            d = r2(m['rbt12_informado'] - r['rbt12'])
            err = abs(d) > 0.01
            impacto = 0
            if err:
                alt = validar({**caso, **sem_decl, 'hist': {}, 'rbt12': m['rbt12_informado'], 'acumulado_ano': r2(r['rba_ano'] - r['rpa'])})
                impacto = r2(abs(alt['total_calculado'] - r['total_calculado']))
            add(id='RBT12-DECL', cat='RBT12', titulo='RBT12 declarado × soma dos meses', sev='erro' if err else 'ok', esperado=r['rbt12'],
                encontrado=m['rbt12_informado'], diferenca=d, impacto=impacto, origem='Sistema: soma mês a mês · Declarado: PGDAS-D ou valor informado',
                causa='Mês retificado depois da declaração, estabelecimento não somado ou histórico digitado diferente. Impacto = DAS pelo RBT12 declarado × pelo recalculado.' if err else '',
                acao=['Comparar meses', '3'])

        # 4. DAS
        if r['das_informado'] is not None:
            div = [x[0] for x in r['comparacao'] if not x[4]]
            err = r['status'] == 'DIVERGENTE'
            if not err:
                causa = ''
            elif not div:
                causa = 'Total diferente com os tributos conferindo: arredondamento, multa/juros somados ou DAS de outra competência.'
            elif all(t == 'ICMS' for t in div):
                causa = 'Só o ICMS diverge: segregação de ICMS-ST (CSOSN 500) ou anexo da atividade.'
            elif all(t in ('PIS', 'COFINS') for t in div):
                causa = 'Só PIS/Cofins divergem: segregação de produtos monofásicos.'
            elif all(t == 'ISS' for t in div):
                causa = 'Só o ISS diverge: ISS retido ou município da prestação.'
            else:
                causa = 'Vários tributos divergem: receita, RBT12/faixa, anexo ou Fator R diferentes entre o sistema e a declaração.'
            add(id='DAS-PGDAS', cat='DAS', titulo='DAS recalculado × DAS declarado', sev='erro' if err else 'ok', esperado=r['total_calculado'],
                encontrado=r['das_informado'], diferenca=r['diferenca'], impacto=(abs(r['diferenca'] or 0) or None) if err else 0,
                resumo=('Diverge em ' + ', '.join(div)) if err and div else None,
                origem='Por tributo, do PGDAS-D importado' if r['comparacao'] else 'Total informado', causa=causa,
                acao=['Ver composição', 'aba:apuracao'])
        else:
            add(id='DAS-PGDAS', cat='DAS', titulo='DAS recalculado × DAS declarado', sev='na', esperado=r['total_calculado'], resumo='Sem DAS declarado',
                causa='Informe o DAS declarado ou importe o PGDAS-D para conferir.', acao=['Ver composição', 'aba:apuracao'])

        # 5. Limites
        uso = r['rba_ano'] / m['sublimite'] if m['sublimite'] else 0
        sev_lim = 'erro' if (r['rba_ano'] > m['limite'] or r['rbt12'] > R['limite']) else ('atencao' if (r['rba_ano'] > m['sublimite'] or uso >= P['subAlerta']) else 'ok')
        add(id='LIMITES', cat='Enquadramento', titulo='Limite e sublimite no ano', sev=sev_lim, rotEsp='Sublimite', rotEnc='Receita no ano',
            esperado=m['sublimite'], encontrado=r['rba_ano'], resumo=f'{pctN(uso, 0)} do sublimite',
            origem=f"Receita acumulada no ano, incluindo o PA · limite {valN(m['limite'])}",
            causa=('Receita acima do limite do Simples: avaliar exclusão e efeitos (LC 123/2006, art. 3º, §§ 9º a 12).' if sev_lim == 'erro'
                   else ('Sublimite ultrapassado: ICMS/ISS passam a ser apurados fora do DAS (no próprio mês se o excesso passar de 20%).' if r['rba_ano'] > m['sublimite']
                         else 'Receita perto do sublimite estadual/municipal: acompanhar os próximos meses.') if sev_lim == 'atencao' else ''),
            acao=['Simular', 'sim'] if sev_lim != 'ok' else None)

        # 6. Fator R
        it_fr = [it for it in r['itens'] if it['anexoOrig'] == 'FATOR_R']
        if it_fr:
            rec_fr = sum(it['valor'] for it in it_fr)
            eco = r2(rec_fr * (aliq_efetiva('V', r['rbt12'], R) - aliq_efetiva('III', r['rbt12'], R)))
            fr = r['fator_r']
            sev_fr = 'erro' if fr is None else ('atencao' if fr < P['frAlerta'] else 'ok')
            add(id='FATOR-R', cat='Fator R', titulo='Fator R e anexo das atividades de serviço', sev=sev_fr, rotEsp='Mínimo', rotEnc='Apurado',
                esperado=f'{pctN(FRM, 0)} (Anexo III)', encontrado='sem folha' if fr is None else f"{pctN(fr)} → Anexo {'III' if fr >= FRM else 'V'}",
                impacto=0 if sev_fr == 'ok' else eco,
                resumo='Folha não informada' if fr is None else ('Tributando no Anexo V' if fr < FRM else ('Próximo do mínimo' if fr < P['frAlerta'] else 'Anexo III')),
                origem='Folha: ' + (m['origemFolha'] or '—'),
                causa=('Sem folha dos 12 meses o sistema tributa pelo Anexo V. Impacto = diferença entre Anexo V e III no mês.' if fr is None
                       else f'Folha abaixo de 28% da receita: o DAS fica {valN(eco)} maior do que no Anexo III. Veja no simulador a folha necessária.' if fr < FRM
                       else f'Margem pequena: queda de folha ou alta de receita leva ao Anexo V ({valN(eco)}/mês a mais).' if fr < P['frAlerta'] else ''),
                acao=['Lançar folha', '3'] if fr is None else ['Simular folha', 'sim'])
            n_f = len(m['folhaMeses'] or {})
            n_esp = min(12, len(m['mesesRbt']) or 12)
            if fr is not None and n_f and n_f < n_esp:
                add(id='FOLHA-MESES', cat='Fator R', titulo='Folha dos meses anteriores', sev='atencao', rotEsp='Necessário', rotEnc='Com dado',
                    esperado=f'{n_esp} meses', encontrado=f'{n_f} meses', causa='Meses sem folha entram como zero e reduzem o Fator R.', acao=['Completar folha', '3'])

        # 7. Faixa e Fator R na próxima competência (janelas móveis de receita e de folha)
        px = r.get('prox') or projetar_prox(r, caso)
        prox = px['pa']
        alt = {'faixa': px['faixa'], 'rbt12': px['rbt12'], 'total_calculado': px['das']}

        if it_fr:
            fr2 = px['fator_r']
            fr1 = r['fator_r']
            an1 = None if fr1 is None else ('III' if fr1 >= FRM else 'V')
            an2 = px['anexoFR']
            frm2 = px['fatorRMin']
            eco2 = r2(rec_fr * (aliq_efetiva('V', px['rbt12'], R) - aliq_efetiva('III', px['rbt12'], R)))
            est = ' (folha do mês estimada)' if px['folha_estimada'] else ''
            if fr2 is None:
                sev2, res2 = 'na', 'Sem folha para projetar'
            elif fr2 < frm2:
                sev2 = 'atencao'
                res2 = ('Passa para o Anexo V' if an1 == 'III' else 'Continua no Anexo V') + est
            elif fr2 < P['frAlerta']:
                sev2, res2 = 'atencao', ('Volta ao Anexo III, perto do mínimo' if an1 == 'V' else 'Anexo III, perto do mínimo') + est
            else:
                sev2, res2 = 'ok', ('Volta ao Anexo III' if an1 == 'V' else 'Mantém o Anexo III') + est
            orig2 = (f"Folha 12m projetada {valN(px['folha_12m'])} (entra {nome_mes(c)}: {valN(px['folha_mes'])}"
                     f"{' — ' + px['origemFolhaMes'] if px['origemFolhaMes'] else ''}; sai {nome_mes(px['mes_sai'])}"
                     f"{': ' + valN(px['folha_sai']) if px['folha_sai'] is not None else ''})"
                     f"{' → anualizada ' + valN(px['folha_anual']) if px.get('folha_anual') is not None and abs(px['folha_anual'] - (px['folha_12m'] or 0)) > 0.01 else ''}"
                     f" ÷ RBT12 projetado {valN(px['rbt12'])}"
                     ) if fr2 is not None else 'Folha: —'
            fmin = px['folha_min_mes']
            dica = (f" Folha mínima de {nome_mes(c)} para manter {pctN(frm2, 0)} em {nome_mes(prox)}: {valN(fmin)}." if fmin is not None else '')
            if fr2 is None:
                causa2 = 'Lance a folha dos 12 meses e a folha do mês para projetar o Fator R da próxima competência.'
            elif fr2 < frm2:
                causa2 = (f"Com a folha de {nome_mes(c)} entrando e a de {nome_mes(px['mes_sai'])} saindo, o Fator R de {nome_mes(prox)} fica abaixo de "
                          f"{pctN(frm2, 0)}: DAS cerca de {valN(eco2)} maior do que no Anexo III, mantida a receita.{dica}")
            elif fr2 < P['frAlerta']:
                causa2 = f'Margem pequena em {nome_mes(prox)}: queda de folha ou alta de receita leva ao Anexo V.{dica}'
            else:
                causa2 = dica.strip()
            if px['folha_estimada'] and fr2 is not None:
                causa2 = (causa2 + ' ' if causa2 else '') + f"Folha de {nome_mes(c)} não informada: {px['origemFolhaMes']}. Informe a folha do mês para projetar com precisão."
            add(id='FATOR-R-PROX', cat='Fator R', titulo=f'Fator R em {nome_mes(prox)}', sev=sev2, rotEsp='Atual', rotEnc='Projetado',
                esperado='—' if fr1 is None else f"{pctN(fr1)} → Anexo {an1}",
                encontrado='sem folha' if fr2 is None else f"{pctN(fr2)} → Anexo {an2}",
                impacto=eco2 if (fr2 is not None and fr2 < frm2) else 0, resumo=res2, origem=orig2, causa=causa2,
                acao=['Lançar folha', '3'] if (fr2 is None or px['folha_estimada']) else ['Simular folha', 'sim'])

        teto = R['tetos'][r['faixa'] - 1]
        dist = (teto - r['rbt12']) / teto if teto else 1
        if alt['faixa'] != r['faixa']:
            d = r2(alt['total_calculado'] - r['total_calculado'])
            sobe = alt['faixa'] > r['faixa']
            add(id='FAIXA-PROX', cat='Enquadramento', titulo=f'Faixa em {nome_mes(prox)}', sev='atencao' if sobe else 'ok', rotEsp='Atual', rotEnc='Próxima',
                esperado=f"{r['faixa']}ª faixa", encontrado=f"{alt['faixa']}ª faixa", impacto=abs(d) if sobe else 0,
                resumo=f"{'Sobe' if sobe else 'Desce'} para a {alt['faixa']}ª faixa",
                origem=f"RBT12 projetado {valN(alt['rbt12'])} (entra {nome_mes(c)}, sai {nome_mes(mes_add(c, -12))})",
                causa=f"Com a mesma receita deste mês{' e o Fator R projetado' if it_fr else ''}, o DAS de {nome_mes(prox)} fica {valN(abs(d))} {'maior' if d >= 0 else 'menor'}.", acao=['Simular', 'sim'])
        elif 0 <= dist < P['faixaAlerta'] and r['faixa'] < 6:
            add(id='FAIXA-PROX', cat='Enquadramento', titulo='Proximidade do teto da faixa', sev='atencao', rotEsp='Teto da faixa', rotEnc='RBT12',
                esperado=teto, encontrado=r['rbt12'], resumo=f"{pctN(dist, 1)} abaixo do teto da {r['faixa']}ª faixa",
                causa='Pequeno aumento de receita muda a faixa nos próximos meses.', acao=['Simular', 'sim'])
        else:
            add(id='FAIXA-PROX', cat='Enquadramento', titulo='Faixa na próxima competência', sev='ok', rotEnc='Próxima', encontrado=f"{alt['faixa']}ª faixa",
                resumo=f"Mantém a {alt['faixa']}ª faixa em {nome_mes(prox)}")

        # 8. Segregações notas × declaração
        x, pg = caso['_xml'], caso['_pg']
        if x and x['qtd'] and pg and pg.get('atividades'):
            segs = [('icms_st', 'ICMS-ST', ef_tributo('I', r['rbt12'], 'ICMS', R), 'Produto com CSOSN 500/CST 60 nas notas não declarado como substituição tributária (ou o inverso).'),
                    ('monofasico', 'PIS/Cofins monofásico', ef_tributo('I', r['rbt12'], 'PIS', R) + ef_tributo('I', r['rbt12'], 'COFINS', R), 'CST 04/05 de PIS/Cofins nas notas diferente do declarado como monofásico.'),
                    ('iss_retido', 'ISS retido', aliq_iss_retencao(self._anexo_iss(r), r['rbt12'], R), 'NFS-e com ISS retido pelo tomador não declarada com retenção (ou o inverso).')]
            for fl, rot, ef, causa in segs:
                nx = r2(sum(v for g, v in x['grupos'].items() if GRUPOS[g].get(fl)))
                np_ = r2(sum(a['valor'] for a in pg['atividades'] if a.get(fl)))
                if not nx and not np_:
                    continue
                d = r2(np_ - nx)
                err = abs(d) > 0.01
                add(id='SEG-' + fl.upper(), cat='Segregação', titulo=f'Segregação de {rot}: notas × PGDAS-D', sev='atencao' if err else 'ok', rotEsp='Notas',
                    esperado=nx, encontrado=np_, diferenca=d, impacto=r2(abs(d) * ef) if err else 0,
                    origem='Notas: XML importados · Declarado: atividades do PGDAS-D', causa=causa if err else '', acao=['Ver documentos', '1'])

        # 8a. ISS retido nas NFS-e × alíquota devida (LC 123/2006, art. 21, § 4º)
        self._check_iss_retido(r, caso, add, R)

        # 8b. Produtos pelo NCM (monofásico / ICMS-ST)
        if x and x.get('ncm'):
            from . import ncm as NCMM
            NCMM.checks(x.get('alertas') or {}, x['ncm'], add,
                        ef_tributo('I', r['rbt12'], 'PIS', R) + ef_tributo('I', r['rbt12'], 'COFINS', R), ef_tributo('I', r['rbt12'], 'ICMS', R))

        # 8c. Atividade × anexo das receitas (LC 123/2006, art. 18)
        ats = caso.get('atividades') or []
        if not ats:
            add(id='ATIVIDADE', cat='Cadastro', titulo='Atividade da empresa (LC 123/2006)', sev='na', resumo='Não cadastrada',
                causa='Cadastre a atividade (ex.: medicina veterinária) para o sistema conferir o anexo e o Fator R pela LC 123/2006, art. 18.',
                acao=['Definir atividade', '2'])
        else:
            esp = {a['anexo'] for a in ats}
            fora = [it for it in r['itens'] if it['anexoOrig'] not in esp]
            rot_esp = ', '.join(sorted({'III/V (Fator R)' if a == 'FATOR_R' else a for a in esp}))
            if fora:
                add(id='ATIVIDADE', cat='Cadastro', titulo='Anexo das receitas × atividade da empresa', sev='atencao', rotEsp='Atividade', rotEnc='Receitas',
                    esperado=rot_esp, encontrado=', '.join(sorted({'III/V' if it['anexoOrig'] == 'FATOR_R' else it['anexoOrig'] for it in fora})),
                    impacto=None, resumo=f"{len(fora)} receita(s) fora do anexo da atividade",
                    origem=' · '.join(f"{a['nome']}: {a['regra']}" for a in ats),
                    causa='Receita lançada em anexo diferente do previsto para as atividades cadastradas: '
                          + '; '.join(f"{it['descricao']} ({'III/V' if it['anexoOrig'] == 'FATOR_R' else it['anexoOrig']})" for it in fora)
                          + '. Confira a atividade da receita ou o cadastro.', acao=['Ver receitas', '2'])
            else:
                add(id='ATIVIDADE', cat='Cadastro', titulo='Anexo das receitas × atividade da empresa', sev='ok', rotEnc='Atividade',
                    encontrado=ats[0]['nome'][:60], resumo=ats[0]['regra'], origem=' · '.join(f"{a['nome']}: {a['regra']}" for a in ats))

        # 9. Início
        ini = (caso.get('_inicio') or [''])[0]
        if ini:
            ini_mes = ini[:7]
            if c < ini_mes:
                add(id='INICIO', cat='Cadastro', titulo='Início das atividades', sev='erro', rotEsp='Início', rotEnc='Competência', esperado=nome_mes(ini_mes),
                    encontrado=nome_mes(c), causa='Competência anterior ao início: confira a data de abertura ou a competência selecionada.', acao=['Conferir início', '3'])
            elif caso.get('_pgAbertura') and caso['_pgAbertura'] != ini_mes:
                add(id='INICIO', cat='Cadastro', titulo='Início das atividades × PGDAS-D', sev='atencao', rotEsp='Cadastro', rotEnc='PGDAS-D',
                    esperado=nome_mes(ini_mes), encontrado=nome_mes(caso['_pgAbertura']),
                    causa='Abertura diferente entre o cadastro e o PGDAS-D: muda a proporcionalização do RBT12 no início.', acao=['Conferir início', '3'])
            else:
                add(id='INICIO', cat='Cadastro', titulo='Início das atividades', sev='ok', rotEnc='Início', encontrado=data_br(ini),
                    resumo=f"{data_br(ini)} ({caso['_inicio'][1]})")

        if r['faixa'] == 6:
            add(id='FAIXA-6', cat='Enquadramento', titulo='6ª faixa', sev='atencao', causa='ICMS/ISS fora do DAS: apurar pelo regime normal.')

        cobertos = re.compile(r'^RBT12 informado|^Histórico incompleto|^Informe o RBT12|^Receita do mês|^Diferença por tributo|^DAS informado|Receita acumulada no ano|^RBT12 \(|6ª faixa|sem folha lançada|anterior ao início')
        for i, a in enumerate([a for a in r['alertas'] if a[0] != 'info' and not cobertos.search(a[1])]):
            add(id=f'MOTOR-{i}', cat='Cálculo', titulo=a[1], sev='erro' if a[0] == 'erro' else 'atencao')

        add(id='CALC', cat='Cálculo', titulo='Cálculo por anexo, faixa e repartição', sev='ok', rotEnc='DAS', encontrado=r['total_calculado'],
            resumo=f"{len(r['itens'])} receita(s) · regra {r['regra']['versao']}", origem=r['regra']['origem'], acao=['Memória de cálculo', 'aba:memoria'])
        return L

    # ---------------- situação / revisão ----------------
    def rev_de(self, id_):
        return (self.forms.get(self.chave(id_)) or {}).get('rev') or {}

    def just_de(self, id_, x):
        j = (self.rev_de(id_).get('just') or {}).get(x['id'])
        return j if j and j.get('assin') == assinatura(x) else None

    def pendente(self, id_, x):
        return x['sev'] in ('erro', 'atencao') and not self.just_de(id_, x)

    # ---------------- ISS retido (LC 123/2006, art. 21, § 4º) ----------------
    @staticmethod
    def _anexo_iss(r):
        """Anexo (já resolvido pelo Fator R) das receitas de serviço com ISS retido; senão o 1º anexo com ISS."""
        its = [it for it in r.get('itens') or [] if it['anexo'] in ('III', 'IV', 'V')]
        ret = [it for it in its if it.get('aliqIss') is not None]
        return (ret or its or [{'anexo': 'III'}])[0]['anexo']

    def rbt12_mes_anterior(self, caso):
        """RBT12 do mês anterior ao da prestação (faixa que define a alíquota de retenção do ISS).
        Janela = PA−13 … PA−2. Retorna (rbt12, origem, inicio) — inicio=True quando o PA é o mês de início de atividade."""
        c = caso['competencia']
        ant = mes_add(c, -1)
        ini = caso.get('inicio_atividade')
        if ini and meses_entre(ini, c) <= 0:
            return None, 'mês de início de atividade', True
        hist = caso.get('hist') or {}
        h_ant = {m: v for m, v in hist.items() if m != ant}
        m13 = mes_add(c, -13)
        v13 = self._receita_mes_avulsa(caso, m13)
        if v13 is not None:
            h_ant[m13] = v13
        if not hist:
            if caso.get('rbt12') is not None:
                return caso['rbt12'], 'estimado pelo RBT12 do mês (sem histórico mês a mês)', False
            return None, 'sem histórico', False
        rpa_ant = hist.get(ant, 0) or 0
        x = validar({'competencia': ant, 'hist': h_ant, 'rbt12': None, 'acumulado_ano': None, 'inicio_atividade': ini,
                     'receitas': [{'descricao': 'PA anterior', 'anexo': 'III', 'valor': rpa_ant}]})
        falta = [m for m in [mes_add(ant, -i) for i in range(1, 13)] if m not in h_ant and (not ini or m >= ini)]
        orig = x['origem_rbt12'] + f' de {nome_mes(ant)}' + (f" (sem receita de {', '.join(nome_mes(m) for m in sorted(falta))}: considerada zero)" if falta else '')
        return x['rbt12'], orig, False

    def _receita_mes_avulsa(self, caso, m):
        """Receita de um mês fora da janela do RBT12 (PA−13): PGDAS-D, apuração salva ou XML."""
        id_ = caso.get('_id')
        if not id_:
            return None
        raiz, imp = self.import_de(id_)
        h_pg = meses_do_pgdas(imp, 'hist')
        if m in h_pg:
            return h_pg[m]
        ap = (self.est.apur.get(raiz) or {}).get(m) or {}
        if ap.get('rpa') is not None:
            return ap['rpa']
        x = xml_mes(imp, m, self.est.cancel, self.uf_de(id_), self.regras_ncm())
        return x['total'] if x['qtd'] else None

    @staticmethod
    def _iss_da_nota(n):
        """(alíquota % informada, ISS retido informado) da NFS-e — None quando a nota não traz o dado."""
        i = n.get('iss') or {}
        if not i and (n.get('sp') or {}).get('aliq') is not None:          # TXT de SP importado em versão anterior
            i = {'aliq': n['sp'].get('aliq'), 'v': n['sp'].get('iss')}
        a = i.get('aliq') or None
        v = i.get('v') or None
        return a, v

    def _check_iss_retido(self, r, caso, add, R):
        x = caso.get('_xml') or {}
        notas = [n for n in x.get('notas') or [] if (n.get('p') or {}).get('serv_ret')]
        ir = r.get('iss_retido')
        if not notas and not ir:
            return
        anexo = self._anexo_iss(r)
        rb_ant, orig, inicio = self.rbt12_mes_anterior(caso)
        if inicio:
            aliq = ALIQ_RET_INICIO
            fonte = 'mês de início de atividade: menor percentual de ISS dos Anexos III, IV e V (LC 123/2006, art. 21, § 4º, II)'
        elif rb_ant is not None:
            aliq = aliq_iss_retencao(anexo, rb_ant, R)
            fonte = f"% do ISS na repartição do Anexo {anexo}, faixa do RBT12 de {nome_mes(mes_add(caso['competencia'], -1))} ({valN(rb_ant)}) — {orig}"
        else:
            aliq = aliq_iss_retencao(anexo, r['rbt12'], R)
            fonte = f'sem histórico do mês anterior: estimada pelo RBT12 do mês ({valN(r["rbt12"])})'
        base_das = (ir or {}).get('base') or 0
        ded = (ir or {}).get('valor') or 0
        aliq_das = ded / base_das if base_das else aliq_iss_retencao(anexo, r['rbt12'], R)
        # dedução no DAS
        add(id='ISS-RET-DAS', cat='ISS retido', titulo='ISS retido deduzido do DAS', sev='ok' if ir else 'na', rotEsp='Base retida', rotEnc='Deduzido',
            esperado=base_das or None, encontrado=ded or None,
            resumo=(f"{valN(base_das)} × {pctN(aliq_das, 4)} = {valN(ded)} fora do DAS" if ir else 'Sem receita marcada com ISS retido'),
            origem=f'Alíquota efetiva × % do ISS na repartição (Anexo {anexo}, {r["faixa"]}ª faixa{", limitado a 5%" if aliq_das >= R["tetoIss"] - 1e-12 else ""}). '
                   'IRPJ, CSLL, Cofins, PIS e CPP continuam no DAS.',
            causa='' if ir else 'Há NFS-e com ISS retido no mês, mas nenhuma receita do cálculo está marcada como retida.',
            acao=None if ir else ['Ver receitas', '2'])
        if not notas:
            return
        # conferência nota a nota
        abaixo, acima, sem, ok = [], [], [], []
        dif_mun = exc = 0.0
        for n in notas:
            v = n['p']['serv_ret']
            a, vi = self._iss_da_nota(n)
            dev = r2(v * aliq)
            if not a and not vi:
                sem.append(n)
                continue
            a_ef = (a / 100) if a else (vi / v if v else 0)
            ret = vi if vi else r2(v * a_ef)
            d = r2(dev - ret)
            # tolerância: alíquota com 2 casas na nota (2,59% para 2,5856%) não é divergência
            tol = 0.00006 if a else max(0.00006, 0.011 / v if v else 0)
            if a_ef < aliq - tol and d > 0.01:
                abaixo.append((n, a_ef, ret, dev))
                dif_mun = r2(dif_mun + d)
            elif a_ef > aliq + tol and d < -0.01:
                acima.append((n, a_ef, ret, dev))
                exc = r2(exc - d)
            else:
                ok.append(n)
        base = r2(sum(n['p']['serv_ret'] for n in notas))
        devido = r2(base * aliq)

        def lista(L):
            return '; '.join(f"NFS-e {n.get('n')} ({pctN(a, 2)} → {valN(ret)}, devido {valN(dv)})" for n, a, ret, dv in L[:12]) + ('…' if len(L) > 12 else '')
        if abaixo:
            add(id='ISS-RET-ALIQ', cat='ISS retido', titulo='Alíquota de ISS retido nas NFS-e', sev='atencao', rotEsp='Alíquota devida', rotEnc='Retido a menor',
                esperado=f'{pctN(aliq, 2)}', encontrado=f'{len(abaixo)} nota(s)', diferenca=dif_mun, impacto=dif_mun,
                resumo=f'{len(abaixo)} nota(s) com alíquota abaixo de {pctN(aliq, 2)}: diferença de {valN(dif_mun)} ao município',
                origem=f'Alíquota devida {pctN(aliq, 4)}: ' + fonte,
                causa=('Alíquota informada na nota menor que a devida: a diferença é recolhida pelo prestador em guia do próprio município, '
                       'fora do DAS (LC 123/2006, art. 21, § 4º, VI). ' + lista(abaixo)), acao=['Ver documentos', '1'])
        elif acima:
            add(id='ISS-RET-ALIQ', cat='ISS retido', titulo='Alíquota de ISS retido nas NFS-e', sev='atencao', rotEsp='Alíquota devida', rotEnc='Retido a maior',
                esperado=f'{pctN(aliq, 2)}', encontrado=f'{len(acima)} nota(s)', diferenca=r2(-exc), impacto=0,
                resumo=f'{len(acima)} nota(s) com alíquota acima de {pctN(aliq, 2)}: {valN(exc)} retido a mais',
                origem=f'Alíquota devida {pctN(aliq, 4)}: ' + fonte,
                causa=('O excesso retido não é compensado no DAS: confira a alíquota informada no emissor da NFS-e para as próximas notas; '
                       'a devolução do que foi retido a mais é pedida ao município. ' + lista(acima)), acao=['Ver documentos', '1'])
        elif sem and not ok:
            add(id='ISS-RET-ALIQ', cat='ISS retido', titulo='Alíquota de ISS retido nas NFS-e', sev='na', rotEsp='Alíquota devida',
                esperado=f'{pctN(aliq, 2)}', resumo=f'Notas sem alíquota no arquivo · reter {pctN(aliq, 2)} = {valN(devido)}',
                origem=f'Alíquota devida {pctN(aliq, 4)}: ' + fonte,
                causa=('O arquivo importado não traz a alíquota nem o valor do ISS. Confira na NFS-e: a alíquota informada deve ser '
                       f'{pctN(aliq, 2)}; sem alíquota na nota o tomador retém 5% (LC 123/2006, art. 21, § 4º, V).'))
        else:
            add(id='ISS-RET-ALIQ', cat='ISS retido', titulo='Alíquota de ISS retido nas NFS-e', sev='ok', rotEsp='Alíquota devida', rotEnc='Retido',
                esperado=f'{pctN(aliq, 2)}', encontrado=f'{len(ok)} nota(s)',
                resumo=f'{len(ok)} nota(s) retidas a {pctN(aliq, 2)}' + (f' · {len(sem)} sem alíquota no arquivo' if sem else ''),
                origem='Alíquota devida: ' + fonte)

    def situacao(self, id_):
        k = self.chave(id_)
        r = self.RES.get(k)
        ch = self.CHK.get(k) or []
        b = {'erros': 0, 'alertas': 0, 'pendErros': 0, 'pendAlert': 0, 'aprov': 0, 'just': 0, 'total': 0, 'prog': 0}
        if not r:
            return {**b, 'cod': 'nao', 'rot': 'Não iniciada', 'cls': 'neutro'}
        for x in ch:
            if x['sev'] == 'na':
                continue
            b['total'] += 1
            if x['sev'] == 'ok':
                b['aprov'] += 1
                continue
            if x['sev'] == 'erro':
                b['erros'] += 1
            else:
                b['alertas'] += 1
            if self.just_de(id_, x):
                b['just'] += 1
            elif x['sev'] == 'erro':
                b['pendErros'] += 1
            else:
                b['pendAlert'] += 1
        b['prog'] = (b['aprov'] + b['just']) / b['total'] if b['total'] else 0
        v = self.rev_de(id_).get('validada')
        if v and v.get('hash') == self.HASH.get(k):
            return {**b, 'v': v, 'cod': 'ressalva' if b['just'] else 'validada', 'rot': 'Validada c/ ressalvas' if b['just'] else 'Validada', 'cls': 'ok'}
        if v:
            return {**b, 'v': v, 'cod': 'alterada', 'rot': 'Alterada após validação', 'cls': 'erro'}
        if b['pendErros']:
            return {**b, 'cod': 'erro', 'rot': 'Com erro', 'cls': 'erro'}
        if b['pendAlert']:
            return {**b, 'cod': 'revisao', 'rot': 'Em revisão', 'cls': 'atencao'}
        return {**b, 'cod': 'pronta', 'rot': 'Pronta para validar', 'cls': 'info'}

    @staticmethod
    def travada(s):
        return s['cod'] in ('validada', 'ressalva')

    def justificar(self, id_, xid, texto):
        x = next((y for y in self.CHK.get(self.chave(id_)) or [] if y['id'] == xid), None)
        if not x:
            return 'Validação não encontrada.'
        texto = str(texto or '').strip()
        if x['sev'] == 'erro' and len(texto) < 10:
            return 'Erro crítico: descreva a justificativa (mínimo 10 caracteres).'
        rev = self.form(id_).setdefault('rev', {})
        rev.setdefault('just', {})[xid] = {'texto': texto, 'sev': x['sev'], 'assin': assinatura(x), 'por': self.usuario(), 'em': agora_iso(), 'titulo': x['titulo']}
        self.salvar_forms()
        self.registrar(id_, 'Divergência justificada' if x['sev'] == 'erro' else 'Alerta revisado', campo=x['titulo'], para=texto or 'revisado')
        return None

    def desfazer_just(self, id_, xid):
        rev = self.form(id_).get('rev') or {}
        if xid not in (rev.get('just') or {}):
            return
        t = rev['just'][xid].get('titulo')
        del rev['just'][xid]
        self.salvar_forms()
        self.registrar(id_, 'Justificativa removida', campo=t)

    def concluir_validacao(self, id_):
        r = self.apurar_caso(id_)
        if not r:
            return 'Lance as receitas antes de validar.'
        s = self.situacao(id_)
        k = self.chave(id_)
        if s['pendErros'] or s['pendAlert']:
            return f"Resolva {s['pendErros']} erro(s) e {s['pendAlert']} alerta(s) antes de concluir."
        f = self.form(id_)
        por, em = self.usuario(), agora_iso()
        validacao = {'em': em, 'por': por, 'regra': r['regra']['versao'], 'hash': self.HASH[k], 'ressalvas': s['just'],
                     'just': dict((f.get('rev') or {}).get('just') or {}),
                     'checks': [{kk: x.get(kk) for kk in ('id', 'cat', 'titulo', 'sev', 'esperado', 'encontrado', 'diferenca', 'impacto')} for x in self.CHK[k]]}
        f.setdefault('rev', {})['validada'] = {'em': em, 'por': por, 'hash': self.HASH[k], 'regra': r['regra']['versao']}
        self.salvar_forms()
        self.salvar_apuracao(id_, {'validacao': validacao})
        self.registrar(id_, 'Competência validada', para=f"com {s['just']} ressalva(s)" if s['just'] else 'sem ressalvas')
        return None

    def reabrir(self, id_):
        f = self.form(id_)
        if f.get('rev'):
            f['rev'].pop('validada', None)
        self.salvar_forms()
        ap = self.apur_salva(id_)
        if ap and ap.get('validacao'):
            del ap['validacao']
            self.est.salvar('apur')
        self.registrar(id_, 'Competência reaberta')

    # ---------------- apurações salvas ----------------
    def apur_salva(self, id_):
        raiz, _ = self.import_de(id_)
        return (self.est.apur.get(raiz) or {}).get(self.comp)

    def salvar_apuracao(self, id_, extra=None):
        if self.regime_de(id_) == 'LP':
            return LPM.salvar(self, id_, extra)
        caso = self.montar_caso(id_)
        if not caso['receitas']:
            return 'Informe as receitas do mês antes de salvar.'
        r = self.apurar_caso(id_, caso)
        raiz, _ = self.import_de(id_)
        f = self.form(id_)
        self.est.apur.setdefault(raiz, {})[caso['competencia']] = {
            'salvoEm': agora_iso(), 'empresa': self.nome(id_), 'cnpj': self.cnpj(id_), 'rpa': r['rpa'], 'folhaMes': caso.get('folha_mes') if caso.get('origemFolhaMes') == 'manual' else num(f.get('folhaMes')),
            'folhaDet': (caso.get('folhaDet') or {}).get(caso['competencia']) if caso.get('origemFolhaMes') == 'manual' else None,
            'cppNaFolha': (caso.get('cppMeses') or {}).get(caso['competencia']),
            'receitas': [{'descricao': x.get('descricao'), 'anexo': x.get('anexo'), 'valor': x.get('valor'), 'origem': x.get('origem'),
                          'icms_st': bool(x.get('icms_st')), 'monofasico': bool(x.get('monofasico')), 'iss_retido': bool(x.get('iss_retido')),
                          'exportacao': bool(x.get('exportacao'))} for x in caso['receitas']],
            'regra': r['regra']['versao'], 'resultado': _limpo(r), **(extra or {})}
        self.est.salvar('apur')
        if not extra:
            self.registrar(id_, 'Apuração salva', para=brl(r['total_calculado']))
        return None

    # ---------------- trilha ----------------
    def registrar_raiz(self, raiz, acao, **det):
        lst = self.est.log.setdefault(raiz or 'geral', [])
        lst.append({'em': agora_iso(), 'por': self.usuario(), 'comp': self.comp, 'acao': acao, **{k: v for k, v in det.items() if v is not None}})
        if len(lst) > 800:
            del lst[:-800]
        self.est.salvar('log')

    def registrar(self, id_, acao, **det):
        raiz, _ = self.import_de(id_)
        self.registrar_raiz(raiz or 'geral', acao, empresa=self.nome(id_), **det)

    def trilha(self, id_, so_comp=True):
        raiz, _ = self.import_de(id_)
        L = [x for x in self.est.log.get(raiz) or [] if not so_comp or x.get('comp') == self.comp]
        return list(reversed(L[-200:]))

    # ---------------- carteira (visão geral) ----------------
    def linhas_carteira(self):
        out = []
        for id_ in self.ids_sel():
            k = self.chave(id_)
            s = self.situacao(id_)
            r = self.RES.get(k)
            pend = [x for x in self.CHK.get(k) or [] if self.pendente(id_, x)]
            pend.sort(key=lambda x: (0 if x['sev'] == 'erro' else 1, -(x.get('impacto') or 0)))
            out.append({'id': id_, 'nome': self.nome(id_), 'cnpj': self.cnpj(id_), 's': s, 'r': r, 'pend': pend,
                        'imp': r2(sum(x.get('impacto') or 0 for x in pend))})
        out.sort(key=lambda l: (ORD_SIT[l['s']['cod']], -l['imp'], l['nome']))
        return out

    def proxima_pendente(self):
        L = self.linhas_carteira()
        alvo = next((l for l in L if l['s']['cod'] in ('erro', 'alterada', 'revisao', 'pronta')), None) or next((l for l in L if l['s']['cod'] == 'nao'), None)
        return alvo

    # ---------------- importação ----------------
    def importar(self, arquivos):
        return self.concluir_importacao(*self.ler_importacao(arquivos))

    def ler_importacao(self, arquivos):
        """(Pode rodar numa thread) Lê os arquivos sobre CÓPIAS das importações, sem mexer no estado da tela."""
        imp = {r: {**v, 'notas': dict(v.get('notas') or {}), 'pgdas': dict(v.get('pgdas') or {}), 'compras': dict(v.get('compras') or {})}
               for r, v in self.est.imp.items()}
        cancel = set(self.est.cancel)
        log = importar_arquivos(arquivos, imp, cancel, self.raizes_carteira())
        return log, imp, cancel

    def concluir_importacao(self, log, imp, cancel):
        """(Thread da interface) Troca as importações pelas novas e recalcula."""
        from .importacao import limpar_cache
        self.est.imp, self.est.cancel = imp, cancel
        limpar_cache()
        self.est.salvar('imp', 'cancel')
        for r in log['raizes']:
            self.registrar_raiz(r, 'Importação de arquivos', para=f"lote: {log['nfe']} NF-e/NFC-e, {log['nfse']} NFS-e, {len(log['pgdas'])} PGDAS-D")
            es = [e for e in self.empresas if raiz_de(e.get(CFG_CARTEIRA['colCnpj'])) == r]
            alvo = next((e for e in es if dig(e.get(CFG_CARTEIRA['colCnpj']))[8:12] == '0001'), es[0] if es else None)
            if alvo:
                self.sel.add(str(alvo[CFG_CARTEIRA['colId']]))
        self.salvar_cfg()
        self.validar_ids(list(self.sel))
        return log

    def marcar_cancelada(self, id_, nota, cancelar=True):
        """Marca/desmarca manualmente uma nota como cancelada (fica fora do cálculo)."""
        return self.marcar_canceladas(id_, [nota], cancelar)

    def marcar_canceladas(self, id_, notas, cancelar=True, apurar=True):
        """Marca/desmarca várias notas de uma vez (um único recálculo e um único registro na trilha)."""
        from .importacao import chave_cancel, nfse_n, limpar_cache
        notas = [n for n in notas if n]
        if not notas:
            return 0
        tot = 0.0
        for nota in notas:
            if cancelar:
                self.est.cancel.add(chave_cancel(nota))
            else:
                chaves = {nota.get('ch'), chave_cancel(nota)}
                if nota.get('mod') == 'NFS-e':
                    chaves.add(nfse_n(nota['cnpj'], nota['n']))
                chaves.discard(None)
                self.est.cancel.difference_update(chaves)
            tot += sum((nota.get('p') or {}).values())
        limpar_cache()
        self.est.salvar('cancel')
        if len(notas) == 1:
            campo = f"{notas[0].get('mod')} {notas[0].get('n')}"
        else:
            campo = f"{len(notas)} notas: " + ', '.join(str(n.get('n')) for n in notas[:20]) + ('…' if len(notas) > 20 else '')
        self.registrar(id_, ('Nota marcada como cancelada' if cancelar else 'Cancelamento da nota desfeito') if len(notas) == 1
                       else ('Notas marcadas como canceladas' if cancelar else 'Cancelamento das notas desfeito'),
                       campo=campo, para=valN(r2(tot)))
        if apurar:
            self.apurar_caso(id_)
        return len(notas)

    def excluir_notas(self, id_, notas):
        """Exclui das importações as notas indicadas (some da lista; importe de novo se precisar)."""
        from .importacao import limpar_cache
        raiz, imp = self.import_de(id_)
        if not imp or not notas:
            return 0
        ids = {id(n) for n in notas}
        ks = {n.get('k') for n in notas if n.get('k')}
        tot, n_ex = 0.0, 0
        for k in [k for k, v in (imp.get('notas') or {}).items() if id(v) in ids or k in ks]:
            v = imp['notas'].pop(k)
            tot += sum((v.get('p') or {}).values())
            n_ex += 1
        if not imp.get('notas') and not imp.get('pgdas'):
            self.est.imp.pop(raiz, None)
        limpar_cache()
        self.est.salvar('imp')
        self.RES.clear()
        if n_ex:
            self.registrar(id_, 'Notas importadas excluídas', campo=f'{n_ex} nota(s)', para=valN(r2(tot)))
        self.apurar_caso(id_)
        return n_ex

    def remover_imports(self, id_):
        from .importacao import limpar_cache
        raiz, _ = self.import_de(id_)
        self.est.imp.pop(raiz, None)
        limpar_cache()
        self.est.salvar('imp')
        self.RES.clear()
        self.registrar(id_, 'Arquivos removidos')

    def resumo_import(self, raiz):
        """Quanto há importado para a raiz do CNPJ (matriz + filiais)."""
        imp = self.est.imp.get(raiz) or {}
        notas = (imp.get('notas') or {}).values()
        nfse = sum(1 for n in notas if n.get('mod') == 'NFS-e')
        comps = {(n.get('d') or '')[:7] or 'sem data' for n in notas} | set(imp.get('pgdas') or {})
        return {'notas': len(imp.get('notas') or {}), 'nfse': nfse, 'nfe': len(imp.get('notas') or {}) - nfse,
                'pgdas': len(imp.get('pgdas') or {}), 'compras': len(imp.get('compras') or {}), 'comps': comps}

    def excluir_import_raizes(self, raizes, oque='tudo', comps=None):
        """Exclui os dados importados de várias empresas (por raiz do CNPJ).
        comps=None → todas as competências. oque: 'tudo', 'notas' ou 'pgdas'.
        As apurações salvas não são afetadas. Retorna (notas, pgdas, empresas)."""
        from .importacao import limpar_cache
        nN = nP = nE = 0
        lista = []
        for raiz in raizes:
            imp = self.est.imp.get(raiz)
            if not imp:
                continue
            if comps is None and oque == 'tudo':
                a, b = len(imp.get('notas') or {}), len(imp.get('pgdas') or {})
                del self.est.imp[raiz]
                self.registrar_raiz(raiz, 'Dados importados excluídos', empresa=self.nome_raiz(raiz), campo='todas as competências',
                                    para=' + '.join(x for x in [f'{a} nota(s)' if a else '', f'{b} PGDAS-D' if b else ''] if x) or 'dados auxiliares')
                nN += a
                nP += b
                nE += 1
            else:
                cs = self.resumo_import(raiz)['comps'] if comps is None else set(comps)
                lista += [(raiz, m) for m in cs]
        if lista:
            antes = set(self.est.imp)
            a, b = self.excluir_import(lista, oque)
            nN += a
            nP += b
            nE += len({r for r, _ in lista} & antes)
        else:
            limpar_cache()
            self.est.salvar('imp')
            self.RES.clear()
            self.validar_ids(list(self.sel))
        return nN, nP, nE

    # ---------------- lixeira ----------------
    def lixo(self):
        return self.forms.setdefault('lixeira|global', {'itens': []})

    def apagar_apuracoes(self, lista):
        n = 0
        it = self.lixo()['itens']
        agora = agora_iso()
        for raiz, c in lista:
            a = (self.est.apur.get(raiz) or {}).get(c)
            if not a:
                continue
            it.insert(0, {'id': f'{raiz}|{c}|{agora}|{n}', 'raiz': raiz, 'comp': c, 'dados': a, 'em': agora, 'por': self.usuario()})
            del self.est.apur[raiz][c]
            if not self.est.apur[raiz]:
                del self.est.apur[raiz]
            for id_ in self.ids_raiz(raiz):
                f = self.forms.get(c + '|' + id_)
                if f and (f.get('rev') or {}).get('validada'):
                    del f['rev']['validada']
            self.registrar_raiz(raiz, 'Apuração movida para a lixeira', empresa=a.get('empresa') or self.nome_raiz(raiz), campo=nome_mes(c),
                                para=brl(a['resultado']['total_calculado']) if a.get('resultado') else '')
            n += 1
        del it[300:]
        self.est.salvar('apur', 'forms')
        self.RES.clear()
        self.validar_ids(list(self.sel))
        return n

    def restaurar_lixo(self, ids, substituir=lambda x: True):
        L = self.lixo()
        n = pulou = 0
        for id_ in ids:
            i = next((j for j, x in enumerate(L['itens']) if x['id'] == id_), None)
            if i is None:
                continue
            x = L['itens'][i]
            if (self.est.apur.get(x['raiz']) or {}).get(x['comp']) and not substituir(x):
                pulou += 1
                continue
            self.est.apur.setdefault(x['raiz'], {})[x['comp']] = x['dados']
            v = x['dados'].get('validacao')
            if v:
                for eid in self.ids_raiz(x['raiz']):
                    f = self.forms.get(x['comp'] + '|' + eid)
                    if f:
                        f.setdefault('rev', {})['validada'] = {'em': v['em'], 'por': v['por'], 'hash': v['hash'], 'regra': v['regra']}
            self.registrar_raiz(x['raiz'], 'Apuração restaurada da lixeira', empresa=x['dados'].get('empresa') or self.nome_raiz(x['raiz']), campo=nome_mes(x['comp']))
            L['itens'].pop(i)
            n += 1
        self.est.salvar('apur', 'forms')
        self.RES.clear()
        self.validar_ids(list(self.sel))
        return n, pulou

    def excluir_lixo(self, ids):
        L = self.lixo()
        s = set(ids)
        for x in [x for x in L['itens'] if x['id'] in s]:
            self.registrar_raiz(x['raiz'], 'Apuração excluída definitivamente', empresa=x['dados'].get('empresa') or self.nome_raiz(x['raiz']), campo=nome_mes(x['comp']))
        antes = len(L['itens'])
        L['itens'] = [x for x in L['itens'] if x['id'] not in s]
        self.salvar_forms()
        return antes - len(L['itens'])

    def linhas_import(self):
        out = []
        for raiz, imp in self.est.imp.items():
            meses = {}
            for n in (imp.get('notas') or {}).values():
                m = (n.get('d') or '')[:7] or 'sem data'
                o = meses.setdefault(m, {'qtd': 0, 'total': 0.0, 'nfe': 0, 'nfse': 0})
                o['qtd'] += 1
                if n.get('mod') == 'NFS-e':
                    o['nfse'] += 1
                else:
                    o['nfe'] += 1
                o['total'] = r2(o['total'] + sum((n.get('p') or {}).values()))
            for pa in (imp.get('pgdas') or {}):
                meses.setdefault(pa, {'qtd': 0, 'total': 0.0, 'nfe': 0, 'nfse': 0})
            cn = next((e.get(CFG_CARTEIRA['colCnpj']) for e in self.empresas if raiz_de(e.get(CFG_CARTEIRA['colCnpj'])) == raiz), raiz)
            for m, o in meses.items():
                out.append({'id': f'{raiz}|{m}', 'raiz': raiz, 'comp': m, 'nome': self.nome_raiz(raiz), 'cnpj': cn, **o,
                            'pg': (imp.get('pgdas') or {}).get(m)})
        return out

    def excluir_import(self, lista, oque='tudo'):
        from .importacao import limpar_cache
        limpar_cache()
        nN = nP = 0
        for raiz, m in lista:
            imp = self.est.imp.get(raiz)
            if not imp:
                continue
            a = b = 0
            if oque != 'pgdas':
                for k in [k for k, n in (imp.get('notas') or {}).items() if ((n.get('d') or '')[:7] or 'sem data') == m]:
                    del imp['notas'][k]
                    a += 1
            if oque != 'notas' and m in (imp.get('pgdas') or {}):
                del imp['pgdas'][m]
                b += 1
            if not imp.get('notas') and not imp.get('pgdas'):
                del self.est.imp[raiz]
            if a or b:
                self.registrar_raiz(raiz, 'Dados importados excluídos', empresa=self.nome_raiz(raiz), campo=m if m == 'sem data' else nome_mes(m),
                                    para=' + '.join(x for x in [f'{a} nota(s)' if a else '', 'PGDAS-D' if b else ''] if x))
            nN += a
            nP += b
        self.est.salvar('imp')
        self.RES.clear()
        self.validar_ids(list(self.sel))
        return nN, nP


def _limpo(r):
    """Cópia serializável do resultado (sem conjuntos)."""
    import json
    return json.loads(json.dumps(r, default=list))
