"""Motor de cálculo do Simples Nacional — LC 123/2006 (LC 155/2016), Res. CGSN 140/2018."""
from __future__ import annotations

from .regras_sn import SEG, ORDEM, regra_vigente, faixa_de
from .util import r2, brl, pct, mes_add, meses_entre, nome_mes


def validar(caso: dict, tol: float = 0.05) -> dict:
    R = regra_vigente(caso.get('competencia'))
    TETOS, LIMITE, TETO_ISS, FATOR_R_MIN = R['tetos'], R['limite'], R['tetoIss'], R['fatorRMin']
    NOMINAIS, TRIBUTOS, REPARTICAO = R['nominais'], R['tributos'], R['reparticao']
    alertas = []
    comp = caso['competencia']
    hist = dict(caso.get('hist') or {})
    receitas = caso.get('receitas') or []
    rpa = sum(float(r['valor']) for r in receitas)

    faltam, meses_rbt = [], []
    inicio = caso.get('inicio_atividade')
    n = meses_entre(inicio, comp) if inicio else None
    tem_hist = len(hist) > 0
    if n is not None and n < 0:
        alertas.append(['erro', f'Competência {comp} anterior ao início de atividade ({inicio}).'])
    if n is not None and n <= 0:
        rbt12 = rpa * 12
        origem = 'Início de atividade: RPA × 12'
    elif tem_hist:
        qtd = n if (n is not None and n < 12) else 12
        ms = [mes_add(comp, -i) for i in range(1, qtd + 1)]
        meses_rbt = list(reversed(ms))
        faltam = [m for m in ms if m not in hist]
        soma = sum(hist.get(m, 0) or 0 for m in ms)
        rbt12 = soma / qtd * 12 if qtd < 12 else soma
        origem = f'Início de atividade: média dos {qtd} meses × 12' if qtd < 12 else 'Soma dos 12 meses anteriores'
        if faltam:
            alertas.append(['erro', 'Histórico incompleto, faltam: ' + ', '.join(sorted(faltam)) + '. Considerados como zero.'])
        if caso.get('rbt12') is not None and not faltam and abs(caso['rbt12'] - rbt12) > 0.01:
            alertas.append(['erro', f"RBT12 informado ({brl(caso['rbt12'])}) diverge da soma mês a mês ({brl(rbt12)}). Usada a soma."])
    elif caso.get('rbt12') is not None:
        rbt12 = caso['rbt12']
        origem = 'Informado'
        if n is not None and n < 12:
            alertas.append(['aviso', 'Empresa com menos de 12 meses: confira se o RBT12 informado já está proporcionalizado.'])
    else:
        rbt12 = 0
        origem = 'Não informado'
        alertas.append(['erro', 'Informe o RBT12 ou a receita dos 12 meses anteriores.'])

    # Limites
    ano = comp[:4]
    rba_ano = rpa
    if caso.get('acumulado_ano') is not None:
        rba_ano += caso['acumulado_ano']
    else:
        for k, v in hist.items():
            if k[:4] == ano and k < comp:
                rba_ano += v
    limite, sublimite = LIMITE, R['sublimite']
    if inicio and inicio[:4] == ano:
        meses_ano = 12 - int(inicio[5:7]) + 1
        limite = R['limiteMesInicio'] * meses_ano
        sublimite = R['sublimiteMesInicio'] * meses_ano
        alertas.append(['info', f'Ano de início: limite proporcional {brl(limite)}, sublimite {brl(sublimite)} ({meses_ano} meses).'])
    if rba_ano > limite * 1.2:
        alertas.append(['erro', f'Receita acumulada no ano ({brl(rba_ano)}) excede o limite em mais de 20%: exclusão no próprio mês.'])
    elif rba_ano > limite:
        alertas.append(['erro', f'Receita acumulada no ano ({brl(rba_ano)}) excede o limite em até 20%: exclusão em 1º/jan seguinte e majoração no excesso.'])
    if rba_ano > sublimite * 1.2:
        alertas.append(['erro', f'Receita acumulada no ano ({brl(rba_ano)}) excede o sublimite em mais de 20%: ICMS/ISS fora do DAS já neste mês.'])
    elif rba_ano > sublimite:
        alertas.append(['aviso', f'Receita acumulada no ano ({brl(rba_ano)}) excede o sublimite: ICMS/ISS fora do DAS a partir do ano seguinte e majoração no excesso.'])
    if rbt12 > LIMITE:
        alertas.append(['erro', f'RBT12 ({brl(rbt12)}) acima de R$ 4,8 mi.'])

    faixa = faixa_de(rbt12, R)
    if faixa == 6:
        alertas.append(['aviso', '6ª faixa: ICMS/ISS fora do DAS; conferir apuração pelo regime normal.'])
    # Folha 12m (FS12) pelo mesmo critério do RBT12: no início de atividade, média dos meses × 12
    # (Res. CGSN 140/2018, art. 26 — mesmos critérios da receita); no 1º mês, folha do mês × 12.
    fol_m = caso.get('folhaMeses') or {}
    f12 = caso.get('folha_12m')
    folha_anual, orig_fa = None, ''
    if n is not None and n <= 0:
        if caso.get('folha_mes') is not None:
            folha_anual, orig_fa = caso['folha_mes'] * 12, 'Início de atividade: folha do mês × 12'
    elif f12 is not None or fol_m:
        qf = n if (n is not None and n < 12) else 12
        soma_f = sum(fol_m.get(mes_add(comp, -i), 0) or 0 for i in range(1, qf + 1)) if fol_m else f12
        folha_anual = soma_f / qf * 12 if qf < 12 else soma_f
        orig_fa = f'Início de atividade: média da folha dos {qf} meses × 12' if qf < 12 else 'Soma da folha dos 12 meses anteriores'
    fator_r = (folha_anual / rbt12) if (folha_anual is not None and rbt12 > 0) else None

    itens, totais = [], {}
    for r in receitas:
        anexo = str(r['anexo']).upper()
        obs = []
        desc = r.get('descricao') or 'Receita'
        valor = float(r['valor'])
        anexo_orig = anexo
        if anexo == 'FATOR_R':
            if fator_r is None:
                alertas.append(['erro', f'{desc}: sujeita ao Fator R sem folha lançada; tributada pelo Anexo V.'])
                anexo = 'V'
            else:
                anexo = 'III' if fator_r >= FATOR_R_MIN else 'V'
                obs.append(f'Fator R {pct(fator_r, 2)} → Anexo {anexo}')
        if anexo not in NOMINAIS:
            alertas.append(['erro', f"{desc}: anexo inválido ({r['anexo']})."])
            continue
        nom_p, pd = NOMINAIS[anexo][faixa - 1]
        nom = nom_p / 100
        aliq_ef = (rbt12 * nom - pd) / rbt12 if rbt12 > 0 else nom
        tribs = TRIBUTOS[anexo]
        percs = [p / 100 for p in REPARTICAO[anexo][faixa - 1]]
        ef = {t: aliq_ef * percs[i] for i, t in enumerate(tribs)}
        iss_exc = 0
        if 'ISS' in ef and ef['ISS'] > TETO_ISS:
            exc = ef['ISS'] - TETO_ISS
            ef['ISS'] = TETO_ISS
            iss_exc = exc
            fed = [(t, percs[i]) for i, t in enumerate(tribs) if t != 'ISS']
            soma = sum(p for _, p in fed)
            for t, p in fed:
                ef[t] += exc * p / soma
            alertas.append(['info', f'{desc}: ISS efetivo limitado a 5%; excedente de {pct(exc)} redistribuído aos federais.'])
        excl = set()
        for flag, (ts, rot) in SEG.items():
            if r.get(flag):
                excl.update(ts)
                obs.append(rot)
        # ISS retido pelo tomador (LC 123/2006, art. 21, § 4º; Res. CGSN 140/2018, art. 27): no DAS sai SÓ a parcela
        # do ISS — alíquota efetiva × % do ISS na repartição da faixa (já limitada a 5%). IRPJ, CSLL, Cofins, PIS e CPP
        # continuam integrais. A alíquota municipal não entra nesta conta.
        iss_ret = 0.0
        if r.get('iss_retido'):
            if 'ISS' not in tribs:
                alertas.append(['aviso', f'{desc}: marcada com ISS retido, mas o Anexo {anexo} não tem ISS — a marcação não altera o DAS.'])
            elif not r.get('exportacao'):
                iss_ret = r2(valor * ef['ISS'])
        valores, aplicada = {}, 0
        for t in tribs:
            if t in excl or ef[t] == 0:
                continue
            valores[t] = r2(valor * ef[t])
            totais[t] = r2(totais.get(t, 0) + valores[t])
            aplicada += ef[t]
        itens.append({
            'descricao': desc, 'anexo': anexo, 'anexoOrig': anexo_orig, 'valor': valor,
            'aliq_nominal': nom, 'parcela_deduzir': pd, 'aliq_efetiva': aliq_ef, 'aliq_aplicada': aplicada,
            'valores': valores, 'total': r2(sum(valores.values())), 'obs': obs, 'origem': r.get('origem') or '',
            'percs': {t: percs[i] for i, t in enumerate(tribs)}, 'ef': dict(ef), 'excl': sorted(excl), 'issExc': iss_exc,
            'issRetido': iss_ret, 'aliqIss': ef.get('ISS', 0.0) if r.get('iss_retido') else None,
        })
    total = r2(sum(totais.values()))
    ret_it = [it for it in itens if it['issRetido']]
    iss_retido = {'base': r2(sum(it['valor'] for it in ret_it)), 'valor': r2(sum(it['issRetido'] for it in ret_it))} if ret_it else None

    if caso.get('rpa_declarada') is not None and abs(r2(rpa) - caso['rpa_declarada']) > 0.01:
        alertas.append(['erro', f"Receita do mês ({brl(rpa)}) difere da RPA declarada no PGDAS-D ({brl(caso['rpa_declarada'])}): diferença de {brl(r2(rpa - caso['rpa_declarada']))}."])
    status, diferenca, comparacao = 'APURADO', None, []
    if caso.get('das_por_tributo'):
        for t in ORDEM:
            c = totais.get(t, 0)
            inf = caso['das_por_tributo'].get(t, 0) or 0
            if not c and not inf:
                continue
            comparacao.append([t, c, inf, r2(inf - c), abs(inf - c) <= tol])
        div = [f'{x[0]} {brl(x[3])}' for x in comparacao if not x[4]]
        if div:
            alertas.append(['erro', 'Diferença por tributo (declarado − recalculado): ' + '; '.join(div) + '.'])
    if caso.get('das_informado') is not None:
        diferenca = r2(caso['das_informado'] - total)
        ok = abs(diferenca) <= tol * max(1, len(totais))
        status = 'OK' if ok and not any(not x[4] for x in comparacao) else 'DIVERGENTE'
        if not ok:
            alertas.append(['erro', f'DAS informado diverge do recalculado em {brl(diferenca)}.'])
    if status == 'OK' and any(a[0] == 'erro' for a in alertas):
        status = 'OK COM RESSALVAS'
    return {
        'regime': 'SN',
        'regra': {'versao': R['versao'], 'vigencia': R['vigencia']['de'], 'origem': R['origem']},
        'rpa': r2(rpa), 'rbt12': r2(rbt12), 'origem_rbt12': origem, 'rba_ano': r2(rba_ano), 'faixa': faixa,
        'fator_r': fator_r, 'itens': itens, 'tributos': totais, 'total_calculado': total,
        'das_informado': caso.get('das_informado'), 'diferenca': diferenca, 'status': status,
        'alertas': alertas, 'comparacao': comparacao, 'iss_retido': iss_retido,
        'memo': {
            'mesesRbt': meses_rbt, 'hist': dict(hist), 'origemHist': dict(caso.get('origemHist') or {}),
            'inicio': inicio, 'qtdInicio': n, 'limite': limite, 'sublimite': sublimite,
            'folha_12m': caso.get('folha_12m'), 'origemFolha': caso.get('origemFolha') or '',
            'folha_anual': r2(folha_anual) if folha_anual is not None else None, 'origemFolhaAnual': orig_fa,
            'folhaMeses': dict(caso.get('folhaMeses') or {}), 'folhaDet': dict(caso.get('folhaDet') or {}),
            'folha_mes': caso.get('folha_mes'), 'atividades': list(caso.get('atividades') or []), 'rpa_declarada': caso.get('rpa_declarada'),
            'rbt12_informado': caso.get('rbt12'),
        },
    }


def projetar_prox(r: dict, caso: dict) -> dict:
    """Projeta a competência seguinte (PA + 1) com as janelas móveis de 12 meses.

    RBT12 de PA+1 = receitas de PA−11 … PA (entra a receita do PA, sai PA−12).
    Folha 12m de PA+1 = folhas de PA−11 … PA (entra a folha do PA, sai PA−12) — Res. CGSN 140/2018, art. 26.
    A folha do PA vem do campo "Folha do mês" / PGDAS-D / apuração salva; sem ela, é estimada
    pela folha do mês anterior (ou pela média da folha 12m) e o resultado é marcado como estimado.
    """
    c = caso['competencia']
    prox = mes_add(c, 1)
    m = r['memo']
    hist = {}
    for i in range(1, 13):
        mm = mes_add(prox, -i)
        if mm == c:
            hist[mm] = caso['rpa_fr'] if caso.get('rpa_fr') is not None else r['rpa']   # receita do PA ajustada no Fator R
        elif mm in m['hist']:
            hist[mm] = m['hist'][mm]

    sai = mes_add(c, -12)            # mês que deixa a janela da folha ao passar para PA+1
    fol = dict(caso.get('folhaMeses') or {})
    f12 = caso.get('folha_12m')
    fm, fm_orig = caso.get('folha_mes'), caso.get('origemFolhaMes') or ''
    estimada = False
    if fm is None and f12 is not None:
        estimada = True
        if mes_add(c, -1) in fol:
            fm, fm_orig = fol[mes_add(c, -1)], f'estimada pela folha de {nome_mes(mes_add(c, -1))}'
        else:
            fm, fm_orig = r2(f12 / 12), 'estimada pela média da folha 12m'
    if f12 is None and fm is None:
        folha_prox, base11 = None, None
    elif fol:
        base11 = r2(sum(v for k, v in fol.items() if sai < k < c))
        folha_prox = r2(base11 + (fm or 0))
    elif f12 is not None:          # só o total de 12 meses foi informado: retira 1/12 (mês que sai)
        base11 = r2(f12 - f12 / 12)
        folha_prox = r2(base11 + (fm or 0))
    else:                          # sem histórico de folha, só a do mês
        base11 = 0
        folha_prox = r2(fm)

    fol_prox = {k: v for k, v in fol.items() if sai < k < c}
    if fol and fm is not None:
        fol_prox[c] = fm
    sem_decl = {'das_informado': None, 'das_por_tributo': None, 'rpa_declarada': None}
    alt = validar({**caso, **sem_decl, 'competencia': prox, 'hist': hist, 'rbt12': None, 'acumulado_ano': None,
                   'folha_12m': folha_prox, 'folhaMeses': fol_prox, 'folha_mes': None})
    R = regra_vigente(prox)
    frm = R['fatorRMin']
    afr = next((it['anexo'] for it in alt['itens'] if it['anexoOrig'] == 'FATOR_R'), None)
    folha_min = None
    n2 = meses_entre(caso.get('inicio_atividade'), prox) if caso.get('inicio_atividade') else None
    q2 = n2 if (n2 is not None and 0 < n2 < 12) else 12
    if base11 is not None and alt['rbt12'] > 0 and (n2 is None or n2 > 0):
        folha_min = max(0.0, r2(frm * alt['rbt12'] * q2 / 12 - base11))   # folha do PA para manter o mínimo em PA+1
    return {
        'pa': prox, 'rbt12': alt['rbt12'], 'faixa': alt['faixa'], 'das': alt['total_calculado'],
        'folha_12m': folha_prox, 'folha_anual': alt['memo']['folha_anual'], 'origemFolhaAnual': alt['memo']['origemFolhaAnual'],
        'fator_r': alt['fator_r'], 'anexoFR': afr, 'fatorRMin': frm,
        'folha_mes': fm, 'origemFolhaMes': fm_orig, 'folha_estimada': estimada,
        'mes_sai': sai, 'folha_sai': fol.get(sai) if fol else (r2(f12 / 12) if f12 is not None else None),
        'folha_min_mes': folha_min,
    }


def projetar(r: dict, caso: dict, rec: float, folha: float, meses: int) -> list:
    """Projeta DAS/faixa/Fator R mês a mês pela janela móvel (simulador)."""
    c = caso['competencia']
    m = r['memo']
    hist = dict(caso['hist'])
    hist[c] = r['rpa']
    fol = dict(m.get('folhaMeses') or {})
    if not fol and m.get('folha_12m') is not None:
        for i in range(1, 13):
            fol[mes_add(c, -i)] = m['folha_12m'] / 12
    fol[c] = folha
    k = rec / r['rpa'] if r['rpa'] > 0 else 0
    receitas = [{**x, 'valor': r2(x['valor'] * k)} for x in caso['receitas']]
    tem_folha = m.get('folha_12m') is not None or folha > 0
    out = []
    for j in range(1, meses + 1):
        p = mes_add(c, j)
        h, fo = {}, 0
        for i in range(1, 13):
            mm = mes_add(p, -i)
            if mm in hist:
                h[mm] = hist[mm]
            fo += fol.get(mm, 0) or 0
        res = validar({'competencia': p, 'hist': h, 'origemHist': {}, 'rbt12': None, 'acumulado_ano': None,
                       'folha_12m': fo if tem_folha else None, 'inicio_atividade': caso.get('inicio_atividade'),
                       'das_informado': None, 'das_por_tributo': None, 'rpa_declarada': None, 'receitas': receitas})
        afr = next((it['anexo'] for it in res['itens'] if it['anexoOrig'] == 'FATOR_R'), None)
        out.append({'pa': p, 'rbt12': res['rbt12'], 'faixa': res['faixa'], 'fr': res['fator_r'], 'das': res['total_calculado'],
                    'aliq': res['total_calculado'] / rec if rec else 0, 'anexoFR': afr})
        hist[p] = rec
        fol[p] = folha
    return out


def folha_necessaria(r, caso, rec, meses, meta):
    def ok(f):
        return all(p['fr'] is not None and p['fr'] >= meta for p in projetar(r, caso, rec, f, meses))
    if ok(0):
        return 0
    lo, hi = 0.0, max(rec, 1000) * 2
    if not ok(hi):
        return None
    for _ in range(32):
        mid = (lo + hi) / 2
        if ok(mid):
            hi = mid
        else:
            lo = mid
    import math
    return math.ceil(hi * 100) / 100


ALIQ_RET_INICIO = 0.02     # mês de início de atividade: menor percentual de ISS dos Anexos III, IV e V (LC 123, art. 21, § 4º, II)
ALIQ_RET_SEM_INFO = 0.05   # nota sem alíquota informada: o tomador retém 5% (art. 21, § 4º, V)


def aliq_iss_retencao(anexo: str, rbt12: float, regra=None) -> float:
    """% do ISS que o tomador deve reter: alíquota efetiva × % do ISS na repartição, limitado a 5%
    (LC 123/2006, art. 21, § 4º, I — faixa do mês ANTERIOR ao da prestação; Res. CGSN 140/2018, art. 27)."""
    from .regras_sn import REGRAS, faixa_de as _fx
    regra = regra or REGRAS[-1]
    tribs = regra['tributos'].get(anexo) or []
    if 'ISS' not in tribs:
        return 0.0
    fx = _fx(rbt12, regra)
    nom, pd = regra['nominais'][anexo][fx - 1]
    ef = (rbt12 * nom / 100 - pd) / rbt12 if rbt12 > 0 else nom / 100
    return min(ef * regra['reparticao'][anexo][fx - 1][tribs.index('ISS')] / 100, regra['tetoIss'])


__all__ = ['validar', 'projetar', 'folha_necessaria', 'nome_mes', 'aliq_iss_retencao']
