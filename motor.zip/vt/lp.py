"""Lucro Presumido — motor versionado.

• Apuração MENSAL: receitas, PIS/Cofins, ICMS, ISS, IPI, CBS/IBS, retenções,
  obrigações e memória do mês.
• Apuração TRIMESTRAL: IRPJ e CSLL consolidando os três meses, regra de 2026
  (LC 224/2025), validação e fechamento do trimestre.
"""
from __future__ import annotations

from datetime import date, timedelta

from .importacao import GRUPOS, xml_mes, _GEN, LEITURA_NFSE
from .util import r2, num, brl, valN, pctN, mes_add, nome_mes, mes_longo, agora_iso, hash_str

GRUPOS_LP_BASE = {
    'comercio':      {'rot': 'Comércio / revenda de mercadorias', 'curto': 'Comércio', 'irpj': 0.08, 'csll': 0.12, 'pc': 'normal'},
    'mono':          {'rot': 'Revenda de monofásicos (PIS/Cofins zero)', 'curto': 'Comércio monofásico', 'irpj': 0.08, 'csll': 0.12, 'pc': 'zero'},
    'industria':     {'rot': 'Indústria / produção própria', 'curto': 'Indústria', 'irpj': 0.08, 'csll': 0.12, 'pc': 'normal'},
    'combustiveis':  {'rot': 'Revenda de combustíveis', 'curto': 'Combustíveis', 'irpj': 0.016, 'csll': 0.12, 'pc': 'zero'},
    'transp_carga':  {'rot': 'Transporte de cargas', 'curto': 'Transporte de cargas', 'irpj': 0.08, 'csll': 0.12, 'pc': 'normal'},
    'transp_pass':   {'rot': 'Transporte de passageiros', 'curto': 'Transporte de passageiros', 'irpj': 0.16, 'csll': 0.12, 'pc': 'normal'},
    'servicos':      {'rot': 'Serviços em geral', 'curto': 'Serviços', 'irpj': 0.32, 'csll': 0.32, 'pc': 'normal', 'iss': True},
    'intermediacao': {'rot': 'Intermediação / administração de bens', 'curto': 'Intermediação', 'irpj': 0.32, 'csll': 0.32, 'pc': 'normal', 'iss': True},
    'locacao':       {'rot': 'Locação / cessão de bens', 'curto': 'Locação', 'irpj': 0.32, 'csll': 0.32, 'pc': 'normal'},
    'saude':         {'rot': 'Serviços hospitalares / auxílio diagnóstico', 'curto': 'Saúde (hospitalar)', 'irpj': 0.08, 'csll': 0.12, 'pc': 'normal', 'iss': True, 'requisitos': True},
    'imobiliaria':   {'rot': 'Atividade imobiliária', 'curto': 'Imobiliária', 'irpj': 0.08, 'csll': 0.12, 'pc': 'normal'},
    'construcao':    {'rot': 'Construção por empreitada com materiais', 'curto': 'Construção', 'irpj': 0.08, 'csll': 0.12, 'pc': 'normal', 'iss': True},
    'exportacao':    {'rot': 'Exportação de mercadorias', 'curto': 'Exportação', 'irpj': 0.08, 'csll': 0.12, 'pc': 'isento'},
    'usados':        {'rot': 'Revenda de veículos usados — pela margem (art. 5º Lei 9.716/98)', 'curto': 'Veículos usados (margem)', 'irpj': 0.32, 'csll': 0.32, 'pc': 'normal', 'usados': True},
    'pendente':      {'rot': 'Sem classificação (usa 32%)', 'curto': 'Sem classificação', 'irpj': 0.32, 'csll': 0.32, 'pc': 'normal', 'pendente': True},
}
ALIQ_LP = {'IRPJ': 0.15, 'ADIC': 0.10, 'CSLL': 0.09, 'PIS': 0.0065, 'COFINS': 0.03}
ORIGEM_LP = ('Lei 9.249/1995, arts. 15 e 20; Lei 9.430/1996, arts. 1º, 3º, 25 e 29; Lei 9.718/1998, arts. 2º, 3º e 8º; '
             'Lei 9.715/1998, art. 8º; Lei 10.833/2003, art. 30')
REGRAS_LP = [
    {'versao': 'LP-2018', 'vigencia': {'de': '2018-01', 'ate': '2025-12'}, 'origem': ORIGEM_LP, 'aliq': ALIQ_LP, 'adicionalMes': 20000,
     'grupos': GRUPOS_LP_BASE, 'maj': None, 'cbsIbs': None},
    {'versao': 'LP-2026.1', 'vigencia': {'de': '2026-01', 'ate': None},
     'origem': ORIGEM_LP + '; LC 224/2025 e Decreto 12.808/2025 (acréscimo de 10% na presunção); LC 214/2025 (CBS/IBS em teste)',
     'aliq': ALIQ_LP, 'adicionalMes': 20000, 'grupos': GRUPOS_LP_BASE,
     'maj': {'fator': 1.1, 'limiteAno': 5000000, 'limiteTri': 1250000, 'irpjDe': '2026-01', 'csllDe': '2026-04'},
     'cbsIbs': {'ano': '2026', 'cbs': 0.009, 'ibs': 0.001}},
]
ORIGEM_USADOS = ('Lei 9.716/1998, art. 5º (equiparação à consignação); IN SRF 152/1998; IN RFB 1.700/2017, art. 242 '
                 '(receita bruta = venda − custo; presunção de 32%); Lei 10.833/2003, art. 10, VII, "c" (cumulativo)')
XML_LP = {'merc': 'comercio', 'merc_st': 'comercio', 'merc_mono': 'mono', 'merc_st_mono': 'mono', 'exp': 'exportacao',
          'serv': 'servicos', 'serv_ret': 'servicos'}
NOME_TRIB = {'IRRF': 'IRRF', 'CSLL': 'CSLL', 'PIS': 'PIS', 'COFINS': 'Cofins', 'IRPJ': 'IRPJ', 'ICMS': 'ICMS', 'ISS': 'ISS', 'IPI': 'IPI'}
SAUDE_REQ = [('org', 'Organizada como sociedade empresária'), ('ativ', 'Atividade elegível (hospitalar / auxílio diagnóstico)'),
             ('anvisa', 'Atende às normas da Anvisa'), ('segreg', 'Receita segregada corretamente'),
             ('docs', 'Documentação comprobatória arquivada'), ('fund', 'Fundamento legal registrado')]
OBRIG_LP = {'versao': 'OBR-2026.1',
            'mensais': [{'k': 'PIS', 'rot': 'PIS — cumulativo', 'cod': '8109', 'venc': 'dia25'},
                        {'k': 'COFINS', 'rot': 'Cofins — cumulativo', 'cod': '2172', 'venc': 'dia25'},
                        {'k': 'IPI', 'rot': 'IPI', 'cod': '5123', 'venc': 'dia25', 'so': 'ipi'},
                        {'k': 'ICMS', 'rot': 'ICMS', 'cod': 'conforme UF', 'venc': 'uf', 'so': 'icms'},
                        {'k': 'ISS', 'rot': 'ISS', 'cod': 'conforme município', 'venc': 'mun', 'so': 'iss'},
                        {'k': 'EFD', 'rot': 'EFD-Contribuições', 'cod': 'declaração', 'venc': 'efd'}],
            'trimestrais': [{'k': 'IRPJ', 'rot': 'IRPJ — Lucro Presumido', 'cod': '2089'},
                            {'k': 'CSLL', 'rot': 'CSLL — Lucro Presumido', 'cod': '2372'}]}
ST_OBRIG = ['calculado', 'revisado', 'transmitido', 'pago']
SEV_ROT = {'erro': 'ERRO', 'atencao': 'ATENÇÃO', 'ok': 'OK', 'na': 'N/A'}


# ---------------- atividade de serviço (item da LC 116 lido do XML) → natureza no Lucro Presumido ----------------
# Sugestão automática; o tipo de serviço de cada atividade pode ser definido no cadastro da empresa (vale para todos os meses).
SERV_LP = {
    '4.01': ('servicos', 'Medicina e congêneres: 32%, salvo se prestado como serviço hospitalar (8%/12%) com os requisitos'),
    '4.02': ('saude', 'Auxílio diagnóstico e terapia (análises clínicas, imagem, radioterapia): 8%/12% se cumprir os requisitos'),
    '4.03': ('saude', 'Hospitais, clínicas e congêneres: 8%/12% se cumprir os requisitos (Lei 9.249/1995, art. 15, § 1º, III, "a")'),
    '4.11': ('servicos', 'Obstetrícia: 32%, salvo serviço hospitalar com os requisitos'),
    '4.17': ('saude', 'Casas de repouso / recuperação: 8%/12% se cumprir os requisitos'),
    '7.02': ('servicos', 'Construção civil: 8%/12% só em empreitada com fornecimento de TODOS os materiais; sem materiais, 32%'),
    '7.05': ('servicos', 'Reparação/reforma de edificações: 8%/12% só com fornecimento de todos os materiais; senão 32%'),
    '16.01': ('transp_pass', 'Transporte de passageiros: 16% IRPJ / 12% CSLL'),
    '16.02': ('transp_carga', 'Outros transportes municipais: 8%/12% se for carga; 16%/12% se passageiros'),
    '17.12': ('intermediacao', 'Administração de bens e negócios de terceiros: 32%'),
}
SERV_LP_ITEM = {'10': ('intermediacao', 'Intermediação / agenciamento / corretagem: 32%'),
                '3': ('servicos', 'Cessão de uso de espaços e congêneres: 32%')}


def sugerir_serv(it):
    """(natureza sugerida, motivo) para o item da LC 116."""
    if not it:
        return 'servicos', 'Sem código de serviço na nota: serviços em geral (32%)'
    if it in SERV_LP:
        return SERV_LP[it]
    item = it.split('.')[0]
    if item in SERV_LP_ITEM:
        return SERV_LP_ITEM[item]
    return 'servicos', 'Serviços em geral: 32% IRPJ / 32% CSLL (Lei 9.249/1995, art. 15, § 1º, III)'


def serv_lp_cad(app, id_):
    """{item LC 116: natureza} definido pelo usuário no cadastro da empresa."""
    return (app.forms.get('empresa|' + str(id_)) or {}).get('servLP') or {}


# ---------------- cache (evita recalcular o mesmo mês dezenas de vezes por tela) ----------------
_CACHE_MES: dict = {}
_CACHE_ENT: dict = {}


def _ver(app):
    e = app.est
    return (id(e), getattr(e, 'ver', 0), _GEN[0], len(e.cancel), len(getattr(app, 'empresas', []) or []))


def limpar_cache_lp():
    _CACHE_MES.clear()
    _CACHE_ENT.clear()
    _CACHE_SIT.clear()


def regra_lp(c):
    v = [r for r in REGRAS_LP if r['vigencia']['de'] <= c and (not r['vigencia']['ate'] or c <= r['vigencia']['ate'])]
    return v[-1] if v else REGRAS_LP[-1]


def grupo(k):
    return GRUPOS_LP_BASE.get(k) or GRUPOS_LP_BASE['pendente']


# ---------------- vencimentos (sem feriados) ----------------
def _util(d):
    return d.weekday() < 5


def _dia_util_anterior(d):
    while not _util(d):
        d -= timedelta(days=1)
    return d


def _n_dia_util(y, m0, n):
    y, m0 = y + m0 // 12, m0 % 12
    d, c = date(y, m0 + 1, 1), 0
    while True:
        if _util(d):
            c += 1
            if c == n:
                return d
        d += timedelta(days=1)


def _ultimo_dia_util(y, m0):
    y2, m2 = y + (m0 + 1) // 12, (m0 + 1) % 12
    return _dia_util_anterior(date(y2, m2 + 1, 1) - timedelta(days=1))


def vencimento(tipo, mes):
    y, m = map(int, mes.split('-'))
    if tipo == 'dia25':
        y2, m2 = (y + 1, 1) if m == 12 else (y, m + 1)
        return _dia_util_anterior(date(y2, m2, 25))
    if tipo == 'efd':
        return _n_dia_util(y, m + 1, 10)
    if tipo == 'tri':
        return _ultimo_dia_util(y, m)
    return None


# ---------------- trimestre ----------------
def tri_de(c):
    y, m = map(int, c.split('-'))
    q = (m - 1) // 3 + 1
    m1 = f'{y}-{(q - 1) * 3 + 1:02d}'
    return {'id': f'{y}-T{q}', 'ano': str(y), 'q': q, 'meses': [m1, mes_add(m1, 1), mes_add(m1, 2)], 'ultimo': mes_add(m1, 2)}


# ---------------- veículos usados ----------------
def usados(app, imp, x, lp):
    linhas, cfg = [], lp.get('veic') or {}
    entradas = {}
    if imp:
        notas = imp.get('notas') or {}
        ck = (id(notas), len(notas), _GEN[0], len(app.est.cancel))
        entradas = _CACHE_ENT.get(ck)
        if entradas is None:              # percorre todas as notas da empresa uma vez só (antes: a cada mês, a cada tela)
            entradas = {}
            for n in notas.values():
                if not n.get('vei') or n.get('ch') in app.est.cancel:
                    continue
                for v in n['vei']:
                    if v.get('tp') == '0' and not v.get('g'):
                        entradas.setdefault(v['chassi'], []).append({'d': n.get('d'), 'n': n.get('n'), 'v': v['v']})
            if len(_CACHE_ENT) > 200:
                _CACHE_ENT.clear()
            _CACHE_ENT[ck] = entradas

    def custo_de(ch, d):
        c = [e for e in entradas.get(ch, []) if not d or (e['d'] or '') <= d]
        c.sort(key=lambda e: e['d'] or '', reverse=True)
        return c[0] if c else None

    def fecha(o, custo_inf):
        custo_bc = r2(o['venda'] - o['bc']) if o.get('bc') is not None and o['bc'] < o['venda'] else None
        custo = custo_inf if custo_inf is not None else (o.get('custoXml') if o.get('custoXml') is not None else custo_bc)
        margem = r2(o['venda'] - custo) if custo is not None else None
        fonte = ('informado' if custo_inf is not None else 'NF-e de entrada' if o.get('custoXml') is not None
                 else 'base do PIS na NF-e de venda' if custo_bc is not None else None)
        return {**o, 'custo': custo, 'custoBc': custo_bc, 'fonte': fonte, 'margem': margem,
                'base': o['venda'] if margem is None else r2(max(0, margem))}

    for n in x['notas']:
        for v in n.get('vei') or []:
            if v.get('tp') != '1' or not v.get('g'):
                continue
            c = cfg.get(v['chassi']) or {}
            usado = (c.get('tipo') == 'usado') if c.get('tipo') else not v.get('mono')
            e = custo_de(v['chassi'], n.get('d'))
            linhas.append(fecha({'origem': 'XML', 'chassi': v['chassi'], 'desc': v.get('desc'), 'nfS': n.get('n'), 'dS': n.get('d'),
                                 'venda': v['v'], 'xg': v['g'], 'mono': v.get('mono'), 'bc': v.get('bc'), 'semChassi': v.get('semChassi'),
                                 'usado': usado, 'nfE': (e or {}).get('n'), 'dE': (e or {}).get('d'), 'custoXml': e['v'] if e else None},
                                num(c.get('custo'))))
    for i, u in enumerate(lp.get('usados') or []):
        venda = num(u.get('venda'))
        if not venda:
            continue
        linhas.append(fecha({'origem': 'manual', 'i': i, 'chassi': str(u.get('chassi') or '').upper(), 'desc': u.get('descricao') or '',
                             'venda': venda, 'usado': True, 'custoXml': None}, num(u.get('custo'))))
    us = [l for l in linhas if l['usado']]
    return {'linhas': linhas, 'qtd': len(us), 'venda': r2(sum(l['venda'] for l in us)), 'custo': r2(sum(l['custo'] or 0 for l in us)),
            'base': r2(sum(l['base'] for l in us)), 'semCusto': [l for l in us if l['custo'] is None],
            'bcDiverge': [l for l in us if l.get('bc') is not None and l['margem'] is not None and abs(l['bc'] - l['base']) > 0.01],
            'negativos': [l for l in us if l['margem'] is not None and l['margem'] < 0]}


# ---------------- dados de um mês ----------------
def mes_dados(app, id_, mes):
    k = (_ver(app), str(id_), mes)
    c = _CACHE_MES.get(k)
    if c is None:
        if len(_CACHE_MES) > 3000:
            _CACHE_MES.clear()
        c = _CACHE_MES[k] = _mes_dados(app, id_, mes)
    return {**c, 'itens': [dict(it) for it in c['itens']]}


def _servicos_mes(x):
    """Receita de serviço das NFS-e do mês por atividade (item da LC 116 do XML)."""
    por = {}
    for n in x['notas']:
        if n.get('mod') != 'NFS-e' or n.get('itens'):
            continue
        sv = n.get('sv') or {}
        it = sv.get('it') or ''
        for g, v in (n.get('p') or {}).items():
            if g not in ('serv', 'serv_ret') or not v:
                continue
            if not it and not sv:
                continue                       # nota sem código (TXT/CSV, importação antiga): fica no grupo geral
            a = por.setdefault(it, {'it': it, 'x': sv.get('x') or '', 'cnae': set(), 'v': 0.0, 'qtd': 0, 'xg': {}, 'notas': []})
            a['v'] = r2(a['v'] + v)
            a['xg'][g] = r2(a['xg'].get(g, 0) + v)
            if n['n'] not in a['notas']:
                a['notas'].append(n['n'])
                a['qtd'] += 1
            if sv.get('cnae'):
                a['cnae'].add(sv['cnae'])
            if not a['x'] and sv.get('x'):
                a['x'] = sv['x']
    for a in por.values():
        a['cnae'] = sorted(a['cnae'])
    return por


def _mes_dados(app, id_, mes):
    raiz, imp = app.import_de(id_)
    f = app.forms.get(f'{mes}|{id_}') or {}
    lp = f.get('lp') or {}
    x = xml_mes(imp, mes, app.est.cancel, app.uf_de(id_), app.regras_ncm())
    itens = []
    U = usados(app, imp, x, lp)
    gx = dict(x['grupos'])
    for u in U['linhas']:
        if u['usado'] and u.get('xg'):
            gx[u['xg']] = r2(gx.get(u['xg'], 0) - u['venda'])
    # serviços: uma linha por atividade lida do XML, com a natureza definida para a atividade
    serv = _servicos_mes(x)
    cad_serv = serv_lp_cad(app, id_)
    for it, a in sorted(serv.items(), key=lambda p: -p[1]['v']):
        for g, v in a['xg'].items():
            gx[g] = r2(gx.get(g, 0) - v)
        sug, motivo = sugerir_serv(it)
        legado = next(((lp.get('grupoXml') or {}).get(g) for g in a['xg'] if (lp.get('grupoXml') or {}).get(g)), None)
        if cad_serv.get(it):
            grp, fonte = cad_serv[it], 'definida para a atividade'
        elif legado:
            grp, fonte = legado, 'etapa 1 (grupo de serviços)'
        else:
            grp, fonte = sug, 'sugestão pelo código'
        rot = (f'Serviço {it}' if it else 'Serviço sem código') + (f' — {a["x"]}' if a['x'] else '')
        itens.append({'descricao': rot[:140], 'grupo': grp, 'valor': a['v'], 'origem': 'XML', 'xg': 'serv_ret' if 'serv_ret' in a['xg'] and len(a['xg']) == 1 else 'serv',
                      'svc': it, 'svcX': a['x'], 'sug': sug, 'sugMotivo': motivo, 'fonteGrupo': fonte, 'qtd': a['qtd'], 'cnae': a['cnae'],
                      'nfse': True, 'issRet': a['xg'].get('serv_ret', 0)})
    for g, v in gx.items():
        if abs(v) > 0.004:
            itens.append({'descricao': GRUPOS.get(g, {}).get('rot', g), 'grupo': (lp.get('grupoXml') or {}).get(g) or XML_LP.get(g) or 'pendente',
                          'valor': v, 'origem': 'XML', 'xg': g, 'nfse': g in ('serv', 'serv_ret')})
    for orig in ('XML', 'manual'):
        us = [u for u in U['linhas'] if u['usado'] and u['origem'] == orig]
        if not us:
            continue
        itens.append({'descricao': f'Veículos usados — margem de {len(us)} veículo(s)', 'grupo': 'usados', 'valor': r2(sum(u['base'] for u in us)),
                      'venda': r2(sum(u['venda'] for u in us)), 'custo': r2(sum(u['custo'] or 0 for u in us)), 'origem': orig, 'usados': True})
    for r in lp.get('receitas') or []:
        v = num(r.get('valor'))
        if v:
            itens.append({'descricao': r.get('descricao') or 'Receita', 'grupo': r.get('grupo') or 'pendente', 'valor': v, 'origem': 'manual'})
    ret_xml = {'IRRF': 0.0, 'CSLL': 0.0, 'PIS': 0.0, 'COFINS': 0.0}
    tx = {'ICMS': 0.0, 'ST': 0.0, 'IPI': 0.0}
    ret_notas, antigas = [], 0
    for n in x['notas']:
        rf = n.get('rf') or {}
        for t in ret_xml:
            ret_xml[t] = r2(ret_xml[t] + (rf.get(t) or 0))
        for t in tx:
            tx[t] = r2(tx[t] + ((n.get('tx') or {}).get(t) or 0))
        if n.get('mod') == 'NFS-e' and (n.get('lv') or 0) < LEITURA_NFSE and str(n.get('arq') or '').lower().endswith('.xml'):
            antigas += 1
        ri = n.get('rfInfo') or {}
        if any(rf.values()) or ri.get('aviso') or ri.get('inss'):
            base = sum((n.get('p') or {}).values())
            ret_notas.append({'n': n.get('n'), 'd': n.get('d'), 'mod': n.get('mod'), 'tom': (n.get('tom') or {}).get('nome') or '',
                              'tomDoc': (n.get('tom') or {}).get('doc') or '', 'it': (n.get('sv') or {}).get('it') or '', 'valor': r2(base),
                              'IRRF': rf.get('IRRF') or 0, 'CSLL': rf.get('CSLL') or 0, 'PIS': rf.get('PIS') or 0, 'COFINS': rf.get('COFINS') or 0,
                              'INSS': ri.get('inss') or 0, 'tp': ri.get('tp', ''), 'tpRot': ri.get('tpRot', ''), 'modo': ri.get('modo', ''),
                              'leiaute': ri.get('leiaute', ''), 'aviso': ri.get('aviso', ''), 'campos': ri.get('campos') or {}})
    ret_notas.sort(key=lambda r: (r['d'] or '', str(r['n'])))
    salva = False
    if not itens:
        ap = (app.est.apur.get(raiz) or {}).get(mes)
        if ap and ap.get('regime') == 'LP' and ap.get('itens'):
            for r in ap['itens']:
                itens.append({**r, 'origem': 'Apuração salva'})
            salva = True
    ret_man = {t: num((lp.get('retManual') or {}).get(t)) or 0 for t in ret_xml}

    def ret_enc(t):
        return r2(ret_xml[t] + ret_man[t])
    return {'mes': mes, 'itens': itens, 'usados': U, 'retXml': ret_xml, 'retEnc': ret_enc, 'tx': tx, 'x': x, 'lp': lp, 'salva': salva,
            'servRet': x['grupos'].get('serv_ret', 0), 'tem': len(itens) > 0, 'rec': r2(sum(it['valor'] for it in itens)),
            'retNotas': ret_notas, 'nfseAntigas': antigas}


# =================== APURAÇÃO MENSAL ===================
def apurar_mes(app, id_, c):
    R = regra_lp(c)
    m = mes_dados(app, id_, c)
    lp = m['lp']
    cad = app.forms.get('empresa|' + str(id_)) or {}
    tol = app.param()['tolerancia']
    if not m['tem']:
        return None
    base = {'normal': 0.0, 'zero': 0.0, 'isento': 0.0}
    base_iss = 0.0
    for it in m['itens']:
        g = grupo(it['grupo'])
        base[g['pc']] = r2(base.get(g['pc'], 0) + it['valor'])
        if g.get('iss') or it.get('nfse'):       # receita de NFS-e sempre é base do ISS, qualquer que seja a natureza no LP
            base_iss = r2(base_iss + it['valor'])
    rpa = m['rec']
    ret = {t: {'xml': m['retXml'][t], 'enc': m['retEnc'](t), 'apr': num((lp.get('ret') or {}).get(t))} for t in ('PIS', 'COFINS', 'IRRF', 'CSLL')}
    pis, cofins = r2(base['normal'] * R['aliq']['PIS']), r2(base['normal'] * R['aliq']['COFINS'])
    pis_dev, cofins_dev = r2(max(0, pis - ret['PIS']['enc'])), r2(max(0, cofins - ret['COFINS']['enc']))
    li = lp.get('icms') or {}
    decl_in = lp.get('decl') or {}
    ic_d = r2(m['tx']['ICMS'] + (num(li.get('deb')) or 0))
    ic_c, ic_s = num(li.get('cred')) or 0, num(li.get('saldoAnt')) or 0
    ic_saldo = r2(ic_d - ic_c - ic_s)
    icms = {'tem': bool(ic_d or ic_c or ic_s or num(decl_in.get('ICMS')) is not None), 'debXml': m['tx']['ICMS'], 'deb': ic_d, 'cred': ic_c,
            'saldoAnt': ic_s, 'st': m['tx']['ST'], 'dev': r2(max(0, ic_saldo)), 'credorProx': r2(max(0, -ic_saldo))}
    aliq = num(cad.get('aliqIss'))
    ret_base = r2(min(base_iss, m['servRet']))
    proprio = r2(base_iss - ret_base)
    iss = {'tem': base_iss > 0 or num(decl_in.get('ISS')) is not None, 'aliq': aliq, 'base': base_iss, 'retBase': ret_base, 'proprioBase': proprio,
           'dev': r2(proprio * aliq / 100) if aliq is not None else None, 'retido': r2(ret_base * aliq / 100) if aliq is not None else None}
    lpi = lp.get('ipi') or {}
    ip_d = r2(m['tx']['IPI'] + (num(lpi.get('deb')) or 0))
    ip_c = num(lpi.get('cred')) or 0
    ipi = {'tem': bool(ip_d or ip_c or (base['normal'] and any(it['grupo'] == 'industria' for it in m['itens'])) or num(decl_in.get('IPI')) is not None),
           'debXml': m['tx']['IPI'], 'deb': ip_d, 'cred': ip_c, 'dev': r2(max(0, ip_d - ip_c)), 'credorProx': r2(max(0, ip_c - ip_d))}
    tributos = {'PIS': pis_dev, 'COFINS': cofins_dev}
    if icms['tem']:
        tributos['ICMS'] = icms['dev']
    if iss['tem'] and iss['dev'] is not None:
        tributos['ISS'] = iss['dev']
    if ipi['tem']:
        tributos['IPI'] = ipi['dev']
    decl = {t: num(decl_in.get(t)) for t in ('PIS', 'COFINS', 'ICMS', 'ISS', 'IPI')}
    comparacao = []
    for t in tributos:
        if decl[t] is not None:
            d = r2(decl[t] - tributos[t])
            comparacao.append([t, tributos[t], decl[t], d, abs(d) <= tol])
    total = r2(sum(tributos.values()))
    decl_tot = r2(sum(x[2] for x in comparacao)) if comparacao else None
    calc_tot = r2(sum(x[1] for x in comparacao)) if comparacao else None
    cbs_base = r2(rpa - base['isento'])
    T = tri_de(c)
    return {'regime': 'LP', 'escopo': 'mes', '_id': id_, 'regra': {'versao': R['versao'], 'vigencia': R['vigencia']['de'], 'origem': R['origem']},
            'comp': c, 'rpa': rpa, 'rbt12': None, 'faixa': None, 'fator_r': None, 'itens': [], 'alertas': [],
            'tri': {'id': T['id'], 'q': T['q'], 'ano': T['ano'], 'ultimo': T['ultimo']},
            'mes': {'itens': m['itens'], 'usados': m['usados'], 'base': base, 'pis': pis, 'cofins': cofins, 'pisDev': pis_dev,
                    'cofinsDev': cofins_dev, 'ret': ret, 'icms': icms, 'iss': iss, 'ipi': ipi,
                    'x': {'qtd': m['x']['qtd'], 'total': m['x']['total'], 'alertas': m['x'].get('alertas') or {}, 'ncm': m['x'].get('ncm') or {}}, 'salva': m['salva'],
                    'retNotas': m['retNotas'], 'nfseAntigas': m['nfseAntigas']},
            'cbsIbs': ({'base': cbs_base, 'cbs': r2(cbs_base * R['cbsIbs']['cbs']), 'ibs': r2(cbs_base * R['cbsIbs']['ibs'])}
                       if R['cbsIbs'] and c.startswith(R['cbsIbs']['ano']) else None),
            'tributos': tributos, 'total_calculado': total, 'das_informado': decl_tot,
            'diferenca': r2(decl_tot - calc_tot) if decl_tot is not None else None,
            'status': 'APURADO' if not comparacao else ('OK' if all(x[4] for x in comparacao) else 'DIVERGENTE'),
            'comparacao': comparacao, 'decl': decl, 'calc': tributos, 'memo': {}}


def hash_mes(r):
    M = r['mes']
    return hash_str([[[it['grupo'], it['valor'], it.get('venda') or 0] for it in M['itens']],
                     [[u['chassi'], u['usado'], u['custo']] for u in (M['usados'] or {}).get('linhas', [])],
                     M['ret'], M['icms'], M['iss'], M['ipi'], r['decl'], r['regra']['versao']])


def apurar_caso(app, id_):
    k = app.chave(id_)
    r = apurar_mes(app, id_, app.comp)
    if not r:
        for d in (app.RES, app.CHK, app.HASH):
            d.pop(k, None)
        return None
    app.RES[k] = r
    app.CHK[k] = checks_mes(app, r)
    app.HASH[k] = hash_mes(r)
    return r


def _add(L):
    def add(**o):
        b = {'esperado': None, 'encontrado': None, 'diferenca': None, 'impacto': None, 'origem': '', 'causa': '', 'acao': None}
        b.update(o)
        L.append(b)
    return add


def checks_mes(app, r):
    tol = app.param()['tolerancia']
    L = []
    add = _add(L)
    M = r['mes']
    pend = [it for it in M['itens'] if it['grupo'] == 'pendente' or it['grupo'] not in GRUPOS_LP_BASE]
    v_pend = r2(sum(it['valor'] for it in pend))
    if pend:
        add(id='LP-CLASSIF', cat='Receitas', titulo='Receitas sem classificação tributária', sev='erro', rotEsp='Receita do mês', rotEnc='Sem natureza',
            esperado=r['rpa'], encontrado=v_pend, resumo=f'{len(pend)} receita(s) · {brl(v_pend)}',
            causa='Sem a natureza da receita não há tratamento de PIS/Cofins, ISS nem percentual de presunção no trimestre.', acao=['Classificar', '2'])
    else:
        add(id='LP-CLASSIF', cat='Receitas', titulo='Classificação das receitas por natureza', sev='ok',
            resumo=f"{len({it['grupo'] for it in M['itens']})} natureza(s) no mês", acao=['Ver receitas', '2'])
    _checks_ativ(app, r, add)
    if (M.get('x') or {}).get('ncm'):
        from . import ncm as NCMM
        NCMM.checks(M['x'].get('alertas') or {}, M['x']['ncm'], add, ALIQ_LP['PIS'] + ALIQ_LP['COFINS'], 0, lp=True)
    U = M['usados']
    if U and U['linhas']:
        aliq_pc = ALIQ_LP['PIS'] + ALIQ_LP['COFINS']
        if U['semCusto']:
            v = r2(sum(l['venda'] for l in U['semCusto']))
            add(id='LP-USADOS-CUSTO', cat='Veículos usados', titulo='Veículo usado vendido sem custo de aquisição', sev='erro', rotEsp='Custo de aquisição',
                rotEnc='Venda sem custo', encontrado=v, impacto=r2(v * aliq_pc),
                resumo=', '.join(l['chassi'] or l['desc'] or 'veículo' for l in U['semCusto'][:4]) + ('…' if len(U['semCusto']) > 4 else ''),
                origem=ORIGEM_USADOS, causa='Sem a NF-e de entrada do veículo (mesmo chassi) ou o custo informado, a venda inteira está sendo tributada. Importe a nota de entrada, informe o custo ou marque como venda normal se for veículo novo.',
                acao=['Informar custo', '2'])
        if U['negativos']:
            v = r2(sum(l['margem'] for l in U['negativos']))
            add(id='LP-USADOS-NEG', cat='Veículos usados', titulo='Veículo vendido abaixo do custo de aquisição', sev='atencao', rotEnc='Margem negativa', encontrado=v,
                resumo=', '.join(f"{l['chassi'] or l['desc']} ({valN(l['margem'])})" for l in U['negativos'][:3]), origem=ORIGEM_USADOS,
                causa='A margem negativa não gera base negativa: o veículo entra com base zero e não reduz a margem dos demais. Confira o custo, a nota de entrada e o valor de venda.', acao=['Ver veículos', '2'])
        if U['bcDiverge']:
            d = r2(sum(l['bc'] - l['base'] for l in U['bcDiverge']))
            add(id='LP-USADOS-BC', cat='Veículos usados', titulo='Base do PIS na NF-e de venda × margem apurada', sev='atencao', rotEsp='Margem (venda − custo)',
                rotEnc='Base na NF-e', esperado=r2(sum(l['base'] for l in U['bcDiverge'])), encontrado=r2(sum(l['bc'] for l in U['bcDiverge'])), diferenca=d,
                impacto=r2(abs(d) * aliq_pc), origem=ORIGEM_USADOS, resumo=', '.join(l['chassi'] for l in U['bcDiverge'][:3]),
                causa='O custo usado (nota de entrada ou informado) não bate com a base de PIS destacada na nota de venda. Confira qual custo está correto.', acao=['Ver veículos', '2'])
        nov = [l for l in U['linhas'] if not l['usado'] and l['origem'] == 'XML' and not l.get('mono')]
        if nov:
            add(id='LP-USADOS-NORMAL', cat='Veículos usados', titulo='Venda de veículo tributada pelo valor total', sev='atencao', rotEnc='Venda integral',
                encontrado=r2(sum(l['venda'] for l in nov)), resumo=', '.join(l['chassi'] for l in nov[:4]),
                causa='Veículo sem PIS/Cofins monofásico marcado como venda normal. Se for usado, a base é só a margem (venda − custo).', acao=['Ver veículos', '2'])
        if U['qtd']:
            add(id='LP-USADOS', cat='Veículos usados', titulo='Veículos usados tributados pela margem', sev='ok', rotEsp='Venda', esperado=U['venda'],
                rotEnc='Base (margem)', encontrado=U['base'], resumo=f"{U['qtd']} veículo(s) · custo {brl(U['custo'])} · margem {brl(U['base'])}",
                origem=ORIGEM_USADOS, acao=['Ver veículos', '2'])
    for t in ('PIS', 'COFINS'):
        x = M['ret'][t]
        nm = NOME_TRIB[t]
        if not x['enc'] and x['apr'] is None:
            continue
        if x['apr'] is None:
            add(id='RET-' + t, cat='Retenções', titulo=f'{nm} retido nos documentos', sev='na', rotEnc='Encontrado', encontrado=x['enc'],
                resumo='Aproveitamento não informado', causa='Informe na etapa 3 o valor aproveitado na declaração.', acao=['Informar', '3'])
            continue
        d = r2(x['apr'] - x['enc'])
        sev = 'erro' if d > 0.01 else ('atencao' if d < -0.01 else 'ok')
        add(id='RET-' + t, cat='Retenções', titulo=f'{nm} retido × aproveitado', sev=sev, rotEsp='Encontrado', rotEnc='Aproveitado', esperado=x['enc'],
            encontrado=x['apr'], diferenca=d, impacto=0 if sev == 'ok' else abs(d),
            resumo='Aproveitado acima do retido' if sev == 'erro' else ('Retenção não aproveitada' if sev == 'atencao' else 'Confere'),
            causa=('Aproveitamento maior que o retido nos documentos: nota não importada, competência errada ou aproveitamento indevido.' if sev == 'erro'
                   else 'Há retenção nos documentos que não foi deduzida: o tributo foi recolhido a maior.' if sev == 'atencao' else ''),
            acao=['Central de retenções', '3'])
    if r2(M['ret']['IRRF']['enc'] + M['ret']['CSLL']['enc']):
        add(id='RET-IRCS', cat='Retenções', titulo='IRRF e CSLL retidos no mês', sev='na',
            resumo=f"IRRF {brl(M['ret']['IRRF']['enc'])} · CSLL {brl(M['ret']['CSLL']['enc'])}",
            causa='Aproveitados no fechamento trimestral de IRPJ e CSLL.', acao=['Abrir trimestre', 'tab:irpjcsll'])

    def comp1(t, cat, causa_err):
        cv, dv, nm = r['tributos'].get(t), r['decl'].get(t), NOME_TRIB[t]
        if cv is None:
            return
        if dv is None:
            add(id='LP-' + t, cat=cat, titulo=f'{nm} do mês × declarado', sev='na', esperado=cv, resumo='Sem valor declarado',
                causa='Informe o valor declarado na etapa 3.', acao=['Informar', '3'])
            return
        d = r2(dv - cv)
        err = abs(d) > tol
        add(id='LP-' + t, cat=cat, titulo=f'{nm} do mês × declarado', sev='erro' if err else 'ok', esperado=cv, encontrado=dv, diferenca=d,
            impacto=abs(d) if err else 0, causa=causa_err if err else '', acao=['Ver cálculo', 'aba:apuracao'])
    causa_pc = (('Confira a segregação de monofásicos (alíquota zero na revenda) e de exportações; ' if M['base']['zero'] or M['base']['isento'] else '')
                + 'receita de outra competência, retenção não deduzida ou alíquota diferente de 0,65%/3% do regime cumulativo.')
    comp1('PIS', 'PIS/Cofins', causa_pc)
    comp1('COFINS', 'PIS/Cofins', causa_pc)
    if M['icms']['tem']:
        comp1('ICMS', 'ICMS', 'Créditos do período, saldo credor anterior, estornos ou débitos de documentos fora dos XML importados.')
    if M['iss']['tem']:
        if M['iss']['aliq'] is None:
            add(id='LP-ISS-ALIQ', cat='ISS', titulo='Alíquota de ISS do município não informada', sev='atencao', rotEnc='Receita de serviços',
                encontrado=M['iss']['base'], causa='Sem a alíquota municipal o ISS do mês não é calculado.', acao=['Informar alíquota', '3'])
        else:
            comp1('ISS', 'ISS', 'Alíquota diferente, serviço com ISS retido pelo tomador, local de incidência em outro município ou nota fora do período.')
    if M['ipi']['tem']:
        comp1('IPI', 'IPI', 'Créditos de entradas, saídas sem destaque ou notas fora do período.')
    add(id='CALC', cat='Cálculo', titulo='Cálculo mensal por natureza e tributo', sev='ok', rotEnc='Tributos do mês', encontrado=r['total_calculado'],
        resumo=f"regra {r['regra']['versao']}", origem=r['regra']['origem'], acao=['Memória de cálculo', 'aba:memoria'])
    return L


def divergencias_ativ(itens):
    """Atividades de serviço cuja natureza na apuração difere da sugerida pelo código da nota."""
    return [it for it in itens if it.get('nfse') and 'svc' in it and it['grupo'] != it.get('sug')]


def _cnae_carteira(app, id_):
    e = app.emp(id_) or {}
    for k, v in e.items():
        if 'cnae' in str(k).lower() and v:
            d = ''.join(ch for ch in str(v) if ch.isdigit())
            if len(d) >= 5:
                return d
    return ''


def _checks_ativ(app, r, add):
    M = r['mes']
    sv = [it for it in M['itens'] if it.get('nfse') and 'svc' in it]
    if M.get('nfseAntigas'):
        add(id='LP-LEITURA', cat='Atividade e retenções', titulo='NFS-e importadas pela leitura antiga', sev='atencao',
            rotEnc='Notas', encontrado=str(M['nfseAntigas']),
            resumo=f"{M['nfseAntigas']} NFS-e sem atividade e com retenção pela regra anterior",
            causa='Estas notas foram importadas antes desta versão: não têm o código do serviço e a retenção da NFS-e Nacional pode estar '
                  'errada (desde a NT 007, vRetCSLL soma PIS + Cofins + CSLL). Importe de novo os XML do mês — a nota é substituída, não duplica.',
            acao=['Importar arquivos', 'importar'])
    if not sv:
        return
    div = divergencias_ativ(sv)
    expl = [it for it in div if it.get('fonteGrupo') == 'definida para a atividade']
    nao = [it for it in div if it not in expl]
    if nao:
        v = r2(sum(it['valor'] for it in nao))
        G = GRUPOS_LP_BASE
        add(id='LP-ATIV', cat='Atividade e retenções', titulo='Atividade da nota diferente da natureza usada na apuração', sev='atencao',
            rotEsp='Receita', rotEnc='Com natureza divergente', esperado=r['rpa'], encontrado=v,
            resumo='; '.join(f"{it['svc'] or 's/ código'}: XML sugere {G.get(it['sug'], {}).get('curto', it['sug'])}, apuração usa {grupo(it['grupo'])['curto']}"
                             for it in nao[:3]) + ('…' if len(nao) > 3 else ''),
            causa='O código de serviço lido do XML (item da LC 116) indica outra natureza/presunção. Defina o tipo de serviço da atividade '
                  'na etapa 1 (vale para todos os meses) ou justifique.', acao=['Definir atividade', '1'])
    if expl:
        add(id='LP-ATIV-DEF', cat='Atividade e retenções', titulo='Atividades com tipo de serviço definido manualmente', sev='na',
            resumo='; '.join(f"{it['svc']}: {grupo(it['grupo'])['curto']} (sugestão {GRUPOS_LP_BASE.get(it['sug'], {}).get('curto', it['sug'])})" for it in expl[:4]),
            causa='Tipo de serviço escolhido no cadastro da empresa, diferente da sugestão pelo código. Confira se continua valendo.',
            acao=['Ver atividades', '1'])
    if not div:
        add(id='LP-ATIV', cat='Atividade e retenções', titulo='Atividades das notas × natureza da apuração', sev='ok',
            resumo=f"{len(sv)} atividade(s): " + ', '.join(f"{it['svc'] or 's/ código'} {grupo(it['grupo'])['curto']}" for it in sv[:4]),
            acao=['Ver atividades', '1'])
    cn = _cnae_carteira(app, r.get('_id')) if r.get('_id') is not None else ''
    if cn:
        outros = sorted({c for it in sv for c in (it.get('cnae') or []) if c[:5] != cn[:5]})
        if outros:
            add(id='LP-ATIV-CNAE', cat='Atividade e retenções', titulo='CNAE das notas diferente do CNAE da empresa', sev='na',
                resumo=f"Empresa {cn} · notas {', '.join(outros[:4])}", causa='Confira se a atividade faturada está no cadastro (CNPJ / alvará).')
    av = [x for x in M.get('retNotas') or [] if x.get('aviso')]
    if av:
        add(id='RET-XML', cat='Retenções', titulo='Retenção informada de forma incoerente no XML', sev='atencao',
            rotEnc='Notas', encontrado=str(len(av)), resumo='; '.join(f"NF {x['n']}: {x['aviso']}" for x in av[:2]) + ('…' if len(av) > 2 else ''),
            causa='Os campos de retenção da nota não batem entre si (código tpRetPisCofins × valores). Confirme com o tomador o que foi retido e, '
                  'se preciso, ajuste em "Outros documentos" na etapa 3.', acao=['Central de retenções', '3'])


# ---------------- situação genérica ----------------
def assin(x):
    return hash_str([x.get('sev'), x.get('esperado'), x.get('encontrado'), x.get('diferenca')])


def sit_calc(ch, rev, hsh, tem):
    b = {'erros': 0, 'alertas': 0, 'pendErros': 0, 'pendAlert': 0, 'aprov': 0, 'just': 0, 'total': 0, 'prog': 0}
    if not tem:
        return {**b, 'cod': 'nao', 'rot': 'Não iniciada', 'cls': 'neutro'}
    for x in ch:
        if x['sev'] == 'na':
            continue
        b['total'] += 1
        if x['sev'] == 'ok':
            b['aprov'] += 1
            continue
        if x['sev'] == 'erro':
            b['erros'] += 1
        else:
            b['alertas'] += 1
        j = None if x.get('bloqueia') else (rev.get('just') or {}).get(x['id'])
        if j and j.get('assin') == assin(x):
            b['just'] += 1
        elif x['sev'] == 'erro':
            b['pendErros'] += 1
        else:
            b['pendAlert'] += 1
    b['prog'] = (b['aprov'] + b['just']) / b['total'] if b['total'] else 0
    v = rev.get('validada')
    if v and v.get('hash') == hsh:
        return {**b, 'v': v, 'cod': 'ressalva' if b['just'] else 'validada', 'rot': 'Validada c/ ressalvas' if b['just'] else 'Validada', 'cls': 'ok'}
    if v:
        return {**b, 'v': v, 'cod': 'alterada', 'rot': 'Alterada após validação', 'cls': 'erro'}
    if b['pendErros']:
        return {**b, 'cod': 'erro', 'rot': 'Com erro', 'cls': 'erro'}
    if b['pendAlert']:
        return {**b, 'cod': 'revisao', 'rot': 'Em revisão', 'cls': 'atencao'}
    return {**b, 'cod': 'pronta', 'rot': 'Pronta para validar', 'cls': 'info'}


_CACHE_SIT: dict = {}


def sit_mes(app, id_, mes):
    if mes == app.comp and (app.RES.get(app.chave(id_)) or {}).get('regime') == 'LP':
        return app.situacao(id_)
    k = (_ver(app), str(id_), mes)
    if k not in _CACHE_SIT:
        if len(_CACHE_SIT) > 3000:
            _CACHE_SIT.clear()
        _CACHE_SIT[k] = _sit_mes(app, id_, mes)
    return _CACHE_SIT[k]


def _sit_mes(app, id_, mes):
    r = apurar_mes(app, id_, mes)
    if not r:
        return {'cod': 'nao', 'rot': 'Sem receita', 'cls': 'neutro', 'pendErros': 0, 'pendAlert': 0}
    return sit_calc(checks_mes(app, r), (app.forms.get(f'{mes}|{id_}') or {}).get('rev') or {}, hash_mes(r), True)


# =================== TRIMESTRAL — IRPJ / CSLL ===================
def tri(app, id_, T):
    R = regra_lp(T['ultimo'])
    ft = app.forms.get(f"{T['id']}|{id_}") or {}
    meses = []
    for mm in T['meses']:
        d = mes_dados(app, id_, mm)
        meses.append({'mes': mm, 'd': d, 'rec': d['rec'], 'sit': sit_mes(app, id_, mm)})
    por_gm = {}
    for i, x in enumerate(meses):
        for it in x['d']['itens']:
            a = por_gm.setdefault(it['grupo'], [0.0, 0.0, 0.0])
            a[i] = r2(a[i] + it['valor'])
    por_g = {g: r2(sum(a)) for g, a in por_gm.items()}
    serv_ativ, ret_notas, antigas = {}, [], 0
    for i, x in enumerate(meses):
        antigas += x['d'].get('nfseAntigas') or 0
        for rn in x['d'].get('retNotas') or []:
            ret_notas.append({**rn, 'mes': x['mes']})
        for it in x['d']['itens']:
            if not (it.get('nfse') and 'svc' in it):
                continue
            a = serv_ativ.setdefault(it['svc'], {'it': it['svc'], 'x': it.get('svcX') or '', 'sug': it.get('sug'), 'sugMotivo': it.get('sugMotivo'),
                                                 'grupo': it['grupo'], 'fonte': it.get('fonteGrupo'), 'meses': [0.0, 0.0, 0.0], 'grupos': set()})
            a['meses'][i] = r2(a['meses'][i] + it['valor'])
            a['grupos'].add(it['grupo'])
            a['grupo'] = it['grupo']
    for a in serv_ativ.values():
        a['total'] = r2(sum(a['meses']))
        a['grupos'] = sorted(a['grupos'])
        g = grupo(a['grupo'])
        a['pIrpj'], a['pCsll'] = g['irpj'], g['csll']
    rec_op = r2(sum(por_g.values()))
    a = ft.get('adic') or {}
    adic = {k: num(a.get(k)) or 0 for k in ('integral', 'financeira', 'ganho', 'outras')}
    adic_tot = r2(sum(adic.values()))
    irrf_notas = r2(sum(x['d']['retEnc']('IRRF') for x in meses))
    csll_notas = r2(sum(x['d']['retEnc']('CSLL') for x in meses))
    irrf = r2(irrf_notas + (num((ft.get('ret') or {}).get('IRRF')) or 0))
    csll_ret = r2(csll_notas + (num((ft.get('ret') or {}).get('CSLL')) or 0))
    outras_ded = num((ft.get('ded') or {}).get('IRPJ')) or 0
    maj = None
    if R['maj']:
        antes, mm = [], f"{T['ano']}-01"
        while mm < T['meses'][0]:
            antes.append(mm)
            mm = mes_add(mm, 1)
        faltam, acum_auto = [], 0.0
        for mm in antes:
            d = mes_dados(app, id_, mm)
            if not d['tem']:
                faltam.append(mm)
            acum_auto += d['rec']
        acum_auto = r2(acum_auto)
        inf = num(ft.get('acumAnt'))
        acum_ant = inf if inf is not None else acum_auto
        disp = r2(max(0, R['maj']['limiteTri'] * T['q'] - acum_ant))
        maj = {'acumAnt': acum_ant, 'acumAuto': acum_auto, 'informado': inf is not None, 'faltam': [] if inf is not None else faltam,
               'disponivel': disp, 'dentro': r2(min(rec_op, disp)), 'excedente': r2(max(0, rec_op - disp)), 'acumAno': r2(acum_ant + rec_op),
               'limiteAno': R['maj']['limiteAno'], 'limiteTri': R['maj']['limiteTri'], 'fator': R['maj']['fator'],
               'irpj': T['meses'][0] >= R['maj']['irpjDe'], 'csll': T['meses'][0] >= R['maj']['csllDe'],
               'irpjDe': R['maj']['irpjDe'], 'csllDe': R['maj']['csllDe']}
    grupos = []
    for g, v in por_g.items():
        if not v:
            continue
        d = grupo(g)
        exc = r2(maj['excedente'] * v / rec_op) if maj and rec_op else 0
        eI = exc if maj and maj['irpj'] else 0
        eC = exc if maj and maj['csll'] else 0
        f = maj['fator'] if maj else 1
        grupos.append({'grupo': g, 'rot': d['rot'], 'curto': d['curto'], 'receita': v, 'meses': por_gm[g], 'pIrpj': d['irpj'], 'pCsll': d['csll'],
                       'exc': exc, 'excI': eI, 'excC': eC, 'baseIrpj': r2((v - eI) * d['irpj'] + eI * d['irpj'] * f),
                       'baseCsll': r2((v - eC) * d['csll'] + eC * d['csll'] * f)})
    grupos.sort(key=lambda x: -x['receita'])
    pres_i, pres_c = r2(sum(g['baseIrpj'] for g in grupos)), r2(sum(g['baseCsll'] for g in grupos))
    base_irpj, base_csll = r2(pres_i + adic_tot), r2(pres_c + adic_tot)
    ini = (app.inicio_emp(id_)[0] or '')[:7]
    meses_ativ = len([mm for mm in T['meses'] if mm >= ini]) if ini and T['meses'][0] < ini <= T['ultimo'] else 3
    lim_adic = R['adicionalMes'] * meses_ativ
    irpj_n = r2(base_irpj * R['aliq']['IRPJ'])
    adicional = r2(max(0, base_irpj - lim_adic) * R['aliq']['ADIC'])
    irpj = r2(irpj_n + adicional)
    csll = r2(base_csll * R['aliq']['CSLL'])
    irpj_pagar, csll_pagar = r2(max(0, irpj - irrf - outras_ded)), r2(max(0, csll - csll_ret))
    imp_maj = None
    if maj and maj['excedente']:
        sem_i = r2(sum(g['receita'] * g['pIrpj'] for g in grupos) + adic_tot)
        sem_c = r2(sum(g['receita'] * g['pCsll'] for g in grupos) + adic_tot)
        irpj_sem = r2(sem_i * R['aliq']['IRPJ'] + max(0, sem_i - lim_adic) * R['aliq']['ADIC'])
        imp_maj = {'irpj': r2(irpj - irpj_sem), 'csll': r2(csll - sem_c * R['aliq']['CSLL']), 'baseIrpjSem': sem_i, 'baseCsllSem': sem_c}
    dd = ft.get('decl') or {}
    decl = {k: num(dd.get(k)) for k in ('receita', 'baseIrpj', 'irpjNormal', 'adicional', 'irpjPagar', 'baseCsll', 'csll', 'csllPagar', 'irrfUtil', 'csllUtil')}
    return {'regime': 'LP', 'escopo': 'tri', 'id': T['id'], 'ano': T['ano'], 'q': T['q'], 'meses': T['meses'], 'ultimo': T['ultimo'],
            'regra': {'versao': R['versao'], 'origem': R['origem']},
            'mesesInfo': [{'mes': x['mes'], 'rec': x['rec'], 'sit': x['sit'], 'tem': x['d']['tem']} for x in meses],
            'grupos': grupos, 'porG': por_g, 'porGM': por_gm, 'recOp': rec_op, 'adic': adic, 'adicTot': adic_tot, 'presI': pres_i, 'presC': pres_c,
            'baseIrpj': base_irpj, 'baseCsll': base_csll, 'limAdic': lim_adic, 'mesesAtiv': meses_ativ, 'irpjN': irpj_n, 'adicional': adicional,
            'irpj': irpj, 'irrf': irrf, 'irrfNotas': irrf_notas, 'outrasDed': outras_ded, 'irpjPagar': irpj_pagar, 'csll': csll, 'csllRet': csll_ret,
            'csllNotas': csll_notas, 'csllPagar': csll_pagar, 'maj': maj, 'impMaj': imp_maj, 'decl': decl, 'saude': bool(por_g.get('saude')),
            'saudeOk': all((ft.get('saude') or {}).get(k) for k, _ in SAUDE_REQ), 'obrig': ft.get('obrig') or {},
            'servAtiv': sorted(serv_ativ.values(), key=lambda a: -a['total']), 'retNotas': ret_notas, 'nfseAntigas': antigas,
            'retNotasTot': {t: r2(sum(x[t] for x in ret_notas)) for t in ('IRRF', 'CSLL', 'PIS', 'COFINS', 'INSS')}}


def hash_tri(q):
    return hash_str([[[g['grupo'], g['receita']] for g in q['grupos']], q['adic'], q['irrf'], q['csllRet'], q['outrasDed'], q['decl'],
                     [q['maj']['acumAnt'], q['maj']['excedente']] if q['maj'] else None, q['saudeOk'], q['regra']['versao']])


def tri_checks(q, tol=0.05):
    L = []
    add = _add(L)
    M = q['maj']

    def cmp(id_, cat, titulo, calc, dv, causa):
        if dv is None:
            add(id=id_, cat=cat, titulo=titulo, sev='na', esperado=calc, rotEsp='Calculado', resumo='Sem valor declarado',
                causa='Informe o valor declarado na subaba Validação do trimestre.')
            return False
        df = r2(dv - calc)
        err = abs(df) > tol
        add(id=id_, cat=cat, titulo=titulo, sev='erro' if err else 'ok', rotEsp='Calculado', rotEnc='Declarado', esperado=calc, encontrado=dv,
            diferenca=df, impacto=abs(df) if err else 0, causa=causa if err else '')
        return err
    nao_val = [x for x in q['mesesInfo'] if x['sit']['cod'] not in ('validada', 'ressalva')]
    if nao_val:
        add(id='TRI-MESES', cat='Meses', titulo='Meses do trimestre sem validação mensal', sev='erro', bloqueia=True, rotEsp='Meses', rotEnc='Validados',
            esperado='3', encontrado=str(3 - len(nao_val)), resumo=' · '.join(f"{mes_longo(x['mes'])}: {x['sit']['rot'].lower()}" for x in nao_val),
            causa='O fechamento de IRPJ e CSLL usa as receitas validadas dos três meses. Valide os meses pendentes antes de fechar.',
            acao=[f"Abrir {mes_longo(nao_val[0]['mes'])}", 'comp:' + nao_val[0]['mes']])
    else:
        add(id='TRI-MESES', cat='Meses', titulo='Três meses validados', sev='ok', resumo='Receitas consolidadas das apurações mensais')
    if q['porG'].get('pendente'):
        add(id='TRI-CLASSIF', cat='Receitas', titulo='Receita sem classificação no trimestre', sev='erro', bloqueia=True, rotEnc='Sem natureza',
            encontrado=q['porG']['pendente'], causa='Receita sem natureza usa 32% de presunção. Classifique no mês de origem.')
    cmp('TRI-REC', 'Receita', 'Receita do trimestre: sistema × declarado', q['recOp'], q['decl']['receita'],
        'Mês com receita diferente da escrituração, nota de outra competência ou cancelamento não considerado.')
    if cmp('TRI-BASE-IRPJ', 'IRPJ', 'Base de cálculo do IRPJ: calculada × declarada', q['baseIrpj'], q['decl']['baseIrpj'],
           'Percentual de presunção diferente por atividade, receita financeira, ganho de capital ou outras adições não incluídas.') \
            and q['impMaj'] and abs(q['decl']['baseIrpj'] - q['impMaj']['baseIrpjSem']) <= 1:
        L[-1]['titulo'] = 'Base do IRPJ sem o acréscimo de 2026'
        L[-1]['causa'] = 'A base declarada bate com o cálculo sem o acréscimo de 10% na presunção sobre a receita excedente (LC 224/2025).'
    cmp('TRI-IRPJ', 'IRPJ', 'IRPJ normal (15%): calculado × informado', q['irpjN'], q['decl']['irpjNormal'], 'Diferença na base de cálculo.')
    if q['decl']['adicional'] is not None and q['decl']['adicional'] == 0 and q['adicional'] > 0:
        add(id='TRI-ADIC', cat='IRPJ', titulo='Adicional do IRPJ não considerado', sev='erro', rotEsp='Calculado', rotEnc='Informado', esperado=q['adicional'],
            encontrado=0, diferenca=r2(-q['adicional']), impacto=q['adicional'],
            causa=f"A base passou de {brl(q['limAdic'])} no trimestre: incide o adicional de 10% sobre o excedente.")
    else:
        cmp('TRI-ADIC', 'IRPJ', 'Adicional do IRPJ (10%): calculado × informado', q['adicional'], q['decl']['adicional'],
            f"Adicional de 10% sobre a base que excede {brl(q['limAdic'])} no trimestre (R$ 20 mil por mês de atividade).")
    cmp('TRI-IRPJ-PAGAR', 'IRPJ', 'IRPJ a pagar: calculado × DARF', q['irpjPagar'], q['decl']['irpjPagar'], 'IRRF ou outras deduções diferentes, ou diferença na base.')
    if cmp('TRI-BASE-CSLL', 'CSLL', 'Base de cálculo da CSLL: calculada × declarada', q['baseCsll'], q['decl']['baseCsll'],
           'Percentual de presunção da CSLL diferente do IRPJ por atividade (não copiar), ou receitas integrais não incluídas.') \
            and q['impMaj'] and abs(q['decl']['baseCsll'] - q['impMaj']['baseCsllSem']) <= 1:
        L[-1]['titulo'] = 'Base da CSLL sem o acréscimo de 2026'
        L[-1]['causa'] = 'A base declarada bate com o cálculo sem o acréscimo de 10% (vigente para a CSLL desde abr/2026).'
    cmp('TRI-CSLL', 'CSLL', 'CSLL (9%): calculada × informada', q['csll'], q['decl']['csll'], 'Diferença na base de cálculo da CSLL.')
    cmp('TRI-CSLL-PAGAR', 'CSLL', 'CSLL a pagar: calculada × DARF', q['csllPagar'], q['decl']['csllPagar'], 'CSLL retida aproveitada diferente ou diferença na base.')
    for t, enc, util in (('IRRF', q['irrf'], q['decl']['irrfUtil']), ('CSLL', q['csllRet'], q['decl']['csllUtil'])):
        if not enc and util is None:
            continue
        if util is None:
            add(id='TRI-RET-' + t, cat='Retenções', titulo=f'{t} retido no trimestre', sev='na', rotEnc='Encontrado', encontrado=enc, resumo='Utilização não informada')
            continue
        df = r2(util - enc)
        sev = 'erro' if df > 0.01 else ('atencao' if df < -0.01 else 'ok')
        add(id='TRI-RET-' + t, cat='Retenções', titulo=f'{t} retido: encontrado × utilizado', sev=sev, rotEsp='Encontrado', rotEnc='Utilizado', esperado=enc,
            encontrado=util, diferenca=df, impacto=0 if sev == 'ok' else abs(df),
            causa='Utilizado acima do retido nos documentos.' if sev == 'erro' else (f'{t} disponível e não utilizado: tributo pago a maior.' if sev == 'atencao' else ''))
    if M:
        if M['faltam']:
            add(id='TRI-2026-ACUM', cat='Presunção 2026', titulo='Receita acumulada no ano incompleta', sev='atencao',
                resumo='Faltam ' + ', '.join(nome_mes(x) for x in M['faltam']),
                causa='O acréscimo depende da receita acumulada no ano. Lance os meses anteriores ou informe o acumulado na subaba Regra 2026.', acao=['Regra 2026', 'tri:regra'])
        imp = r2(((q['impMaj'] or {}).get('irpj') or 0) + ((q['impMaj'] or {}).get('csll') or 0))
        if M['excedente'] > 0:
            add(id='TRI-2026', cat='Presunção 2026', titulo='Receita acima do limite: presunção acrescida de 10%', sev='atencao', rotEsp='Dentro do limite',
                rotEnc='Excedente', esperado=M['dentro'], encontrado=M['excedente'], impacto=imp,
                causa=f"Percentual majorado só sobre {brl(M['excedente'])}{'' if M['csll'] else '; na CSLL o acréscimo só vale a partir de abr/2026'}. Confira se a declaração considerou o acréscimo.",
                acao=['Regra 2026', 'tri:regra'])
        else:
            add(id='TRI-2026', cat='Presunção 2026', titulo='Dentro do limite de R$ 5 milhões', sev='ok', resumo=f"{pctN(M['acumAno'] / M['limiteAno'], 0)} do limite anual usado")
    if q['saude']:
        v = q['porG']['saude']
        imp = r2(v * ((0.32 - 0.08) * ALIQ_LP['IRPJ'] + (0.32 - 0.12) * ALIQ_LP['CSLL']))
        if q['saudeOk']:
            add(id='TRI-SAUDE', cat='Presunção', titulo='Requisitos de serviços hospitalares', sev='ok', resumo='Checklist confirmado')
        else:
            add(id='TRI-SAUDE', cat='Presunção', titulo='Requisitos de serviços hospitalares não confirmados', sev='atencao', impacto=imp, rotEnc='Receita com 8%/12%',
                encontrado=v, causa='A presunção reduzida exige sociedade empresária, atividade elegível e normas da Anvisa. Sem os requisitos a receita vai a 32%.',
                acao=['Checklist', 'tri:irpj'])
    if q.get('nfseAntigas'):
        add(id='TRI-LEITURA', cat='Atividade e retenções', titulo='NFS-e do trimestre importadas pela leitura antiga', sev='atencao',
            rotEnc='Notas', encontrado=str(q['nfseAntigas']),
            causa='Importe de novo os XML de NFS-e do trimestre: a leitura nova pega o código da atividade e a retenção de IRRF/CSLL '
                  'direto do XML (NT 007: vRetCSLL soma PIS + Cofins + CSLL). A nota é substituída, não duplica.', acao=['Importar arquivos', 'importar'])
    todas = [a for a in q.get('servAtiv') or [] if a['grupo'] != a['sug']]
    dv = [a for a in todas if a.get('fonte') != 'definida para a atividade']
    exp = [a for a in todas if a not in dv]
    if exp:
        add(id='TRI-ATIV-DEF', cat='Presunção', titulo='Atividades com tipo de serviço definido manualmente', sev='na',
            resumo='; '.join(f"{a['it']}: {grupo(a['grupo'])['curto']} {pctN(a['pIrpj'], 0)} (código sugere {grupo(a['sug'])['curto']})" for a in exp[:3]),
            causa='Escolha feita no cadastro da empresa. Confira se a atividade realmente se enquadra (ex.: requisitos de serviço hospitalar, '
                  'construção com materiais).', acao=['Atividades', 'tri:irpj'])
    if dv:
        imp = 0.0
        for a in dv:
            gs, gu = grupo(a['sug']), grupo(a['grupo'])
            imp += abs(a['total'] * ((gs['irpj'] - gu['irpj']) * ALIQ_LP['IRPJ'] + (gs['csll'] - gu['csll']) * ALIQ_LP['CSLL']))
        add(id='TRI-ATIV', cat='Presunção', titulo='Atividade do XML com presunção diferente da usada', sev='atencao',
            rotEnc='Receita', encontrado=r2(sum(a['total'] for a in dv)), impacto=r2(imp),
            resumo='; '.join(f"{a['it'] or 's/ código'}: {grupo(a['grupo'])['curto']} {pctN(a['pIrpj'], 0)} (código sugere {grupo(a['sug'])['curto']} "
                             f"{pctN(grupo(a['sug'])['irpj'], 0)})" for a in dv[:3]),
            causa='Confira o tipo de serviço de cada atividade na subaba IRPJ (Atividades das notas). Se a escolha estiver certa, justifique.',
            acao=['Atividades', 'tri:irpj'])
    if not q['adic']['financeira']:
        add(id='TRI-FIN', cat='Receitas', titulo='Receitas financeiras no trimestre', sev='na', resumo='Nenhuma informada',
            causa='Rendimentos de aplicação entram integralmente na base, com IRRF compensável.')
    add(id='TRI-CALC', cat='Cálculo', titulo='Cálculo por atividade, IRPJ e CSLL separados', sev='ok', resumo=f"regra {q['regra']['versao']}", origem=q['regra']['origem'])
    return L


def sit_tri(app, id_, T):
    q = tri(app, id_, T)
    ch = tri_checks(q, app.param()['tolerancia'])
    ft = app.forms.get(f"{T['id']}|{id_}") or {}
    s = sit_calc(ch, ft.get('rev') or {}, hash_tri(q), q['recOp'] > 0)
    rot = {'validada': 'Fechado', 'ressalva': 'Fechado c/ ressalvas', 'pronta': 'Pronto para fechar', 'nao': 'Sem receita',
           'alterada': 'Alterado após fechamento'}.get(s['cod'])
    if rot:
        s = {**s, 'rot': rot}
    return q, ch, s


def tri_just(app, id_, T, ch, xid, texto):
    x = next((y for y in ch if y['id'] == xid), None)
    if not x:
        return 'Validação não encontrada.'
    texto = str(texto or '').strip()
    if x['sev'] == 'erro' and len(texto) < 10:
        return 'Erro crítico: descreva a justificativa (mínimo 10 caracteres).'
    ft = app.forms.setdefault(f"{T['id']}|{id_}", {})
    ft.setdefault('rev', {}).setdefault('just', {})[xid] = {'texto': texto, 'sev': x['sev'], 'assin': assin(x), 'por': app.usuario(),
                                                             'em': agora_iso(), 'titulo': x['titulo']}
    app.salvar_forms()
    app.registrar(id_, 'Divergência do trimestre justificada' if x['sev'] == 'erro' else 'Alerta do trimestre revisado', campo=x['titulo'], para=texto or 'revisado')
    return None


def tri_desjust(app, id_, T, xid):
    ft = app.forms.get(f"{T['id']}|{id_}") or {}
    j = ((ft.get('rev') or {}).get('just') or {}).pop(xid, None)
    if j:
        app.salvar_forms()
        app.registrar(id_, 'Justificativa do trimestre removida', campo=j.get('titulo'))


def fechar_tri(app, id_, T):
    q, ch, s = sit_tri(app, id_, T)
    if s['pendErros'] or s['pendAlert']:
        return f"Resolva {s['pendErros']} erro(s) e {s['pendAlert']} alerta(s) antes de fechar o trimestre."
    ft = app.forms.setdefault(f"{T['id']}|{id_}", {})
    em, por = agora_iso(), app.usuario()
    ft.setdefault('rev', {})['validada'] = {'em': em, 'por': por, 'hash': hash_tri(q), 'regra': q['regra']['versao']}
    ft['fechamento'] = {'em': em, 'por': por, 'regra': q['regra']['versao'], 'irpjPagar': q['irpjPagar'], 'csllPagar': q['csllPagar'],
                        'baseIrpj': q['baseIrpj'], 'baseCsll': q['baseCsll'], 'adicional': q['adicional'], 'recOp': q['recOp'],
                        'checks': [{k: x.get(k) for k in ('id', 'titulo', 'sev', 'esperado', 'encontrado', 'diferenca')} for x in ch]}
    app.salvar_forms()
    app.registrar(id_, f"Trimestre {T['q']}/{T['ano']} fechado", para=f"IRPJ {brl(q['irpjPagar'])} · CSLL {brl(q['csllPagar'])}")
    return None


def reabrir_tri(app, id_, T):
    ft = app.forms.get(f"{T['id']}|{id_}") or {}
    (ft.get('rev') or {}).pop('validada', None)
    ft.pop('fechamento', None)
    app.salvar_forms()
    app.registrar(id_, f"Trimestre {T['q']}/{T['ano']} reaberto")


def salvar(app, id_, extra=None):
    r = apurar_caso(app, id_)
    if not r:
        return 'Lance as receitas do mês antes de salvar.'
    raiz, _ = app.import_de(id_)
    from .servico import _limpo
    app.est.apur.setdefault(raiz, {})[r['comp']] = {
        'salvoEm': agora_iso(), 'empresa': app.nome(id_), 'cnpj': app.cnpj(id_), 'regime': 'LP', 'rpa': r['rpa'],
        'itens': [{'descricao': it['descricao'], 'grupo': it['grupo'], 'valor': it['valor'], 'origem': it['origem']} for it in r['mes']['itens']],
        'regra': r['regra']['versao'], 'resultado': _limpo(r), **(extra or {})}
    app.est.salvar('apur')
    if not extra:
        app.registrar(id_, 'Apuração salva', para=brl(r['total_calculado']))
    return None
