"""Atividades e anexos do Simples Nacional pela LC 123/2006, art. 18 (redação da LC 155/2016).

Cada atividade diz em que anexo a receita é tributada e qual é a base legal. 'FATOR_R' = depende do
Fator R (folha 12m ÷ receita 12m, art. 18, §§ 5º-J, 5º-K, 5º-M e 24):
  • § 5º-I (ex.: medicina veterinária): Anexo V; vai para o Anexo III se o Fator R for ≥ 28% (§ 5º-J).
  • § 5º-B, XVI, XVIII a XXI, e § 5º-D: Anexo III; vai para o Anexo V se o Fator R for < 28% (§ 5º-M).
Os CNAE são exemplos para busca; o enquadramento oficial por CNAE é o Anexo VI da Res. CGSN 140/2018.
"""
from __future__ import annotations

L = 'art. 18'

# (código, atividade, anexo, base legal, CNAE de exemplo, grupo)
_A = [
    # ---- comércio e indústria (§ 4º)
    ('COM', 'Revenda de mercadorias (comércio)', 'I', f'{L}, § 4º, I', [], 'Comércio e indústria'),
    ('IND', 'Venda de mercadorias industrializadas pelo contribuinte (indústria)', 'II', f'{L}, § 4º, II', [], 'Comércio e indústria'),

    # ---- Fator R · Anexo V → III (§ 5º-I)
    ('VET', 'Medicina veterinária', 'FATOR_R', f'{L}, § 5º-I, II', ['7500-1/00'], 'Fator R · Anexo V (III se Fator R ≥ 28%)'),
    ('DESP', 'Serviços de comissaria, despachantes, tradução e interpretação', 'FATOR_R', f'{L}, § 5º-I, V', [], 'Fator R · Anexo V (III se Fator R ≥ 28%)'),
    ('ENG', 'Engenharia, medição, cartografia, topografia, geologia, geodésia, testes, suporte e análises técnicas e tecnológicas, '
            'pesquisa, design, desenho e agronomia', 'FATOR_R', f'{L}, § 5º-I, VI', ['7112-0/00'], 'Fator R · Anexo V (III se Fator R ≥ 28%)'),
    ('REPR', 'Representação comercial e demais atividades de intermediação de negócios e serviços de terceiros', 'FATOR_R',
     f'{L}, § 5º-I, VII', [], 'Fator R · Anexo V (III se Fator R ≥ 28%)'),
    ('PERI', 'Perícia, leilão e avaliação', 'FATOR_R', f'{L}, § 5º-I, VIII', [], 'Fator R · Anexo V (III se Fator R ≥ 28%)'),
    ('CONS', 'Auditoria, economia, consultoria, gestão, organização, controle e administração', 'FATOR_R', f'{L}, § 5º-I, IX',
     ['7020-4/00'], 'Fator R · Anexo V (III se Fator R ≥ 28%)'),
    ('JORN', 'Jornalismo e publicidade', 'FATOR_R', f'{L}, § 5º-I, X', [], 'Fator R · Anexo V (III se Fator R ≥ 28%)'),
    ('AGEN', 'Agenciamento, exceto de mão de obra', 'FATOR_R', f'{L}, § 5º-I, XI', [], 'Fator R · Anexo V (III se Fator R ≥ 28%)'),
    ('INTEL', 'Outras atividades intelectuais, técnicas, científicas, desportivas, artísticas ou culturais (profissão regulamentada ou não)',
     'FATOR_R', f'{L}, § 5º-I, XII', [], 'Fator R · Anexo V (III se Fator R ≥ 28%)'),

    # ---- Fator R · Anexo III → V (§ 5º-M)
    ('FISIO', 'Fisioterapia', 'FATOR_R', f'{L}, § 5º-B, XVI, c/c § 5º-M, I', ['8650-0/04'], 'Fator R · Anexo III (V se Fator R < 28%)'),
    ('ARQ', 'Arquitetura e urbanismo', 'FATOR_R', f'{L}, § 5º-B, XVIII, c/c § 5º-M, I', ['7111-1/00'], 'Fator R · Anexo III (V se Fator R < 28%)'),
    ('MED', 'Medicina, inclusive laboratorial, e enfermagem', 'FATOR_R', f'{L}, § 5º-B, XIX, c/c § 5º-M, I', [], 'Fator R · Anexo III (V se Fator R < 28%)'),
    ('ODONTO', 'Odontologia e prótese dentária', 'FATOR_R', f'{L}, § 5º-B, XX, c/c § 5º-M, I', ['8630-5/04'], 'Fator R · Anexo III (V se Fator R < 28%)'),
    ('PSI', 'Psicologia, psicanálise, terapia ocupacional, acupuntura, podologia, fonoaudiologia, clínicas de nutrição e de vacinação e bancos de leite',
     'FATOR_R', f'{L}, § 5º-B, XXI, c/c § 5º-M, I', ['8650-0/03'], 'Fator R · Anexo III (V se Fator R < 28%)'),
    ('IMOV', 'Administração e locação de imóveis de terceiros', 'FATOR_R', f'{L}, § 5º-D, I, c/c § 5º-M, II', ['6822-6/00'],
     'Fator R · Anexo III (V se Fator R < 28%)'),
    ('DANCA', 'Academias de dança, capoeira, ioga e artes marciais', 'FATOR_R', f'{L}, § 5º-D, II, c/c § 5º-M, II', [],
     'Fator R · Anexo III (V se Fator R < 28%)'),
    ('ACAD', 'Academias de atividades físicas, desportivas, natação e escolas de esportes', 'FATOR_R', f'{L}, § 5º-D, III, c/c § 5º-M, II',
     ['9313-1/00'], 'Fator R · Anexo III (V se Fator R < 28%)'),
    ('SOFT', 'Elaboração de programas de computador, inclusive jogos, desenvolvidos no estabelecimento do optante', 'FATOR_R',
     f'{L}, § 5º-D, IV, c/c § 5º-M, II', ['6201-5/01'], 'Fator R · Anexo III (V se Fator R < 28%)'),
    ('LIC', 'Licenciamento ou cessão de direito de uso de programas de computação', 'FATOR_R', f'{L}, § 5º-D, V, c/c § 5º-M, II',
     ['6203-1/00'], 'Fator R · Anexo III (V se Fator R < 28%)'),
    ('WEB', 'Planejamento, confecção, manutenção e atualização de páginas eletrônicas (no estabelecimento do optante)', 'FATOR_R',
     f'{L}, § 5º-D, VI, c/c § 5º-M, II', [], 'Fator R · Anexo III (V se Fator R < 28%)'),
    ('ESTAN', 'Montagem de estandes para feiras', 'FATOR_R', f'{L}, § 5º-D, IX, c/c § 5º-M, II', [], 'Fator R · Anexo III (V se Fator R < 28%)'),
    ('LAB', 'Laboratórios de análises clínicas ou de patologia clínica', 'FATOR_R', f'{L}, § 5º-D, XII, c/c § 5º-M, II', [],
     'Fator R · Anexo III (V se Fator R < 28%)'),
    ('IMAG', 'Tomografia, diagnóstico médico por imagem, registros gráficos, métodos óticos e ressonância magnética', 'FATOR_R',
     f'{L}, § 5º-D, XIII, c/c § 5º-M, II', [], 'Fator R · Anexo III (V se Fator R < 28%)'),
    ('PROT', 'Serviços de prótese em geral', 'FATOR_R', f'{L}, § 5º-D, XIV, c/c § 5º-M, II', [], 'Fator R · Anexo III (V se Fator R < 28%)'),

    # ---- Anexo III (sem Fator R)
    ('ENS', 'Creche, pré-escola, ensino fundamental, médio, técnico, profissional, línguas, artes, preparatórios, cursos gerenciais e escolas livres',
     'III', f'{L}, § 5º-B, I', [], 'Anexo III'),
    ('CORR', 'Agência terceirizada de correios', 'III', f'{L}, § 5º-B, II', [], 'Anexo III'),
    ('VIAG', 'Agência de viagem e turismo', 'III', f'{L}, § 5º-B, III', ['7911-2/00'], 'Anexo III'),
    ('CFC', 'Centro de formação de condutores (autoescola)', 'III', f'{L}, § 5º-B, IV', [], 'Anexo III'),
    ('LOT', 'Agência lotérica', 'III', f'{L}, § 5º-B, V', [], 'Anexo III'),
    ('MANUT', 'Instalação, reparos e manutenção em geral; usinagem, solda, tratamento e revestimento em metais', 'III', f'{L}, § 5º-B, IX', [], 'Anexo III'),
    ('TRANSP', 'Transporte municipal de passageiros', 'III', f'{L}, § 5º-B, XIII', [], 'Anexo III'),
    ('CONT', 'Escritório de serviços contábeis', 'III', f'{L}, § 5º-B, XIV', ['6920-6/01'], 'Anexo III'),
    ('CINE', 'Produções cinematográficas, audiovisuais, artísticas e culturais, exibição ou apresentação', 'III', f'{L}, § 5º-B, XV', [], 'Anexo III'),
    ('SEG', 'Corretagem de seguros', 'III', f'{L}, § 5º-B, XVII', ['6622-3/00'], 'Anexo III'),
    ('SERV3', 'Demais serviços não previstos nos Anexos IV ou V', 'III', f'{L}, § 5º-F', [], 'Anexo III'),

    # ---- Anexo IV (CPP fora do DAS)
    ('CONSTR', 'Construção de imóveis e obras de engenharia, inclusive subempreitada; paisagismo e decoração de interiores', 'IV',
     f'{L}, § 5º-C, I', ['4120-4/00'], 'Anexo IV (CPP fora do DAS)'),
    ('LIMP', 'Vigilância, limpeza ou conservação', 'IV', f'{L}, § 5º-C, VI', ['8121-4/00', '8011-1/01'], 'Anexo IV (CPP fora do DAS)'),
    ('ADV', 'Serviços advocatícios', 'IV', f'{L}, § 5º-C, VII', ['6911-7/01'], 'Anexo IV (CPP fora do DAS)'),
]

ATIVIDADES = {c: {'cod': c, 'nome': n, 'anexo': a, 'base': b, 'cnae': cn, 'grupo': g} for c, n, a, b, cn, g in _A}
GRUPOS_ORDEM = list(dict.fromkeys(g for *_, g in _A))


def regra_texto(cod: str) -> str:
    """Como a atividade é tributada, em uma linha, com a base legal."""
    a = ATIVIDADES.get(cod)
    if not a:
        return ''
    if a['anexo'] == 'FATOR_R':
        if '5º-I' in a['base']:
            return f"Anexo V; Anexo III se o Fator R for ≥ 28% (LC 123/2006, {a['base']}, c/c § 5º-J)"
        return f"Anexo III; Anexo V se o Fator R for < 28% (LC 123/2006, {a['base']})"
    extra = ' — CPP recolhida fora do DAS' if a['anexo'] == 'IV' else ''
    return f"Anexo {a['anexo']} (LC 123/2006, {a['base']}){extra}"


def rotulo(cod: str) -> str:
    a = ATIVIDADES.get(cod)
    return a['nome'] if a else ''


def buscar(q: str):
    """Filtra por nome, base legal ou CNAE (com ou sem pontuação)."""
    q = (q or '').strip().lower()
    qd = ''.join(ch for ch in q if ch.isdigit())
    out = []
    for a in ATIVIDADES.values():
        txt = (a['nome'] + ' ' + a['base'] + ' ' + a['grupo']).lower()
        if not q or q in txt or (qd and any(qd in ''.join(ch for ch in c if ch.isdigit()) for c in a['cnae'])):
            out.append(a)
    return out
