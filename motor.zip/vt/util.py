"""Funções utilitárias (números, datas, CNPJ, formatação pt-BR)."""
from __future__ import annotations

import json
import re
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP

MES_CURTO = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez']
MES_LONGO = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto',
             'Setembro', 'Outubro', 'Novembro', 'Dezembro']


def r2(x) -> float:
    """Arredonda para 2 casas (meio para cima), como Math.round(x*100)/100."""
    if x is None:
        return 0.0
    return float(Decimal(str(float(x))).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP))


def num(v):
    """Converte para float; vazio/inválido -> None."""
    if v is None or v == '':
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    if not s:
        return None
    s = s.replace('R$', '').replace(' ', '')
    if s.count(',') > 1:                    # "14,937,77" (gravado errado antes): vírgulas extras eram milhar
        s = s.replace(',', '', s.count(',') - 1)
    if ',' in s:
        s = s.replace('.', '').replace(',', '.')
    elif s.count('.') > 1:                  # "1.234.567": só separadores de milhar
        s = s.replace('.', '')
    try:
        return float(s)
    except ValueError:
        return None


def _fmt_num(x, casas=2) -> str:
    s = f"{float(x):,.{casas}f}"
    return s.replace(',', 'X').replace('.', ',').replace('X', '.')


def valN(x) -> str:
    if x is None:
        return '—'
    return _fmt_num(x, 2)


def brl(x) -> str:
    if x is None:
        return '—'
    try:
        x = float(x)
    except (TypeError, ValueError):
        return '—'
    s = _fmt_num(abs(x), 2)
    return ('-R$ ' if x < 0 else 'R$ ') + s


def pct(x, c=4) -> str:
    if x is None:
        return '—'
    return _fmt_num(x * 100, c) + '%'


def pctN(x, c=2) -> str:
    return _fmt_num(x * 100, c) + '%'


def mes_add(c: str, n: int) -> str:
    y, m = map(int, c.split('-'))
    t = y * 12 + (m - 1) + n
    return f"{t // 12:04d}-{t % 12 + 1:02d}"


def meses_entre(a: str, b: str) -> int:
    ya, ma = map(int, a.split('-'))
    yb, mb = map(int, b.split('-'))
    return (yb * 12 + mb) - (ya * 12 + ma)


def nome_mes(m: str) -> str:
    if not m or '-' not in m:
        return m or ''
    y, mm = m.split('-')[:2]
    return f"{mm}/{y}"


def mes_curto(m: str) -> str:
    return MES_CURTO[int(m[5:7]) - 1]


def mes_longo(m: str) -> str:
    return MES_LONGO[int(m[5:7]) - 1]


def data_br(d: str) -> str:
    if not d:
        return ''
    return '/'.join(reversed(d.split('-')))


def data_hora(iso: str) -> str:
    try:
        dt = datetime.fromisoformat(iso.replace('Z', '+00:00'))
        if dt.tzinfo:
            dt = dt.astimezone()
        return dt.strftime('%d/%m/%Y %H:%M')
    except Exception:
        return iso or ''


def agora_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec='seconds')


def dig(s) -> str:
    return re.sub(r'\D', '', str(s or ''))


def raiz_de(cnpj) -> str:
    return dig(cnpj)[:8]


def fmt_cnpj(c) -> str:
    d = dig(c)
    if len(d) == 14:
        return f"{d[:2]}.{d[2:5]}.{d[5:8]}/{d[8:12]}-{d[12:]}"
    return str(c or '')


def br_num(s) -> float:
    return float(str(s).replace('.', '').replace(',', '.'))


def iso_data(s) -> str:
    s = str(s or '').strip()
    m = re.match(r'^(\d{2})/(\d{2})/(\d{4})', s)
    if m:
        return f"{m.group(3)}-{m.group(2)}-{m.group(1)}"
    return s[:10]


def _js(o):
    """Normaliza como o JSON.stringify do navegador (1000.0 -> 1000), para o hash bater com o painel HTML."""
    if isinstance(o, float):
        return int(o) if o.is_integer() and abs(o) < 1e15 else o
    if isinstance(o, dict):
        return {k: _js(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_js(v) for v in o]
    return o


def hash_str(s) -> str:
    if not isinstance(s, str):
        s = json.dumps(_js(s), sort_keys=False, ensure_ascii=False, default=str, separators=(',', ':'))
    h = 0
    for ch in s:
        h = (h * 31 + ord(ch)) & 0xFFFFFFFF
    if h >= 2 ** 31:
        h -= 2 ** 32
    return f"{h}:{len(s)}"


def esc(s) -> str:
    return (str('' if s is None else s).replace('&', '&amp;').replace('<', '&lt;')
            .replace('>', '&gt;').replace('"', '&quot;').replace("'", '&#39;'))


def fmt_log(v) -> str:
    if v is True:
        return 'sim'
    if v is False:
        return 'não'
    if v is None or v == '':
        return '(vazio)'
    return str(v)
