"""Motor de regras do Simples Nacional — versionado por vigência.

Cada versão guarda vigência e origem legal. A apuração usa a versão vigente
na competência e grava qual usou. Mudança legal = nova versão em REGRAS.
"""
from __future__ import annotations

REGRAS = [{
    'versao': 'LC155-2018', 'vigencia': {'de': '2018-01', 'ate': None},
    'origem': 'LC 123/2006 (redação da LC 155/2016), arts. 3º, 18 e 18-A; Resolução CGSN 140/2018, arts. 21 a 26 e Anexos I a V',
    'tetos': [180000, 360000, 720000, 1800000, 3600000, 4800000],
    'limite': 4800000, 'sublimite': 3600000, 'limiteMesInicio': 400000, 'sublimiteMesInicio': 300000,
    'tetoIss': 0.05, 'fatorRMin': 0.28,
    'nominais': {
        'I':   [[4.00, 0], [7.30, 5940], [9.50, 13860], [10.70, 22500], [14.30, 87300], [19.00, 378000]],
        'II':  [[4.50, 0], [7.80, 5940], [10.00, 13860], [11.20, 22500], [14.70, 85500], [30.00, 720000]],
        'III': [[6.00, 0], [11.20, 9360], [13.50, 17640], [16.00, 35640], [21.00, 125640], [33.00, 648000]],
        'IV':  [[4.50, 0], [9.00, 8100], [10.20, 12420], [14.00, 39780], [22.00, 183780], [33.00, 828000]],
        'V':   [[15.50, 0], [18.00, 4500], [19.50, 9900], [20.50, 17100], [23.00, 62100], [30.50, 540000]],
    },
    'tributos': {
        'I': ['IRPJ', 'CSLL', 'COFINS', 'PIS', 'CPP', 'ICMS'],
        'II': ['IRPJ', 'CSLL', 'COFINS', 'PIS', 'CPP', 'IPI', 'ICMS'],
        'III': ['IRPJ', 'CSLL', 'COFINS', 'PIS', 'CPP', 'ISS'],
        'IV': ['IRPJ', 'CSLL', 'COFINS', 'PIS', 'ISS'],
        'V': ['IRPJ', 'CSLL', 'COFINS', 'PIS', 'CPP', 'ISS'],
    },
    'reparticao': {
        'I': [[5.50, 3.50, 12.74, 2.76, 41.50, 34.00], [5.50, 3.50, 12.74, 2.76, 41.50, 34.00], [5.50, 3.50, 12.74, 2.76, 42.00, 33.50],
              [5.50, 3.50, 12.74, 2.76, 42.00, 33.50], [5.50, 3.50, 12.74, 2.76, 42.00, 33.50], [13.50, 10.00, 28.27, 6.13, 42.10, 0]],
        'II': [[5.50, 3.50, 11.51, 2.49, 37.50, 7.50, 32.00], [5.50, 3.50, 11.51, 2.49, 37.50, 7.50, 32.00], [5.50, 3.50, 11.51, 2.49, 37.50, 7.50, 32.00],
               [5.50, 3.50, 11.51, 2.49, 37.50, 7.50, 32.00], [5.50, 3.50, 11.51, 2.49, 37.50, 7.50, 32.00], [8.50, 7.50, 20.96, 4.54, 23.50, 35.00, 0]],
        'III': [[4.00, 3.50, 12.82, 2.78, 43.40, 33.50], [4.00, 3.50, 14.05, 3.05, 43.40, 32.00], [4.00, 3.50, 13.64, 2.96, 43.40, 32.50],
                [4.00, 3.50, 13.64, 2.96, 43.40, 32.50], [4.00, 3.50, 12.82, 2.78, 43.40, 33.50], [35.00, 15.00, 16.03, 3.47, 30.50, 0]],
        'IV': [[18.80, 15.20, 17.67, 3.83, 44.50], [19.80, 15.20, 20.55, 4.45, 40.00], [20.80, 15.20, 19.73, 4.27, 40.00],
               [17.80, 19.20, 18.90, 4.10, 40.00], [18.80, 19.20, 18.08, 3.92, 40.00], [53.50, 21.50, 20.55, 4.45, 0]],
        'V': [[25.00, 15.00, 14.10, 3.05, 28.85, 14.00], [23.00, 15.00, 14.10, 3.05, 27.85, 17.00], [24.00, 15.00, 14.92, 3.23, 23.85, 19.00],
              [21.00, 15.00, 15.74, 3.41, 23.85, 21.00], [23.00, 12.50, 14.10, 3.05, 23.85, 23.50], [35.00, 15.50, 16.44, 3.56, 29.50, 0]],
    },
}]

# Segregações: flag -> (tributos excluídos, rótulo)
SEG = {
    'icms_st': (['ICMS'], 'ICMS-ST'),
    'monofasico': (['PIS', 'COFINS'], 'PIS/Cofins monofásico'),
    'iss_retido': (['ISS'], 'ISS retido'),
    'exportacao': (['PIS', 'COFINS', 'ICMS', 'IPI', 'ISS'], 'Exportação'),
}
ORDEM = ['IRPJ', 'CSLL', 'COFINS', 'PIS', 'CPP', 'IPI', 'ICMS', 'ISS']
ANEXOS = ['I', 'II', 'III', 'IV', 'V', 'FATOR_R']


def rotulo_anexo(a: str) -> str:
    return 'III/V (Fator R)' if a == 'FATOR_R' else f'Anexo {a}'


def regra_vigente(c: str | None):
    v = [r for r in REGRAS if (not c or r['vigencia']['de'] <= c) and (not c or not r['vigencia']['ate'] or c <= r['vigencia']['ate'])]
    return v[-1] if v else REGRAS[-1]


def faixa_de(rbt12: float, regra=None) -> int:
    tetos = (regra or REGRAS[-1])['tetos']
    for i, t in enumerate(tetos):
        if rbt12 <= t:
            return i + 1
    return 6


def aliq_efetiva(anexo: str, rbt12: float, regra=None) -> float:
    regra = regra or REGRAS[-1]
    fx = faixa_de(rbt12, regra)
    nom, pd = regra['nominais'][anexo][fx - 1]
    return (rbt12 * nom / 100 - pd) / rbt12 if rbt12 > 0 else nom / 100


def ef_tributo(anexo: str, rbt12: float, trib: str, regra=None) -> float:
    regra = regra or REGRAS[-1]
    tribs = regra['tributos'][anexo]
    if trib not in tribs:
        return 0.0
    i = tribs.index(trib)
    return aliq_efetiva(anexo, rbt12, regra) * regra['reparticao'][anexo][faixa_de(rbt12, regra) - 1][i] / 100
