"""Geração de HTML: memória de cálculo, apuração, centro de validação, histórico,
trilha e relatórios para impressão (abertos no navegador → Imprimir / Salvar PDF).

Os mesmos trechos são exibidos dentro do programa (QTextBrowser) e nos relatórios.
"""
from __future__ import annotations

import csv
import io
import os
import tempfile
import webbrowser
from datetime import datetime
from pathlib import Path

from . import lp as LPM
from . import atividades as ATV
from .regras_sn import ORDEM, regra_vigente
from .util import (esc, valN, brl, pct, pctN, nome_mes, mes_longo, data_br, data_hora, fmt_cnpj, mes_add, r2)

AZUL, NAVY, OK, WARN, BAD, MUT = '#094488', '#0f172a', '#047857', '#b45309', '#b91c1c', '#64748b'
CLS_COR = {'erro': (BAD, '#fef2f2'), 'atencao': ('#92400e', '#fffbeb'), 'ok': (OK, '#ecfdf5'), 'info': ('#094488', '#e8f1fb'),
           'neutro': ('#475569', '#f1f5f9')}

CSS_QT = f"""
body {{ font-family: 'Segoe UI', Inter, Arial; font-size: 10pt; color: {NAVY}; }}
h3 {{ font-size: 10pt; color: #1e293b; margin-top: 14px; margin-bottom: 4px; text-transform: uppercase; }}
h4 {{ font-size: 11pt; color: {NAVY}; margin-top: 16px; margin-bottom: 4px; }}
td, th {{ padding: 3px 7px; }}
th {{ background-color: #f1f5f9; color: {MUT}; font-size: 8.5pt; text-align: left; }}
.n {{ text-align: right; }}
.tot {{ background-color: #e2e8f0; font-weight: bold; }}
.mut {{ color: {MUT}; }}
.bad {{ color: {BAD}; font-weight: bold; }}
.okc {{ color: {OK}; font-weight: bold; }}
.formula {{ background-color: #f1f5f9; }}
a {{ color: {AZUL}; text-decoration: none; font-weight: bold; }}
"""


def chip(rot, cls):
    cor, fundo = CLS_COR.get(cls, CLS_COR['neutro'])
    return f'<span style="background-color:{fundo};color:{cor};font-weight:bold;font-size:8.5pt">&nbsp;{esc(rot)}&nbsp;</span>'


def tabela(cab, linhas, tot=None, larg='100%'):
    h = f'<table width="{larg}" cellspacing="0" cellpadding="4" style="border-collapse:collapse;border:1px solid #e2e8f0">'
    if any(c.lstrip('>') for c in cab):
        h += '<tr>' + ''.join(f'<th{" class=n align=right" if c.startswith(">") else ""}>{esc(c.lstrip(">"))}</th>' for c in cab) + '</tr>'
    for i, l in enumerate(linhas):
        bg = ' style="background-color:#fbfcfe"' if i % 2 else ''
        h += f'<tr{bg}>' + ''.join(f'<td{" align=right" if cab[j].startswith(">") else ""}>{c}</td>' for j, c in enumerate(l)) + '</tr>'
    if tot:
        h += '<tr class="tot">' + ''.join(f'<td{" align=right" if cab[j].startswith(">") else ""}><b>{c}</b></td>' for j, c in enumerate(tot)) + '</tr>'
    return h + '</table>'


def nota(txt, tipo=''):
    cor = {'ok': ('#065f46', '#ecfdf5'), 'bad': ('#991b1b', '#fef2f2'), 'at': ('#92400e', '#fffbeb')}.get(tipo, (NAVY, '#f8fafc'))
    return f'<table width="100%" cellpadding="6" style="margin-top:4px"><tr><td style="background-color:{cor[1]};color:{cor[0]}">{txt}</td></tr></table>'


def calc(linhas, larg='560'):
    """linhas: (op, rotulo, valor, tipo) tipo: '', 'res', 'fim'"""
    h = f'<table width="{larg}" cellspacing="0" cellpadding="5" style="border:1px solid #e2e8f0">'
    for op, rot, v, tp in linhas:
        st = {'res': 'background-color:#e8f1fb;color:#094488;font-weight:bold', 'fim': 'background-color:#094488;color:#ffffff;font-weight:bold'}.get(tp, '')
        h += f'<tr style="{st}"><td width="24" align="center" style="{st}">{op}</td><td style="{st}">{rot}</td><td align="right" style="{st}">{v}</td></tr>'
    return h + '</table>'


# ======================= SIMPLES NACIONAL =======================
def rot_anexo(it):
    return f"Anexo {it['anexo']} (pelo Fator R)" if it['anexoOrig'] == 'FATOR_R' else f"Anexo {it['anexo']}"


def memoria_sn(r, nome, cnpj, c):
    m = r.get('memo') or {}
    R = regra_vigente(c)
    TETOS = R['tetos']
    FRM = R['fatorRMin']

    def faixa_txt(f):
        return f'até {valN(TETOS[0])}' if f == 1 else f'de {valN(TETOS[f - 2] + 0.01)} até {valN(TETOS[f - 1])}'
    aliq_med = r['total_calculado'] / r['rpa'] if r['rpa'] else 0
    out = [f'<table width="100%" cellpadding="8" style="background-color:#f8fafc;border:1px solid #e2e8f0"><tr><td><b style="font-size:11pt">{esc(nome)}</b><br>'
           f'<span class="mut">CNPJ {esc(fmt_cnpj(cnpj))} · Simples Nacional</span></td><td align="right"><b>PA {nome_mes(c)}</b><br>'
           f'<span class="mut">regra {esc(r["regra"]["versao"])}</span></td></tr></table>']
    out.append(tabela(['Receita do mês', 'RBT12', 'Faixa', 'Alíquota efetiva', 'DAS do mês'],
                      [[f"<b>{valN(r['rpa'])}</b><br><span class=mut>{len(r['itens'])} atividade(s)</span>",
                        f"<b>{valN(r['rbt12'])}</b><br><span class=mut>{esc(r['origem_rbt12'])}</span>",
                        f"<b>{r['faixa']}ª faixa</b><br><span class=mut>{faixa_txt(r['faixa'])}</span>",
                        f"<b>{pct(aliq_med)}</b><br><span class=mut>DAS ÷ receita</span>",
                        f"<b>{valN(r['total_calculado'])}</b><br><span class=mut>{'declarado ' + valN(r['das_informado']) if r['das_informado'] is not None else 'sem DAS declarado'}</span>"]]))
    n = [0]

    def sec(t, exp=''):
        n[0] += 1
        out.append(f'<h4>{n[0]}. {t}</h4>' + (f'<p class="mut">{exp}</p>' if exp else ''))
    sec('Receita do mês', 'Receitas do período de apuração, separadas por atividade e anexo.')
    out.append(tabela(['Receita', 'Anexo', 'Origem', '>Valor'], [[esc(it['descricao']), rot_anexo(it), esc(it['origem'] or '—'), valN(it['valor'])] for it in r['itens']],
                      ['Receita bruta do mês (RPA)', '', '', valN(r['rpa'])]))
    if m.get('rpa_declarada') is not None:
        d = r2(r['rpa'] - m['rpa_declarada'])
        out.append(nota(f"PGDAS-D declarou {valN(m['rpa_declarada'])} — diferença de <b>{valN(d)}</b>.", 'bad') if abs(d) > 0.01
                   else nota(f"✓ Confere com a receita declarada no PGDAS-D ({valN(m['rpa_declarada'])}).", 'ok'))
    sec('RBT12 — receita dos 12 meses anteriores', 'Soma das receitas dos 12 meses anteriores ao período; define a faixa e a alíquota.')
    if m.get('mesesRbt'):
        soma = r2(sum(m['hist'].get(mm, 0) for mm in m['mesesRbt']))
        out.append(tabela(['Mês', '>Receita', 'Origem'], [[nome_mes(mm), valN(m['hist'][mm]) if mm in m['hist'] else '<span class=bad>sem dado</span>',
                                                          esc(m['origemHist'].get(mm, '—'))] for mm in m['mesesRbt']], larg='60%'))
        lin = [('', f"Soma dos {len(m['mesesRbt'])} meses", valN(soma), '')]
        if len(m['mesesRbt']) < 12:
            lin += [('÷', 'Meses de atividade', str(len(m['mesesRbt'])), ''), ('×', 'Anualização', '12', '')]
        lin.append(('=', 'RBT12', valN(r['rbt12']), 'res'))
        out.append('<br>' + calc(lin))
        if m.get('rbt12_informado') is not None:
            out.append(nota('✓ Confere com o RBT12 do PGDAS-D.', 'ok') if abs(m['rbt12_informado'] - r['rbt12']) < 0.01
                       else nota(f"PGDAS-D informa RBT12 de {valN(m['rbt12_informado'])} — diferença de <b>{valN(r2(m['rbt12_informado'] - r['rbt12']))}</b>.", 'bad'))
    else:
        out.append(calc([('', 'RBT12', valN(r['rbt12']), 'res')]) + nota(esc(r['origem_rbt12']) + '.'))
    sec('Faixa e limites', 'O RBT12 indica em qual faixa da tabela do anexo a empresa está.')
    uso_sub = r['rba_ano'] / m['sublimite'] if m.get('sublimite') else 0
    uso_lim = r['rba_ano'] / m['limite'] if m.get('limite') else 0
    out.append(calc([('', 'RBT12', valN(r['rbt12']), ''), ('', 'Faixa', f"{r['faixa']}ª faixa · {faixa_txt(r['faixa'])}", 'res')]))
    out.append('<br>' + tabela(['Referência', '>Valor', '>Usado'], [['Receita acumulada no ano (com o mês)', valN(r['rba_ano']), ''],
                                                                     ['Sublimite ICMS/ISS', valN(m['sublimite']), pctN(uso_sub, 1)],
                                                                     ['Limite do Simples Nacional', valN(m['limite']), pctN(uso_lim, 1)]], larg='560'))
    if m.get('atividades'):
        sec('Atividade da empresa', 'Enquadramento das receitas pela LC 123/2006, art. 18.')
        out.append(tabela(['Atividade', 'Tributação'], [[('<b>' if k == 0 else '') + esc(a['nome']) + (' (principal)</b>' if k == 0 else ''), esc(a['regra'])]
                                                        for k, a in enumerate(m['atividades'])]))
    if r['fator_r'] is not None:
        sec('Fator R', 'Define se as atividades sujeitas ao Fator R vão para o Anexo III (folha ≥ 28% da receita) ou para o Anexo V.')
        lf = [('', f"Folha dos 12 meses <span class=mut>{esc(m.get('origemFolha', ''))}</span>", valN(m['folha_12m']), '')]
        if m.get('folha_anual') is not None and m.get('folha_12m') is not None and abs(m['folha_anual'] - m['folha_12m']) > 0.01:
            lf.append(('=', f"Folha anualizada <span class=mut>{esc(m.get('origemFolhaAnual', ''))}</span>", valN(m['folha_anual']), 'res'))
        out.append(calc(lf + [('÷', 'RBT12', valN(r['rbt12']), ''), ('=', 'Fator R', pctN(r['fator_r']), 'res')]))
        ok = r['fator_r'] >= FRM
        out.append(nota(f"{pctN(r['fator_r'])} {'≥' if ok else '<'} 28% → atividades do Fator R tributadas no <b>Anexo {'III' if ok else 'V'}</b>.", 'ok' if ok else 'at'))
        px = r.get('prox') or {}
        if px.get('fator_r') is not None:
            pa2 = nome_mes(px['pa'])
            out.append(f"<p><b>Projeção para {pa2}</b> <span class=mut>— janela móvel: entra {nome_mes(c)}, sai {nome_mes(px['mes_sai'])}</span></p>")
            fd = m.get('folhaDet') or {}
            lin, tp, tf, ti, tt, tr = [], 0, 0, 0, 0, 0
            for i in range(11, -1, -1):
                mm = mes_add(c, -i)
                rec = r['rpa'] if mm == c else (m.get('hist') or {}).get(mm)
                fol = px['folha_mes'] if mm == c else (m.get('folhaMeses') or {}).get(mm)
                d = fd.get(mm) or {}
                tp, tf, ti = tp + (d.get('prov') or 0), tf + (d.get('fgts') or 0), ti + (d.get('inss') or 0)
                tt, tr = tt + (fol or 0), tr + (rec or 0)
                lin.append([nome_mes(mm) + (' *' if mm == c else ''), valN(d['prov']) if d else '', valN(d['fgts']) if d else '',
                            valN(d['inss']) if d else '', valN(fol) if fol is not None else '—', valN(rec) if rec is not None else '—'])
            out.append(tabela(['Mês', '>Proventos', '>FGTS', '>INSS/CPP', '>Total de folha', '>Faturamento'], lin,
                              tot=['Total', valN(tp) if fd else '', valN(tf) if fd else '', valN(ti) if fd else '', valN(tt), valN(tr)]))
            out.append(calc([('', f"Folha 12m de {pa2} <span class=mut>(folha de {nome_mes(c)} {valN(px['folha_mes'])}"
                                  f"{' — ' + esc(px['origemFolhaMes']) if px.get('origemFolhaMes') else ''})</span>", valN(px['folha_12m']), '')]
                            + ([('=', f"Folha anualizada <span class=mut>{esc(px.get('origemFolhaAnual') or '')}</span>", valN(px['folha_anual']), 'res')]
                               if px.get('folha_anual') is not None and abs(px['folha_anual'] - (px['folha_12m'] or 0)) > 0.01 else [])
                            + [('÷', f'RBT12 de {pa2}', valN(px['rbt12']), ''), ('=', f'Fator R de {pa2}', pctN(px['fator_r']), 'res')]))
            okp = px['fator_r'] >= px['fatorRMin']
            txt = f"{pctN(px['fator_r'])} {'≥' if okp else '<'} 28% → em {pa2} as atividades do Fator R vão para o <b>Anexo {px['anexoFR'] or ('III' if okp else 'V')}</b>."
            if px.get('folha_min_mes') is not None:
                txt += f" Folha mínima de {nome_mes(c)} para manter 28%: <b>{valN(px['folha_min_mes'])}</b>."
            if px.get('folha_estimada'):
                txt += ' <i>Folha do mês não informada: valor estimado.</i>'
            out.append(nota(txt, 'ok' if okp else 'at'))
    sec('Cálculo por atividade', 'Para cada receita: alíquota efetiva pela fórmula do art. 18, § 1º-A, LC 123/2006, e divisão do DAS entre os tributos.')
    for k, it in enumerate(r['itens']):
        prod = r2(r['rbt12'] * it['aliq_nominal'])
        base = r2(prod - it['parcela_deduzir'])
        out.append(f"<p><b>{'abcdefghij'[k] if k < 10 else k + 1}) {esc(it['descricao'])}</b> · {rot_anexo(it)} · {r['faixa']}ª faixa · receita <b>{valN(it['valor'])}</b></p>")
        out.append(calc([('', 'RBT12', valN(r['rbt12']), ''), ('×', f"Alíquota nominal (Anexo {it['anexo']}, {r['faixa']}ª faixa)", pctN(it['aliq_nominal']), ''),
                         ('=', '', valN(prod), 'res'), ('−', 'Parcela a deduzir', valN(it['parcela_deduzir']), ''), ('=', '', valN(base), 'res'),
                         ('÷', 'RBT12', valN(r['rbt12']), ''), ('=', 'Alíquota efetiva', pct(it['aliq_efetiva']), 'fim')]))
        dif = abs(it['aliq_aplicada'] - it['aliq_efetiva']) > 1e-9
        out.append('<br>' + calc([('', 'Receita', valN(it['valor']), ''), ('×', 'Alíquota ' + ('aplicada (após segregação)' if dif else 'efetiva'), pct(it['aliq_aplicada']), ''),
                                  ('=', 'DAS', valN(it['total']), 'fim')]))
        if it['excl']:
            out.append(nota(f"Segregação: {esc(', '.join(o for o in it['obs'] if not o.startswith('Fator R')))} — {', '.join(t for t in it['excl'] if t in it['percs'])} fora do DAS."))
        if it.get('issExc'):
            out.append(nota(f"ISS limitado a 5%; o excedente de {pct(it['issExc'])} foi redistribuído aos tributos federais."))
        if it.get('issRetido'):
            out.append(nota(f"ISS retido pelo tomador: sai do DAS só a parcela do ISS pela repartição — {valN(it['valor'])} × "
                            f"{pct(it['aliqIss'])} (alíquota efetiva {pct(it['aliq_efetiva'])} × {pctN(it['percs'].get('ISS', 0))} do ISS"
                            f"{', limitado a 5%' if it.get('issExc') else ''}) = <b>{valN(it['issRetido'])}</b>. "
                            "Os demais tributos continuam integrais (LC 123/2006, art. 21, § 4º; Res. CGSN 140/2018, art. 27)."))
        linhas = []
        for t in it['percs']:
            fora = t in it['excl'] or not it['ef'].get(t)
            linhas.append([t, pctN(it['percs'][t]), pct(it['ef'][t]), ('segregado' if t in it['excl'] else 'fora do DAS') if fora else valN(it['valores'].get(t, 0))])
        out.append('<br>' + tabela(['Tributo', '>% de repartição', '>Alíquota do tributo', '>Valor'], linhas, ['Total', '100%', pct(it['aliq_aplicada']), valN(it['total'])]))
    sec('Valor do DAS', 'Soma dos tributos de todas as atividades' + (', comparada com o PGDAS-D.' if r['comparacao'] else '.'))
    tribs = [t for t in ORDEM if t in r['tributos']]
    if r['comparacao']:
        cp = {x[0]: x for x in r['comparacao']}
        out.append(tabela(['Tributo', '>Recalculado', '>Declarado', '>Diferença'],
                          [[t, valN(r['tributos'][t]), valN(cp[t][2]) if t in cp else '—',
                            (f"<span class=bad>{valN(cp[t][3])}</span>" if not cp[t][4] else valN(cp[t][3])) if t in cp else '—'] for t in tribs],
                          ['Total do DAS', valN(r['total_calculado']), valN(r['das_informado']), valN(r['diferenca'])], larg='620'))
    else:
        out.append(tabela(['Tributo', '>Recalculado'], [[t, valN(r['tributos'][t])] for t in tribs], ['Total do DAS', valN(r['total_calculado'])], larg='420'))
    if r['das_informado'] is not None:
        out.append(nota(f"DAS declarado difere do recalculado em <b>{valN(r['diferenca'])}</b>.", 'bad') if r['status'] == 'DIVERGENTE'
                   else nota('✓ DAS declarado confere com o recalculado.', 'ok'))
    al = [a for a in r['alertas'] if a[0] != 'info']
    if al:
        sec('Pontos de atenção')
        for nv, t in al:
            out.append(nota(f"<b>{'Erro' if nv == 'erro' else 'Atenção'}:</b> {esc(t)}", 'bad' if nv == 'erro' else 'at'))
    out.append('<p class="mut" style="font-size:8.5pt">Base: LC 123/2006 (redação da LC 155/2016), arts. 18 e 18-A; Resolução CGSN 140/2018, arts. 21 a 25.</p>')
    return ''.join(out)


def apuracao_sn(r):
    """Aba "Apuração": indicadores no topo, DAS por tributo (com participação) e por receita — tabelas na largura certa."""
    tot = r['total_calculado'] or 0
    aliq = tot / r['rpa'] if r['rpa'] else 0

    def kpi(rot, val, sub='', escuro=False):
        fundo, cor, cs = ('#094488', '#ffffff', '#d6d3d1') if escuro else ('#f6f5f2', '#094488', MUT)
        return (f'<td width="25%" style="background-color:{fundo};padding:10px 14px">'
                f'<span style="font-size:7.5pt;color:{cs};font-weight:bold">{rot}</span><br>'
                f'<span style="font-size:14pt;font-weight:bold;color:{cor}">{val}</span><br>'
                f'<span style="font-size:8.5pt;color:{cs}">{sub}</span></td>')
    dif = r.get('diferenca')
    topo = ('<table width="100%" cellspacing="6" cellpadding="0"><tr>'
            + kpi('DAS RECALCULADO', brl(tot), r['status'], True)
            + kpi('RECEITA DO MÊS', valN(r['rpa']), f"RBT12 {valN(r['rbt12'])} · {r['faixa']}ª faixa")
            + kpi('ALÍQUOTA EFETIVA', pct(aliq, 2), 'DAS ÷ receita do mês')
            + kpi('DECLARADO (PGDAS-D)', valN(r['das_informado']) if r['das_informado'] is not None else '—',
                  (f'diferença {valN(dif)}' if dif is not None else 'informe para conferir'))
            + '</tr></table>')
    st_th = 'style="background-color:#f6f5f2;color:#71717a;font-size:8pt;padding:6px 10px;border-bottom:1px solid #e4e2dd"'

    def th(t, dir_=False):
        return f'<th {st_th} align="{"right" if dir_ else "left"}">{t}</th>'

    def td(t, dir_=False, b=False, cor=None):
        st = f'padding:6px 10px;border-bottom:1px solid #f0efeb;{"font-weight:bold;" if b else ""}{f"color:{cor};" if cor else ""}'
        return f'<td align="{"right" if dir_ else "left"}" style="{st}">{t}</td>'
    comp = {c[0]: c for c in (r.get('comparacao') or [])}
    tem_decl = bool(comp)
    linhas = []
    for t in ORDEM:
        v = r['tributos'].get(t)
        if not v and t not in comp:
            continue
        part = (v or 0) / tot if tot else 0
        barra = (f'<table cellspacing="0" cellpadding="0" width="120"><tr><td width="{max(1, int(part * 120))}" height="7" style="background-color:#094488"></td>'
                 f'<td height="7" style="background-color:#e7e5e0"></td></tr></table>')
        cel = td(f'<b>{t}</b>') + td(valN(v), True) + td(pct(part, 1), True) + f'<td style="padding:6px 10px;border-bottom:1px solid #f0efeb">{barra}</td>'
        if tem_decl:
            c = comp.get(t)
            cel += td(valN(c[2]) if c else '—', True)
            cel += td(valN(c[3]) if c else '—', True, cor=(None if (not c or c[4]) else BAD), b=bool(c and not c[4]))
        linhas.append(f'<tr>{cel}</tr>')
    rod = td('<b>Total do DAS</b>') + td(valN(tot), True, True) + td('100%', True, True) + td('')
    if tem_decl:
        rod += td(valN(r['das_informado']), True, True) + td(valN(dif), True, True, cor=(BAD if dif and abs(dif) > 0.05 else OK))
    t1 = (f'<table width="{"720" if tem_decl else "560"}" cellspacing="0" cellpadding="0" style="border:1px solid #e4e2dd">'
          f'<tr>{th("Tributo")}{th("Recalculado", True)}{th("Participação", True)}{th("")}'
          + (th('PGDAS-D', True) + th('Diferença', True) if tem_decl else '') + '</tr>' + ''.join(linhas)
          + f'<tr style="background-color:#f6f5f2">{rod}</tr></table>')
    lin2 = ''.join('<tr>' + td(esc(it['descricao'])) + td(rot_anexo(it)) + td(valN(it['valor']), True)
                   + td(pct(it['aliq_aplicada'], 4), True) + td(valN(it['total']), True, True) + '</tr>' for it in r['itens'])
    t2 = ('<table width="100%" cellspacing="0" cellpadding="0" style="border:1px solid #e4e2dd">'
          f'<tr>{th("Receita")}{th("Anexo")}{th("Valor", True)}{th("Alíquota aplicada", True)}{th("DAS", True)}</tr>{lin2}'
          f'<tr style="background-color:#f6f5f2">{td("<b>Total</b>")}{td("")}{td(valN(r["rpa"]), True, True)}{td("")}{td(valN(tot), True, True)}</tr></table>')
    h = '<p style="margin:14px 0 6px 0;font-size:9pt;font-weight:bold;color:#094488;letter-spacing:1px">{}</p>'
    t3 = ''
    ret = [it for it in r['itens'] if it.get('issRetido')]
    if ret:
        lin3 = ''.join('<tr>' + td(esc(it['descricao'])) + td(valN(it['valor']), True) + td(pct(it['aliq_efetiva'], 4), True)
                       + td(pctN(it['percs'].get('ISS', 0)), True) + td(pct(it['aliqIss'], 4), True) + td(valN(it['issRetido']), True, True) + '</tr>'
                       for it in ret)
        ir = r.get('iss_retido') or {}
        t3 = (h.format('ISS RETIDO PELO TOMADOR — FORA DO DAS')
              + '<table width="100%" cellspacing="0" cellpadding="0" style="border:1px solid #e4e2dd">'
              f'<tr>{th("Receita")}{th("Base retida", True)}{th("Alíq. efetiva", True)}{th("% ISS (repartição)", True)}{th("Alíq. do ISS", True)}{th("Deduzido", True)}</tr>{lin3}'
              f'<tr style="background-color:#f6f5f2">{td("<b>Total</b>")}{td(valN(ir.get("base")), True, True)}{td("")}{td("")}{td("")}'
              f'{td(valN(ir.get("valor")), True, True)}</tr></table>'
              f'<p style="font-size:8.5pt;color:{MUT}">Sai do DAS só a parcela do ISS (alíquota efetiva × % do ISS na repartição, limitada a 5%) — '
              'não a alíquota municipal. IRPJ, CSLL, Cofins, PIS e CPP continuam integrais.</p>')
    return topo + h.format('DAS POR TRIBUTO') + t1 + h.format('DAS POR RECEITA') + t2 + t3


# ======================= LUCRO PRESUMIDO =======================
def apuracao_lp(r):
    M = r['mes']
    nt = LPM.NOME_TRIB
    por_g = {}
    for it in M['itens']:
        por_g[it['grupo']] = r2(por_g.get(it['grupo'], 0) + it['valor'])
    o = [f"<h3>Resumo — {nome_mes(r['comp'])}</h3>" + tabela(['Natureza', '>Receita'], [[esc(LPM.grupo(g)['rot']), valN(v)] for g, v in por_g.items()],
                                                             ['Receita bruta do mês', valN(r['rpa'])], larg='70%')]
    lin = [['Receita tributada', valN(M['base']['normal'])]]
    if M['base']['zero']:
        lin.append(['Monofásicos / alíquota zero', valN(M['base']['zero'])])
    if M['base']['isento']:
        lin.append(['Exportação (isenta)', valN(M['base']['isento'])])
    lin += [['PIS 0,65%', valN(M['pis'])], ['(−) PIS retido', valN(M['ret']['PIS']['enc'])], ['<b>PIS a recolher</b>', f"<b>{valN(M['pisDev'])}</b>"],
            ['Cofins 3%', valN(M['cofins'])], ['(−) Cofins retida', valN(M['ret']['COFINS']['enc'])], ['<b>Cofins a recolher</b>', f"<b>{valN(M['cofinsDev'])}</b>"]]
    o.append('<h3>PIS e Cofins — cumulativo</h3>' + tabela(['', '>'], lin, larg='70%'))
    if M['icms']['tem']:
        i = M['icms']
        lin = [['Débitos das notas', valN(i['debXml'])], ['Débitos de outros documentos', valN(r2(i['deb'] - i['debXml']))], ['(−) Créditos do período', valN(i['cred'])],
               ['(−) Saldo credor anterior', valN(i['saldoAnt'])], ['<b>ICMS a recolher</b>', f"<b>{valN(i['dev'])}</b>"]]
        if i['credorProx']:
            lin.append(['Saldo credor para o próximo mês', valN(i['credorProx'])])
        if i['st']:
            lin.append(['ICMS-ST destacado nas saídas', valN(i['st'])])
        o.append('<h3>ICMS</h3>' + tabela(['', '>'], lin, larg='70%'))
    if M['iss']['tem']:
        s = M['iss']
        lin = [['Receita de serviços', valN(s['base'])], ['(−) Serviços com ISS retido pelo tomador', valN(s['retBase'])], ['Base do ISS próprio', valN(s['proprioBase'])],
               ['Alíquota municipal', (str(s['aliq']).replace('.', ',') + '%') if s['aliq'] is not None else 'não informada'],
               ['<b>ISS a recolher</b>', f"<b>{valN(s['dev']) if s['dev'] is not None else '—'}</b>"]]
        if s.get('retido'):
            lin.append(['ISS retido pelos tomadores', valN(s['retido'])])
        o.append('<h3>ISS</h3>' + tabela(['', '>'], lin, larg='70%'))
    if M['ipi']['tem']:
        p = M['ipi']
        o.append('<h3>IPI</h3>' + tabela(['', '>'], [['Débitos', valN(p['deb'])], ['(−) Créditos', valN(p['cred'])], ['<b>IPI a recolher</b>', f"<b>{valN(p['dev'])}</b>"]], larg='70%'))
    if r.get('cbsIbs'):
        c = r['cbsIbs']
        o.append('<h3>CBS e IBS 2026 — fase de teste (informativo)</h3>' + tabela(['', '>'], [['Base', valN(c['base'])], ['CBS 0,9%', valN(c['cbs'])], ['IBS 0,1%', valN(c['ibs'])]], larg='70%'))
    if r['comparacao']:
        o.append('<h3>Sistema × declarado</h3>' + tabela(['Tributo', '>Sistema', '>Declarado', '>Diferença'],
                                                          [[nt[t], valN(c), valN(d), f'<span class=bad>{valN(df)}</span>' if not ok else valN(df)] for t, c, d, df, ok in r['comparacao']], larg='70%'))
    return ''.join(o)


def _tab_ret_notas(L, tipos=('IRRF', 'CSLL', 'PIS', 'COFINS')):
    nm = {'COFINS': 'Cofins'}
    lin = []
    for x in L:
        como = esc((x.get('leiaute') or '') + (f" cód. {x['tp']}" if x.get('tp') else ''))
        if x.get('aviso'):
            como += f"<br><span class=bad>{esc(x['aviso'])}</span>"
        lin.append([esc(f"{x['n']}"), data_br(x['d']), esc(x.get('tom') or x.get('tomDoc') or '—'), esc(x.get('it') or ''), valN(x['valor'])]
                   + [valN(x[t]) if x[t] else '—' for t in tipos] + [como])
    tot = ['Total', '', '', '', valN(r2(sum(x['valor'] for x in L)))] + [valN(r2(sum(x[t] for x in L))) for t in tipos] + ['']
    return tabela(['Nota', 'Data', 'Tomador', 'Ativ.', '>Valor'] + ['>' + nm.get(t, t) for t in tipos] + ['Leitura do XML'], lin, tot)


def _tab_ativ_mes(itens):
    sv = [it for it in itens if it.get('nfse') and 'svc' in it]
    if not sv:
        return ''
    lin = []
    for it in sv:
        g, sg = LPM.grupo(it['grupo']), LPM.grupo(it.get('sug'))
        dif = it['grupo'] != it.get('sug')
        lin.append([esc(it['svc'] or 's/ código'), esc(it.get('svcX') or '—'), str(it.get('qtd') or ''), valN(it['valor']),
                    esc(f"{sg['curto']} ({pctN(sg['irpj'], 0)})"),
                    (f"<span class=bad>{esc(g['curto'])}</span>" if dif else esc(g['curto'])) + f" <span class=mut>· {esc(it.get('fonteGrupo') or '')}</span>"])
    return tabela(['Código', 'Atividade no XML', '>Notas', '>Receita', 'Sugestão pelo código', 'Natureza usada'], lin)


def memoria_lp(r, nome, cnpj):
    M = r['mes']
    nt = LPM.NOME_TRIB
    o = [f'<p style="background-color:#f1f5f9"><b>{esc(nome)}</b> · CNPJ {esc(fmt_cnpj(cnpj))} · Lucro Presumido · PA <b>{nome_mes(r["comp"])}</b></p>']
    n = [0]

    def sec(t):
        n[0] += 1
        o.append(f'<h4>{n[0]}. {t}</h4>')
    sec('Receitas do mês por natureza')
    o.append(tabela(['Receita', 'Natureza', 'Fonte', '>Valor'], [[esc(it['descricao']), esc(LPM.grupo(it['grupo'])['rot']), esc(it['origem']), valN(it['valor'])] for it in M['itens']],
                    ['Receita bruta do mês', '', '', valN(r['rpa'])]))
    ta = _tab_ativ_mes(M['itens'])
    if ta:
        sec('Atividades de serviço lidas dos XML (item da LC 116)')
        o.append(ta)
        o.append('<p class=mut style="font-size:8.5pt">O tipo de serviço de cada atividade define a natureza: base do PIS/Cofins/ISS no mês e '
                 'percentual de presunção do IRPJ/CSLL no trimestre.</p>')
    U = M.get('usados') or {}
    if U.get('qtd'):
        sec('Veículos usados — receita bruta pela margem')
        o.append(f'<p class="mut">{esc(LPM.ORIGEM_USADOS)}</p>')
        o.append(tabela(['Chassi / veículo', 'NF saída', '>Venda', 'NF entrada', '>Custo', '>Margem', '>Base'],
                        [[esc(l['chassi'] or l['desc']), esc(l.get('nfS') or 'manual'), valN(l['venda']), esc('NF ' + l['nfE'] if l.get('nfE') else l.get('fonte') or '—'),
                          valN(l['custo']) if l['custo'] is not None else '—', valN(l['margem']) if l['margem'] is not None else 'sem custo', valN(l['base'])]
                         for l in U['linhas'] if l['usado']], ['Total', '', valN(U['venda']), '', valN(U['custo']), '', valN(U['base'])]))
    sec('PIS e Cofins — regime cumulativo')
    o.append(f"<p class=formula>PIS = {valN(M['base']['normal'])} × 0,65% = {valN(M['pis'])} − retido {valN(M['ret']['PIS']['enc'])} = <b>{valN(M['pisDev'])}</b></p>")
    o.append(f"<p class=formula>Cofins = {valN(M['base']['normal'])} × 3% = {valN(M['cofins'])} − retida {valN(M['ret']['COFINS']['enc'])} = <b>{valN(M['cofinsDev'])}</b></p>")
    if M['base']['zero'] or M['base']['isento']:
        o.append(f"<p>Fora da base: monofásicos/alíquota zero {valN(M['base']['zero'])} · exportação {valN(M['base']['isento'])}.</p>")
    if M['icms']['tem']:
        i = M['icms']
        sec('ICMS')
        o.append(f"<p class=formula>{valN(i['deb'])} débitos − {valN(i['cred'])} créditos − {valN(i['saldoAnt'])} saldo anterior = <b>{valN(i['dev'])}</b>"
                 + (f" (saldo credor {valN(i['credorProx'])})" if i['credorProx'] else '') + '</p>')
    if M['iss']['tem']:
        s = M['iss']
        sec('ISS')
        o.append(f"<p class=formula>({valN(s['base'])} − {valN(s['retBase'])} retido) × {(str(s['aliq']).replace('.', ',') + '%') if s['aliq'] is not None else 'alíquota não informada'} = <b>{valN(s['dev']) if s['dev'] is not None else '—'}</b></p>")
    if M['ipi']['tem']:
        sec('IPI')
        o.append(f"<p class=formula>{valN(M['ipi']['deb'])} − {valN(M['ipi']['cred'])} = <b>{valN(M['ipi']['dev'])}</b></p>")
    sec('Retenções do mês')
    o.append(tabela(['Tributo', '>Nas notas', '>Encontrado', '>Aproveitado'],
                    [[nt[t], valN(M['ret'][t]['xml']), valN(M['ret'][t]['enc']),
                      'no trimestre' if t in ('IRRF', 'CSLL') else (valN(M['ret'][t]['apr']) if M['ret'][t]['apr'] is not None else '—')] for t in ('PIS', 'COFINS', 'IRRF', 'CSLL')], larg='70%'))
    if M.get('retNotas'):
        o.append('<p><b>Retenções lidas de cada nota</b></p>' + _tab_ret_notas(M['retNotas']))
    o.append(f"<p class=mut style='font-size:8.5pt'>Regra {esc(r['regra']['versao'])}: {esc(r['regra']['origem'])}. IRPJ e CSLL: ver fechamento do {r['tri']['q']}º trimestre.</p>")
    return ''.join(o)


def memoria_tri(q, nome, cnpj):
    M = q['maj']
    o = [f'<p style="background-color:#f1f5f9"><b>{esc(nome)}</b> · CNPJ {esc(fmt_cnpj(cnpj))} · Lucro Presumido · <b>{q["q"]}º trimestre {q["ano"]}</b></p>']
    n = [0]

    def sec(t):
        n[0] += 1
        o.append(f'<h4>{n[0]}. {t}</h4>')

    def lin(g, pk, bk, eK, on):
        if on and g[eK]:
            return f"<p class=formula>{esc(g['rot'])}: ({valN(r2(g['receita'] - g[eK]))} × {pctN(g[pk], 1)}) + ({valN(g[eK])} × {pctN(g[pk] * M['fator'], 2)}) = <b>{valN(g[bk])}</b></p>"
        return f"<p class=formula>{esc(g['rot'])}: {valN(g['receita'])} × {pctN(g[pk], 1)} = <b>{valN(g[bk])}</b></p>"
    ad = (f"<p class=formula>Receitas integrais {valN(q['adic']['integral'])} + financeiras {valN(q['adic']['financeira'])} + ganhos de capital {valN(q['adic']['ganho'])}"
          f" + outras adições {valN(q['adic']['outras'])} = <b>{valN(q['adicTot'])}</b></p>") if q['adicTot'] else ''
    sec('Receitas do trimestre (apurações mensais)')
    o.append(tabela(['Atividade'] + ['>' + mes_longo(mm) for mm in q['meses']] + ['>Total'],
                    [[esc(g['rot'])] + [valN(v) for v in g['meses']] + [valN(g['receita'])] for g in q['grupos']],
                    ['Receita bruta'] + [valN(x['rec']) for x in q['mesesInfo']] + [valN(q['recOp'])]))
    if q.get('servAtiv'):
        sec('Atividades de serviço lidas dos XML × tipo de serviço')
        o.append(tabela(['Atividade (XML)'] + ['>' + mes_longo(mm) for mm in q['meses']] + ['>Total', 'Sugestão pelo código', 'Natureza usada', '>% IRPJ', '>% CSLL'],
                        [[esc(f"{a['it'] or 's/ código'} — {a['x'] or ''}")] + [valN(v) if v else '—' for v in a['meses']] + [valN(a['total'])]
                         + [esc(LPM.grupo(a['sug'])['curto']),
                            (f"<span class=bad>{esc(LPM.grupo(a['grupo'])['curto'])}</span>" if a['grupo'] != a['sug'] else esc(LPM.grupo(a['grupo'])['curto'])),
                            pctN(a['pIrpj'], 1), pctN(a['pCsll'], 1)] for a in q['servAtiv']]))
    sec('IRPJ')
    o += [lin(g, 'pIrpj', 'baseIrpj', 'excI', M and M['irpj']) for g in q['grupos']]
    o.append(ad)
    o.append(f"<p class=formula>Base = {valN(q['presI'])} presumida + {valN(q['adicTot'])} = <b>{valN(q['baseIrpj'])}</b> · IRPJ normal 15% = <b>{valN(q['irpjN'])}</b></p>")
    o.append(f"<p class=formula>Adicional 10% × ({valN(q['baseIrpj'])} − {valN(q['limAdic'])}) = <b>{valN(q['adicional'])}</b></p>")
    o.append(f"<p class=formula>IRRF aproveitável = {valN(q['irrfNotas'])} retido nas notas (XML + outros documentos do mês) + {valN(r2(q['irrf'] - q['irrfNotas']))} informado no trimestre = <b>{valN(q['irrf'])}</b></p>")
    o.append(f"<p class=formula>{valN(q['irpjN'])} + {valN(q['adicional'])} − IRRF {valN(q['irrf'])} − outras deduções {valN(q['outrasDed'])} = <b>IRPJ a pagar {valN(q['irpjPagar'])}</b></p>")
    sec('CSLL')
    o += [lin(g, 'pCsll', 'baseCsll', 'excC', M and M['csll']) for g in q['grupos']]
    o.append(ad)
    o.append(f"<p class=formula>CSLL retida = {valN(q['csllNotas'])} nas notas (XML + outros documentos do mês) + {valN(r2(q['csllRet'] - q['csllNotas']))} informada no trimestre = <b>{valN(q['csllRet'])}</b></p>")
    o.append(f"<p class=formula>Base = {valN(q['presC'])} presumida + {valN(q['adicTot'])} = <b>{valN(q['baseCsll'])}</b> · CSLL 9% = {valN(q['csll'])} − retida {valN(q['csllRet'])} = <b>CSLL a pagar {valN(q['csllPagar'])}</b></p>")
    if q.get('retNotas'):
        sec('Retenções lidas do XML, nota a nota')
        o.append(_tab_ret_notas(q['retNotas']))
        o.append('<p class=mut style="font-size:8.5pt">NFS-e Nacional: vRetIRRF = IRRF; desde a NT 007 (09/02/2026) vRetCSLL soma PIS + Cofins + CSLL retidos e o código '
                 'tpRetPisCofins diz quais foram retidos — o programa separa cada um. ABRASF: ValorIr, ValorCsll, ValorPis e ValorCofins.</p>')
    if M:
        sec('Acréscimo de 10% na presunção (LC 224/2025)')
        o.append(f"<p>Acumulado no ano antes do trimestre: {valN(M['acumAnt'])} ({'informado' if M['informado'] else 'calculado'}). Limite disponível = {valN(M['limiteTri'])} × {q['q']} − {valN(M['acumAnt'])} = <b>{valN(M['disponivel'])}</b>. "
                 f"Dentro do limite: {valN(M['dentro'])} · excedente: <b>{valN(M['excedente'])}</b>, rateado pela receita de cada atividade. "
                 f"Vigência: IRPJ desde {nome_mes(M['irpjDe'])}{'' if M['irpj'] else ' (não se aplica)'} · CSLL desde {nome_mes(M['csllDe'])}{'' if M['csll'] else ' (não se aplica a este trimestre)'}.</p>")
    o.append(f"<p class=mut style='font-size:8.5pt'>Regra {esc(q['regra']['versao'])}: {esc(q['regra']['origem'])}.</p>")
    return ''.join(o)


# ======================= CENTRO DE VALIDAÇÃO =======================
def fv(v):
    if v is None:
        return '—'
    if isinstance(v, (int, float)):
        return valN(v)
    return esc(v)


def ordenar_checks(ch, just_de):
    def grupo(x):
        if x['sev'] == 'na':
            return 4
        if x['sev'] == 'ok':
            return 3
        if just_de(x):
            return 2
        return 0 if x['sev'] == 'erro' else 1
    return sorted(enumerate(ch), key=lambda p: (grupo(p[1]), -(p[1].get('impacto') or 0), p[0]))


def centro(ch, just_de, travada, msg, s, prefixo=''):
    """Lista de validações em HTML com links: acao:<a>, just:<id>, desjust:<id>."""
    cls = s.get('cls', 'neutro')
    cor, fundo = CLS_COR.get(cls, CLS_COR['neutro'])
    o = [f'<table width="100%" cellpadding="8"><tr><td style="background-color:{fundo};color:{cor}">{chip(s["rot"], cls)} &nbsp;{esc(msg)}</td></tr></table>',
         f'<p><b style="color:{BAD}">{s.get("pendErros", 0)}</b> crítico(s) · <b style="color:{WARN}">{s.get("pendAlert", 0)}</b> atenção · '
         f'<b style="color:{OK}">{s.get("aprov", 0)}</b> aprovado(s) · progresso <b>{pctN(s.get("prog", 0), 0)}</b></p>']
    for _, x in ordenar_checks(ch, just_de):
        j = just_de(x)
        if j:
            rot, c = ('JUSTIFICADO' if x['sev'] == 'erro' else 'REVISADO'), 'neutro'
        else:
            rot, c = {'erro': 'ERRO', 'atencao': 'ATENÇÃO', 'ok': 'OK', 'na': 'N/A'}[x['sev']], {'erro': 'erro', 'atencao': 'atencao', 'ok': 'ok', 'na': 'neutro'}[x['sev']]
        faixa = {'erro': '#ef4444', 'atencao': '#f59e0b', 'ok': '#10b981'}.get(x['sev'] if not j else '', '#cbd5e1')
        fundo_c = {'erro': '#fff7f7', 'atencao': '#fffcf2'}.get(x['sev'] if not j else '', '#ffffff')
        resumo = x.get('resumo')
        if resumo is None:
            resumo = ('Diferença ' + brl(x['diferenca'])) if x.get('diferenca') is not None and abs(x['diferenca']) > 0.01 else ('Confere' if x['sev'] == 'ok' else '')
        imp = f"<b style='color:{BAD}'>{brl(x['impacto'])}</b><br><span class=mut style='font-size:8pt'>impacto estimado</span>" if x.get('impacto') else ''
        acao = f"<a href='{prefixo}acao:{esc(x['acao'][1])}'>{esc(x['acao'][0])} ›</a>" if x.get('acao') else ''
        o.append(f'<table width="100%" cellpadding="6" cellspacing="0" border="0" style="margin-top:8px;background-color:{fundo_c}"><tr>'
                 f'<td width="3" rowspan="2" style="background-color:{faixa};padding:0"></td>'
                 f'<td width="100" valign="top">{chip(rot, c)}</td>'
                 f'<td valign="top"><b>{esc(x["titulo"])}</b><br><span class=mut style="font-size:8.5pt">{esc(x["cat"])}{" · " + esc(resumo) if resumo else ""}</span></td>'
                 f'<td width="130" align="right" valign="top">{imp}</td><td width="140" align="right" valign="top">{acao}</td></tr>')
        det = []
        if x.get('esperado') is not None:
            det.append(f"<span class=mut>{esc(x.get('rotEsp') or 'Sistema')}:</span> <b>{fv(x['esperado'])}</b>")
        if x.get('encontrado') is not None:
            det.append(f"<span class=mut>{esc(x.get('rotEnc') or 'Declarado')}:</span> <b>{fv(x['encontrado'])}</b>")
        if x.get('diferenca') is not None:
            det.append(f"<span class=mut>Diferença:</span> <b{' style=color:' + BAD if abs(x['diferenca']) > 0.05 else ''}>{fv(x['diferenca'])}</b>")
        if det or x.get('causa') or x.get('origem') or x['sev'] in ('erro', 'atencao'):
            cel = ''
            if det:
                cel += ' &nbsp;&nbsp; '.join(det) + '<br>'
            if x.get('origem'):
                cel += f"<span class=mut style='font-size:8.5pt'>Origem: {esc(x['origem'])}</span><br>"
            if x.get('causa'):
                cel += f"<span style='font-size:9pt'><b>{'Causa provável' if x['sev'] in ('erro', 'atencao') else 'Observação'}:</b> {esc(x['causa'])}</span><br>"
            if j:
                cel += (f"<span style='background-color:#f1f5f9'><b>{'Justificativa' if x['sev'] == 'erro' else 'Revisado'}</b> por {esc(j['por'])} em {data_hora(j['em'])}"
                        f"{': ' + esc(j['texto']) if j.get('texto') else ''}</span>" + ('' if travada else f" &nbsp;<a href='{prefixo}desjust:{esc(x['id'])}'>desfazer</a>"))
            elif x['sev'] in ('erro', 'atencao') and not travada and not x.get('bloqueia'):
                cel += f"<a href='{prefixo}just:{esc(x['id'])}'>{'Justificar divergência' if x['sev'] == 'erro' else 'Marcar como revisado'} ›</a>"
            elif x.get('bloqueia') and x['sev'] == 'erro':
                cel += '<span class=mut><b>Não pode ser justificado:</b> resolva nos meses.</span>'
            o.append(f'<tr><td></td><td colspan="3">{cel}</td></tr>')
        o.append('</table>')
    return ''.join(o)


def historico(app, id_):
    raiz, imp = app.import_de(id_)
    ap = app.est.apur.get(raiz) or {}
    pgs = (imp or {}).get('pgdas') or {}
    meses = sorted(set(ap) | set(pgs), reverse=True)
    if not meses:
        return '<p class=mut>Nenhuma apuração salva ou PGDAS-D importado.</p>'
    lin = []
    for m in meses:
        a, p = ap.get(m), pgs.get(m)
        dif = r2(p['das']['total'] - a['resultado']['total_calculado']) if a and p and p.get('das') else None
        sit = []
        if a:
            sit.append(f"salva {data_hora(a['salvoEm'])}" + (' · <b class=okc>validada</b>' if a.get('validacao') else ''))
        if p:
            sit.append('PGDAS-D importado')
        if dif is not None and abs(dif) > 0.05:
            sit.append(f'<b class=bad>dif. {brl(dif)}</b>')
        acoes = []
        if a:
            acoes.append(f"<a href='delap:{m}'>excluir apuração</a>")
        if p:
            acoes.append(f"<a href='delpg:{m}'>excluir PGDAS</a>")
        lin.append([f"<a href='irpa:{m}'>{nome_mes(m)}</a>" + (' ◀' if m == app.comp else ''), brl((a or {}).get('rpa', (p or {}).get('rpa'))),
                    brl(p['das']['total']) if p and p.get('das') else '—', brl(a['resultado']['total_calculado']) if a else '—', ' · '.join(sit), ' · '.join(acoes)])
    return tabela(['PA', '>Receita', '>DAS declarado', '>DAS apurado', 'Situação', ''], lin)


def trilha_html(L, so_comp=True):
    if not L:
        return f'<p class=mut>Nenhuma alteração registrada{" nesta competência" if so_comp else ""}.</p>'
    cab = ['Quando', 'Quem'] + ([] if so_comp else ['PA']) + ['Ação', 'Campo', 'De', 'Para']
    lin = [[data_hora(x['em']), esc(x.get('por'))] + ([] if so_comp else [nome_mes(x.get('comp', ''))]) +
           [esc(x.get('acao')), esc(x.get('campo', '')), esc(x.get('de', '')), esc(x.get('para', ''))] for x in L]
    return tabela(cab, lin)


# ======================= RELATÓRIOS (navegador) =======================
CSS_PRINT = """body{font-family:Inter,'Segoe UI',Arial,sans-serif;font-size:11.5px;color:#111;margin:24px;-webkit-print-color-adjust:exact;print-color-adjust:exact}
h2{font-size:16px;margin:0 0 6px;color:#094488}h3{font-size:12px;text-transform:uppercase;margin:14px 0 6px}h4{font-size:13px;margin:16px 0 6px;border-bottom:1px solid #ccc;padding-bottom:3px;color:#094488}
table{border-collapse:collapse;width:100%;margin:4px 0 8px}th,td{border:1px solid #d5d9e0;padding:4px 6px;text-align:left;vertical-align:top}th{background:#f2f4f7}
.n{text-align:right}.mut{color:#666}.formula{background:#f6f6f6;padding:6px 8px;border-left:3px solid #094488}.bad{color:#b91c1c;font-weight:bold}.okc{color:#047857;font-weight:bold}
tr{page-break-inside:avoid}@media print{body{margin:10mm}}"""


def pasta_relatorios():
    from .store import pasta_dados
    p = pasta_dados() / 'relatorios'
    p.mkdir(exist_ok=True)
    return p


def abrir_impressao(titulo, corpo, usuario, logo_path=None, paisagem=False):
    logo = ''
    if logo_path and os.path.exists(logo_path):
        logo = f'<img src="{Path(logo_path).as_uri()}" style="height:38px;margin:0 0 14px" alt="Contrato">'
    pag = '@page{size:A4 landscape}' if paisagem else ''
    html = (f'<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>{esc(titulo)}</title><style>{CSS_PRINT}{pag}</style></head><body>{logo}{corpo}'
            f'<p class="mut" style="font-size:10px">Contrato · Contabilidade e Consultoria — gerado em {datetime.now().strftime("%d/%m/%Y %H:%M")} por {esc(usuario)}</p>'
            '<script>window.onload=()=>window.print()</script></body></html>')
    nome = ''.join(ch if ch.isalnum() or ch in ' -_' else '_' for ch in titulo)[:90] + '.html'
    arq = pasta_relatorios() / nome
    arq.write_text(html, 'utf-8')
    webbrowser.open(arq.as_uri())
    return arq


def relatorio_validacao(app, id_, logo):
    k = app.chave(id_)
    r = app.RES.get(k) or app.apurar_caso(id_)
    if not r:
        return 'Sem apuração nesta competência.'
    s = app.situacao(id_)
    ch = app.CHK.get(k) or []
    nome, cnpj = app.nome(id_), app.cnpj(id_)
    lin = []
    for x in ch:
        j = app.just_de(id_, x)
        rot = ('JUSTIFICADO' if x['sev'] == 'erro' else 'REVISADO') if j else {'erro': 'ERRO', 'atencao': 'ATENÇÃO', 'ok': 'OK', 'na': 'N/A'}[x['sev']]
        lin.append(f"<tr><td>{rot}</td><td>{esc(x['titulo'])}</td><td class=n>{fv(x.get('esperado'))}</td><td class=n>{fv(x.get('encontrado'))}</td>"
                   f"<td class=n>{fv(x.get('diferenca'))}</td><td class=n>{valN(x['impacto']) if x.get('impacto') else '—'}</td>"
                   f"<td>{esc((j.get('texto') or 'revisado') + ' — ' + j['por'] + ', ' + data_hora(j['em'])) if j else esc(x.get('causa', ''))}</td></tr>")
    lp_ = r.get('regime') == 'LP'
    corpo = (f"<h2>Relatório de validação — {'Lucro Presumido' if lp_ else 'Simples Nacional'}</h2>"
             f"<p><b>{esc(nome)}</b> · CNPJ {esc(fmt_cnpj(cnpj))} · Período de apuração <b>{nome_mes(app.comp)}</b></p>"
             f"<table><tr><th>Situação</th><td>{esc(s['rot'])}{(' — ' + esc(s['v']['por']) + ', ' + data_hora(s['v']['em'])) if s.get('v') else ''}</td><th>Regra</th><td>{esc(r['regra']['versao'])}</td></tr>"
             f"<tr><th>Receita do mês</th><td class=n>{valN(r['rpa'])}</td>"
             + (f"<th>Regime · trimestre</th><td>Lucro Presumido · {r['tri']['q']}º tri {r['tri']['ano']}</td>" if lp_ else f"<th>RBT12 · faixa</th><td class=n>{valN(r['rbt12'])} · {r['faixa']}ª</td>")
             + f"</tr><tr><th>Tributos recalculados</th><td class=n>{valN(r['total_calculado'])}</td><th>Declarado</th><td class=n>{valN(r['das_informado']) if r['das_informado'] is not None else '—'}</td></tr>"
             f"<tr><th>Validações</th><td colspan=3>{s['aprov']} aprovada(s) · {s['erros']} erro(s) · {s['alertas']} alerta(s) · {s['just']} justificada(s)/revisada(s)</td></tr></table>"
             f"<h4>Validações</h4><table><tr><th>Resultado</th><th>Validação</th><th class=n>Sistema</th><th class=n>Declarado</th><th class=n>Diferença</th><th class=n>Impacto</th><th>Causa / justificativa</th></tr>{''.join(lin)}</table>"
             f"<h4>Memória de cálculo</h4>{memoria_lp(r, nome, cnpj) if lp_ else memoria_sn(r, nome, cnpj, app.comp)}"
             f"<h4>Trilha da competência</h4>{trilha_html(app.trilha(id_, True), True)}"
             f"<p class=mut>Regra aplicada: {esc(r['regra']['origem'])}.</p>")
    abrir_impressao(f'Validação – {nome} – {nome_mes(app.comp)}', corpo, app.usuario(), logo)


def relatorio_memoria(app, id_, logo):
    r = app.RES.get(app.chave(id_))
    if not r:
        return 'Sem apuração nesta competência.'
    nome, cnpj = app.nome(id_), app.cnpj(id_)
    corpo = '<h2>Memória de cálculo</h2>' + (memoria_lp(r, nome, cnpj) if r.get('regime') == 'LP' else memoria_sn(r, nome, cnpj, app.comp))
    abrir_impressao(f'Memória de cálculo – {nome} – {nome_mes(app.comp)}', corpo, app.usuario(), logo)


def relatorio_carteira(app, logo):
    L = app.linhas_carteira()
    if not L:
        return 'Selecione empresas primeiro.'
    from .servico import ROT_SIT
    cnt = {}
    for l in L:
        cnt[l['s']['cod']] = cnt.get(l['s']['cod'], 0) + 1

    def tot(k):
        return r2(sum((l['r'] or {}).get(k) or 0 for l in L))
    lin = []
    for l in L:
        r = l['r'] or {}
        rb = f"{valN(r['rbt12'])} · {r['faixa']}ª" if r.get('faixa') else ('Lucro Presumido' if r.get('regime') == 'LP' else '—')
        lin.append(f"<tr><td>{esc(l['nome'])}<br><span class=mut>{esc(fmt_cnpj(l['cnpj']))}</span></td><td>{esc(l['s']['rot'])}</td>"
                   f"<td class=n>{valN(r['rpa']) if r else '—'}</td><td class=n>{rb}</td><td class=n>{valN(r['total_calculado']) if r else '—'}</td>"
                   f"<td class=n>{valN(r['das_informado']) if r.get('das_informado') is not None else '—'}</td><td class=n>{valN(r['diferenca']) if r.get('diferenca') is not None else '—'}</td>"
                   f"<td>{'; '.join(esc(x['titulo']) for x in l['pend']) or '—'}</td><td>{(esc(l['s']['v']['por']) + '<br>' + data_hora(l['s']['v']['em'])) if l['s'].get('v') else ''}</td></tr>")
    corpo = (f"<h2>Relatório da carteira</h2><p>Competência <b>{nome_mes(app.comp)}</b> · {len(L)} empresa(s) · "
             + ' · '.join(f'{v} {ROT_SIT[k]}' for k, v in cnt.items()) + '</p>'
             f"<table><tr><th>Empresa</th><th>Situação</th><th class=n>Receita</th><th class=n>RBT12 · faixa</th><th class=n>Tributos recalc.</th><th class=n>Declarado</th><th class=n>Dif.</th><th>Pendências</th><th>Validado por</th></tr>{''.join(lin)}"
             f"<tr><th colspan=2>Total</th><th class=n>{valN(tot('rpa'))}</th><th></th><th class=n>{valN(tot('total_calculado'))}</th><th class=n>{valN(tot('das_informado'))}</th><th></th><th></th><th></th></tr></table>")
    abrir_impressao(f'Carteira – {nome_mes(app.comp)}', corpo, app.usuario(), logo, paisagem=True)


def relatorio_tri(app, id_, T, q, ch, logo):
    nome, cnpj = app.nome(id_), app.cnpj(id_)
    lin = ''.join(f"<tr><td>{LPM.SEV_ROT[x['sev']]}</td><td>{esc(x['titulo'])}</td><td class=n>{fv(x.get('esperado'))}</td><td class=n>{fv(x.get('encontrado'))}</td><td class=n>{fv(x.get('diferenca'))}</td></tr>" for x in ch)
    corpo = (f"<h2>IRPJ e CSLL — {T['q']}º trimestre {T['ano']}</h2>{memoria_tri(q, nome, cnpj)}"
             f"<h4>Validação do trimestre</h4><table><tr><th>Resultado</th><th>Validação</th><th class=n>Calculado</th><th class=n>Declarado</th><th class=n>Diferença</th></tr>{lin}</table>")
    abrir_impressao(f"IRPJ e CSLL – {nome} – {T['q']}º tri {T['ano']}", corpo, app.usuario(), logo)


# ======================= CSV =======================
def _csv(caminho, linhas):
    with open(caminho, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f, delimiter=';', quoting=csv.QUOTE_ALL)
        w.writerows(linhas)


def _nb(v):
    if v is None:
        return ''
    if isinstance(v, (int, float)):
        return str(r2(v)).replace('.', ',')
    return v


def csv_resumo(app, caminho):
    ids = app.ids_sel()
    cab = ['empresa', 'cnpj', 'competencia', 'regime', 'status', 'rpa', 'rbt12', 'faixa', 'fator_r', 'tributos_calculados', 'declarado', 'diferenca'] + ORDEM + ['alertas']
    lin = []
    for id_ in ids:
        r = app.RES.get(app.chave(id_)) or {}
        lin.append([app.nome(id_), app.cnpj(id_), app.comp, app.regime_de(id_), app.situacao(id_)['rot'], _nb(r.get('rpa')), _nb(r.get('rbt12')), r.get('faixa') or '',
                    (f"{r['fator_r'] * 100:.2f}%".replace('.', ',') if r.get('fator_r') is not None else ''), _nb(r.get('total_calculado')),
                    _nb(r.get('das_informado')), _nb(r.get('diferenca'))] + [_nb((r.get('tributos') or {}).get(t)) for t in ORDEM]
                   + [' | '.join(a[1] for a in r.get('alertas') or [] if a[0] != 'info')])
    _csv(caminho, [cab] + lin)
    return len(lin)


def csv_divergencias(app, ids, caminho):
    from .servico import SEV_ROT
    cab = ['empresa', 'cnpj', 'competencia', 'regra_id', 'categoria', 'severidade', 'validacao', 'sistema', 'declarado', 'diferenca', 'impacto',
           'causa_provavel', 'acao_sugerida', 'status', 'justificativa', 'responsavel', 'data_resolucao']
    lin = []
    for id_ in ids:
        for x in app.CHK.get(app.chave(id_)) or []:
            if x['sev'] in ('ok', 'na'):
                continue
            j = app.just_de(id_, x)
            lin.append([app.nome(id_), app.cnpj(id_), app.comp, x['id'], x['cat'], SEV_ROT[x['sev']], x['titulo'], _nb(x.get('esperado')), _nb(x.get('encontrado')),
                        _nb(x.get('diferenca')), _nb(x.get('impacto')), x.get('causa', ''), (x.get('acao') or [''])[0],
                        ('justificado' if x['sev'] == 'erro' else 'revisado') if j else 'pendente', (j or {}).get('texto', ''), (j or {}).get('por', ''),
                        data_hora(j['em']) if j else ''])
    if not lin:
        return 0
    _csv(caminho, [cab] + lin)
    return len(lin)


# ======================= FATOR R — PROJEÇÃO DO MÊS SEGUINTE =======================
def fator_r_resumo(app, id_):
    """Resumo do Fator R atual e projetado de uma empresa na competência aberta (app.comp)."""
    base = {'id': id_, 'nome': app.nome(id_), 'cnpj': app.cnpj(id_), 'pa': app.comp, 'prox': mes_add(app.comp, 1),
            'fr': None, 'anexo': None, 'fr_prox': None, 'anexo_prox': None, 'folha_min': None, 'estimada': False,
            'folha12_prox': None, 'rbt12_prox': None, 'r': None, 'sit': '', 'cls': 'neutro', 'tem_fr': False,
            'atividades': [{'cod': k, 'nome': ATV.rotulo(k), 'regra': ATV.regra_texto(k)} for k in app.atividades(id_)]}
    if app.regime_de(id_) != 'SN':
        return {**base, 'sit': 'Não é Simples Nacional'}
    try:
        r = app.RES.get(app.chave(id_)) or app.apurar_caso(id_)
    except Exception as e:  # noqa: BLE001
        return {**base, 'sit': f'Erro ao apurar: {e}', 'cls': 'erro'}
    if not r:
        return {**base, 'sit': 'Sem receitas na competência'}
    px = r.get('prox') or {}
    tem = any(it.get('anexoOrig') == 'FATOR_R' for it in r.get('itens') or [])
    frm = px.get('fatorRMin') or 0.28
    fr, fr2 = r.get('fator_r'), px.get('fator_r')
    an = None if fr is None else ('III' if fr >= frm else 'V')
    an2 = px.get('anexoFR') or (None if fr2 is None else ('III' if fr2 >= frm else 'V'))
    if not tem and any(ATV.ATIVIDADES[a['cod']]['anexo'] == 'FATOR_R' for a in base['atividades']):
        sit, cls = 'Atividade do Fator R, mas as receitas não estão nesse anexo', 'atencao'
    elif not tem:
        sit, cls = 'Sem atividade sujeita ao Fator R', 'neutro'
    elif fr2 is None:
        sit, cls = 'Sem folha para projetar', 'erro'
    elif an2 == 'V':
        sit, cls = ('Passa para o Anexo V' if an == 'III' else 'Continua no Anexo V'), 'erro'
    elif fr2 < app.param()['frAlerta']:
        sit, cls = ('Volta ao Anexo III' if an == 'V' else 'Anexo III, perto do mínimo'), 'atencao'
    else:
        sit, cls = ('Volta ao Anexo III' if an == 'V' else 'Mantém o Anexo III'), 'ok'
    return {**base, 'fr': fr, 'anexo': an, 'fr_prox': fr2, 'anexo_prox': an2, 'folha_min': px.get('folha_min_mes'),
            'estimada': bool(px.get('folha_estimada')), 'folha12_prox': px.get('folha_12m'), 'rbt12_prox': px.get('rbt12'),
            'r': r, 'sit': sit, 'cls': cls, 'tem_fr': tem}


def fator_r_html(app, s):
    """Relatório de uma empresa: janela do mês seguinte no formato da planilha de folha + sócios e funcionários."""
    r = s['r']
    c, prox = s['pa'], s['prox']
    o = [f"<h2>Fator R — projeção para {nome_mes(prox)}</h2>",
         f"<p><b>{esc(s['nome'])}</b> · CNPJ {esc(fmt_cnpj(s['cnpj']))} · apurado em {nome_mes(c)}</p>"]
    for k, a in enumerate(s.get('atividades') or []):
        o.append(f"<p style='margin:2px 0'>{'<b>Atividade:</b> ' if k == 0 else '<span class=mut>Também:</span> '}{esc(a['nome'])} "
                 f"<span class=mut>— {esc(a['regra'])}</span></p>")
    if not r or not s['tem_fr']:
        o.append(f"<p class=mut>{esc(s['sit'])}.</p>")
        return ''.join(o)
    m = r['memo']
    px = r.get('prox') or {}
    cor = {'ok': OK, 'atencao': WARN, 'erro': BAD}.get(s['cls'], MUT)
    o.append('<table><tr>'
             f"<th>Fator R {nome_mes(c)}</th><td class=n>{pctN(s['fr']) if s['fr'] is not None else '—'} → Anexo {s['anexo'] or '—'}</td>"
             f"<th>Fator R {nome_mes(prox)}</th><td class=n style='color:{cor}'><b>{pctN(s['fr_prox']) if s['fr_prox'] is not None else '—'} → Anexo {s['anexo_prox'] or '—'}</b></td>"
             f"<th>Situação</th><td style='color:{cor}'><b>{esc(s['sit'])}</b></td></tr>"
             f"<tr><th>Folha 12m projetada</th><td class=n>{valN(s['folha12_prox']) if s['folha12_prox'] is not None else '—'}</td>"
             f"<th>RBT12 projetado</th><td class=n>{valN(s['rbt12_prox']) if s['rbt12_prox'] is not None else '—'}</td>"
             f"<th>Folha mínima de {nome_mes(c)}</th><td class=n>{valN(s['folha_min']) if s['folha_min'] is not None else '—'}</td></tr></table>")
    fd = m.get('folhaDet') or {}
    lin, tp, tf, ti, tt, tr = [], 0, 0, 0, 0, 0
    for i in range(11, -1, -1):
        mm = mes_add(c, -i)
        rec = r['rpa'] if mm == c else (m.get('hist') or {}).get(mm)
        fol = px.get('folha_mes') if mm == c else (m.get('folhaMeses') or {}).get(mm)
        d = fd.get(mm) or {}
        tp, tf, ti = tp + (d.get('prov') or 0), tf + (d.get('fgts') or 0), ti + (d.get('inss') or 0)
        tt, tr = tt + (fol or 0), tr + (rec or 0)
        lin.append([nome_mes(mm) + (' (PA)' if mm == c else ''), valN(d['prov']) if d else '', valN(d['fgts']) if d else '',
                    valN(d['inss']) if d else '', valN(fol) if fol is not None else '—', valN(rec) if rec is not None else '—'])
    o.append(f"<h4>Janela de {nome_mes(mes_add(c, -11))} a {nome_mes(c)}</h4>")
    o.append(tabela(['Mês', '>Proventos', '>FGTS', '>INSS/CPP', '>Total de folha', '>Faturamento'], lin,
                    tot=['Total', valN(tp) if fd else '', valN(tf) if fd else '', valN(ti) if fd else '', valN(tt), valN(tr)]))
    if px.get('folha_anual') is not None and abs(px['folha_anual'] - (px.get('folha_12m') or 0)) > 0.01:
        o.append(nota(f"Início de atividade: {esc(px.get('origemFolhaAnual') or '')} = {valN(px['folha_anual'])}, pelo mesmo critério do RBT12."))
    o.append(nota(f"Fator R {nome_mes(prox)} = folha ÷ RBT12 = <b>{pctN(s['fr_prox']) if s['fr_prox'] is not None else '—'}</b> "
                  f"({'≥' if (s['fr_prox'] or 0) >= px.get('fatorRMin', .28) else '<'} 28%) → Anexo <b>{s['anexo_prox'] or '—'}</b>."
                  + (f" Para manter 28%, a folha de {nome_mes(c)} precisa ser de pelo menos <b>{valN(s['folha_min'])}</b>." if s['folha_min'] is not None else '')
                  + (f" <i>Folha de {nome_mes(c)} não informada: {esc(px.get('origemFolhaMes') or 'estimada')}.</i>" if s['estimada'] else ''),
                  'ok' if s['anexo_prox'] == 'III' else 'at'))
    pj = app.pessoas_janela(s['id'], [mes_add(c, -i) for i in range(11, -1, -1)])
    if pj:
        o.append(f"<h4>Sócios e funcionários — {nome_mes(mes_add(c, -11))} a {nome_mes(c)}</h4>")
        o.append(tabela(['Nome', 'Tipo', '>Meses', '>Proventos', '>FGTS', '>INSS/CPP', '>Total na janela', f'>{nome_mes(c)}'],
                        [[esc(p['nome']), 'Sócio' if p['tipo'] == 'socio' else 'Funcionário', str(p['meses']), valN(p['prov']), valN(p['fgts']),
                          valN(p['inss']), valN(p['total']), valN(p['por_mes'][c]) if c in p['por_mes'] else '—'] for p in pj],
                        tot=['Total', '', '', valN(sum(p['prov'] for p in pj)), valN(sum(p['fgts'] for p in pj)), valN(sum(p['inss'] for p in pj)),
                             valN(sum(p['total'] for p in pj)), valN(sum(p['por_mes'].get(c, 0) for p in pj))]))
    return ''.join(o)


def _fr_resumo_tabela(L):
    lin = []
    for s in L:
        cor = {'ok': OK, 'atencao': WARN, 'erro': BAD}.get(s['cls'], MUT)
        lin.append([f"{esc(s['nome'])}<br><span class=mut>{esc(fmt_cnpj(s['cnpj']))}</span>",
                    f"{pctN(s['fr'])} → {s['anexo']}" if s['fr'] is not None else '—',
                    f"<b style='color:{cor}'>{pctN(s['fr_prox'])} → {s['anexo_prox']}</b>" if s['fr_prox'] is not None else '—',
                    valN(s['folha_min']) if s['folha_min'] is not None else '—',
                    f"<span style='color:{cor}'>{esc(s['sit'])}</span>" + (' <span class=mut>(folha do mês estimada)</span>' if s['estimada'] else '')])
    return tabela(['Empresa', '>Fator R PA', '>Fator R projetado', '>Folha mínima do PA', 'Situação'], lin)


def relatorio_fator_r(app, ids, logo):
    """Relatório consolidado (abre no navegador para imprimir/salvar PDF): resumo + uma página por empresa."""
    L = [fator_r_resumo(app, i) for i in ids]
    if not L:
        return 'Escolha ao menos uma empresa.'
    c, prox = app.comp, mes_add(app.comp, 1)
    corpo = (f"<h2>Fator R — projeção para {nome_mes(prox)}</h2><p>Apurado em <b>{nome_mes(c)}</b> · {len(L)} empresa(s). "
             f"Janela de {nome_mes(mes_add(c, -11))} a {nome_mes(c)}: entra a folha e a receita do PA, sai {nome_mes(mes_add(c, -12))}.</p>"
             + _fr_resumo_tabela(L)
             + ''.join(f'<div style="page-break-before:always">{fator_r_html(app, s)}</div>' for s in L if s['tem_fr']))
    abrir_impressao(f'Fator R – projeção {nome_mes(prox)}', corpo, app.usuario(), logo)
    return None


def pdf_fator_r(app, ids, pasta, logo=None):
    """Um PDF por empresa, gravado direto na pasta (sem abrir o navegador). Retorna a lista de arquivos."""
    from PySide6.QtGui import QTextDocument, QPdfWriter, QPageSize, QPageLayout
    from PySide6.QtCore import QMarginsF
    prox = mes_add(app.comp, 1)
    arqs = []
    img = f'<img src="{Path(logo).as_uri()}" height="34"><br>' if logo and os.path.exists(logo) else ''
    for i in ids:
        s = fator_r_resumo(app, i)
        if not s['tem_fr']:
            continue
        html = (f'<html><head><style>{CSS_QT} table {{border-collapse:collapse}} td, th {{border:1px solid #e2e8f0}}</style></head><body>'
                f"{img}{fator_r_html(app, s)}<p class=mut style='font-size:8pt'>Contrato · Contabilidade e Consultoria — gerado em "
                f"{datetime.now().strftime('%d/%m/%Y %H:%M')} por {esc(app.usuario())}</p></body></html>")
        nome = ''.join(ch if ch.isalnum() or ch in ' -_' else '_' for ch in f"Fator R {prox} - {s['nome']}")[:110] + '.pdf'
        caminho = str(Path(pasta) / nome)
        w = QPdfWriter(caminho)
        w.setPageSize(QPageSize(QPageSize.A4))
        w.setPageMargins(QMarginsF(14, 14, 14, 14), QPageLayout.Millimeter)
        w.setResolution(110)
        doc = QTextDocument()
        doc.setHtml(html)
        doc.setPageSize(w.pageLayout().paintRectPixels(w.resolution()).size().toSizeF())
        doc.print_(w)
        del w
        arqs.append(caminho)
    return arqs


def csv_fator_r(app, ids, caminho):
    cab = ['empresa', 'cnpj', 'pa', 'fator_r_pa', 'anexo_pa', 'competencia_projetada', 'fator_r_projetado', 'anexo_projetado',
           'folha_12m_projetada', 'rbt12_projetado', 'folha_minima_pa', 'folha_pa_estimada', 'situacao', 'atividade_principal', 'tributacao_lc123']
    lin = []
    for i in ids:
        s = fator_r_resumo(app, i)
        if not s['tem_fr']:
            s = {**s, 'folha12_prox': None, 'rbt12_prox': None}
        f = (lambda v: f"{v * 100:.2f}%".replace('.', ',') if v is not None else '')
        lin.append([s['nome'], s['cnpj'], s['pa'], f(s['fr']), s['anexo'] or '', s['prox'], f(s['fr_prox']), s['anexo_prox'] or '',
                    _nb(s['folha12_prox']), _nb(s['rbt12_prox']), _nb(s['folha_min']), 'sim' if s['estimada'] else '', s['sit'],
                    (s['atividades'] or [{}])[0].get('nome', ''), (s['atividades'] or [{}])[0].get('regra', '')])
    _csv(caminho, [cab] + lin)
    return len(lin)


# ======================= FATOR R — APURAÇÃO DA TELA (impressão) =======================
CSS_FR = """
@page{size:A4 portrait;margin:12mm 12mm 14mm}
@page{@bottom-right{content:"Página " counter(page) " de " counter(pages);font:8pt 'Segoe UI',Arial,sans-serif;color:#64748b}}
*{box-sizing:border-box}
html{-webkit-print-color-adjust:exact;print-color-adjust:exact}
body{font-family:'Segoe UI',Inter,Arial,sans-serif;font-size:9.5pt;color:#0f172a;margin:0;background:#e9edf2}
.folha{max-width:200mm;margin:16px auto;background:#fff;padding:14mm 13mm 12mm;box-shadow:0 2px 14px rgba(15,23,42,.12)}
.barra{position:sticky;top:0;z-index:2;background:#094488;color:#fff;padding:9px 16px;display:flex;gap:12px;align-items:center;justify-content:center;font-size:9.5pt}
.barra button{background:#fff;color:#094488;border:0;border-radius:6px;padding:6px 16px;font-weight:700;cursor:pointer;font-size:9.5pt}
@media print{body{background:#fff}.folha{margin:0;padding:0;box-shadow:none;max-width:none}.barra{display:none}}
.cab{display:flex;justify-content:space-between;align-items:flex-end;padding-bottom:10px;border-bottom:3px solid #094488}
.cab img{height:40px;display:block}
.cab .tit{text-align:right}
.cab .sob{font-size:7.5pt;letter-spacing:.14em;text-transform:uppercase;color:#8c8c8f;font-weight:700}
.cab h1{margin:2px 0 0;font-size:17pt;color:#094488;font-weight:700;letter-spacing:-.01em}
.cab .lei{font-size:7.5pt;color:#64748b;margin-top:2px}
.emp{display:grid;grid-template-columns:2.2fr 1.1fr 1fr 1fr;border:1px solid #dbe2ea;border-top:0;border-radius:0 0 8px 8px;margin-bottom:12px}
.emp>div{padding:7px 10px;border-right:1px solid #dbe2ea}.emp>div:last-child{border-right:0}
.emp .rot,.card .rot,.k .rot{font-size:7pt;text-transform:uppercase;letter-spacing:.08em;color:#64748b;font-weight:600}
.emp .v{font-weight:600;font-size:10pt;margin-top:1px}
.emp .atv{grid-column:1/-1;border-top:1px solid #dbe2ea;border-right:0;font-size:8.5pt;background:#f8fafc;border-radius:0 0 8px 8px}
.cards{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px}
.card{border:1px solid #dbe2ea;border-radius:10px;padding:10px 12px;position:relative;overflow:hidden;break-inside:avoid}
.card:before{content:"";position:absolute;left:0;top:0;bottom:0;width:5px;background:var(--c)}
.card .topo{display:flex;justify-content:space-between;align-items:baseline}
.card .jan{font-size:8pt;color:#64748b}
.card .pct{font-size:24pt;font-weight:700;color:var(--c);line-height:1.1;margin:4px 0 2px;font-variant-numeric:tabular-nums}
.anx{display:inline-block;padding:2px 10px;border-radius:20px;font-weight:700;font-size:9pt;color:#fff;background:var(--c);vertical-align:middle;margin-left:6px}
.card .det{display:grid;grid-template-columns:1fr 1fr;gap:4px 12px;margin-top:6px;padding-top:6px;border-top:1px dashed #dbe2ea}
.card .det b{display:block;font-size:10pt;font-variant-numeric:tabular-nums}
.call{border-radius:8px;padding:8px 12px;margin:0 0 12px;font-size:9pt;break-inside:avoid}
.call.ok{background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0}
.call.at{background:#fffbeb;color:#92400e;border:1px solid #fde68a}
.call.bad{background:#fef2f2;color:#991b1b;border:1px solid #fecaca}
h2{font-size:10pt;text-transform:uppercase;letter-spacing:.08em;color:#094488;margin:14px 0 6px;padding-bottom:4px;border-bottom:1px solid #dbe2ea}
h2 small{text-transform:none;letter-spacing:0;color:#64748b;font-weight:400;font-size:8.5pt}
table{width:100%;border-collapse:collapse;font-variant-numeric:tabular-nums}
.t th{background:#094488;color:#fff;font-size:7.5pt;text-transform:uppercase;letter-spacing:.04em;font-weight:600;padding:6px 6px;text-align:right;vertical-align:bottom}
.t th:first-child,.t td:first-child{text-align:left}
.t td{padding:4.5px 6px;border-bottom:1px solid #e5e9f0;text-align:right;white-space:nowrap}
.t tbody tr:nth-child(even) td{background:#f8fafc}
.t td.o{text-align:left;font-size:7.3pt;color:#475569;white-space:normal;line-height:1.35;width:92px}
.t td.o .oi{display:block;white-space:nowrap}
.t td.j{text-align:center;color:#094488;font-size:8pt;width:46px}
.t th.j{text-align:center}
.t tr.pa td{background:#e8f1fb!important;font-weight:600}
.t tr.antes td{color:#94a3b8}
.t .tag{display:inline-block;font-size:6.5pt;font-weight:700;text-transform:uppercase;letter-spacing:.05em;padding:1px 5px;border-radius:3px;margin-left:5px;vertical-align:1px}
.tag.pa{background:#094488;color:#fff}.tag.sai{background:#fde68a;color:#78350f}.tag.ant{background:#e2e8f0;color:#64748b}
.t tfoot td{font-weight:700;border-top:2px solid #094488;border-bottom:0;padding:6px}
.t tfoot tr+tr td{border-top:1px solid #dbe2ea}
.t tfoot .r{color:var(--c)}
.t .sn{display:inline-block;font-size:6pt;font-weight:700;color:#0e7490;background:#cffafe;border-radius:3px;padding:0 3px;margin-right:4px;vertical-align:1px}
.t .falta{display:inline-block;font-size:6pt;font-weight:700;color:#92400e;background:#fef3c7;border-radius:3px;padding:0 3px;margin-right:4px;vertical-align:1px}
.calc .ln.sub{color:#475569}.calc .ln.tot{font-weight:700;border-top:1px solid #94a3b8;border-bottom:1px dotted #dbe2ea}
.calc .ln .op{display:inline-block;width:20px;color:#94a3b8;font-weight:700}
.dot{display:inline-block;width:7px;height:7px;border-radius:50%;margin-right:4px;vertical-align:0}
.calc{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.calc .bx{border:1px solid #dbe2ea;border-radius:8px;padding:8px 12px;break-inside:avoid}
.calc .bx .h{font-weight:700;color:#094488;font-size:9pt;margin-bottom:4px}
.calc .ln{display:flex;justify-content:space-between;padding:2.5px 0;border-bottom:1px dotted #dbe2ea}
.calc .ln:last-child{border-bottom:0;font-weight:700;color:var(--c);border-top:2px solid var(--c);margin-top:2px;padding-top:4px}
.calc .ln span:last-child{font-variant-numeric:tabular-nums}
.leg{font-size:7.5pt;color:#64748b;margin:5px 0 0}
.leg span{margin-right:10px;white-space:nowrap}
.notas{font-size:7.8pt;color:#475569;margin:12px 0 0;padding:8px 12px;background:#f8fafc;border-radius:8px;break-inside:avoid}
.notas p{margin:2px 0}
.ass{display:grid;grid-template-columns:1fr 1fr;gap:40px;margin-top:34px;break-inside:avoid}
.ass div{border-top:1px solid #0f172a;padding-top:4px;font-size:8pt;text-align:center;color:#475569}
.rod{margin-top:14px;padding-top:6px;border-top:1px solid #dbe2ea;font-size:7.5pt;color:#94a3b8;display:flex;justify-content:space-between}
"""

_COR_ORIG = {'PGDAS-D': '#8c8c8f', 'Apuração salva': '#059669', 'XML': '#c98a1c', 'Sócios e funcionários': '#7c3aed',
             'Digitado': '#0f172a', 'Receitas do mês': '#094488', 'CPP da apuração do SN': '#0e7490'}


_ORIG_CURTO = {'Receitas do mês': 'Mês apurado', 'Sócios e funcionários': 'Sócios/func.'}


def _orig_html(o, curto=False):
    if not o:
        return ''
    cor = _COR_ORIG.get(o, '#c98a1c')
    txt = _ORIG_CURTO.get(o, o) if curto else o
    return f'<span class="dot" style="background:{cor}"></span>{esc(txt)}'


def relatorio_fator_r_apuracao(d, usuario, logo_path=None):
    """Apuração do Fator R de uma empresa, montada com os valores da tela (etapa RBT12 e folha), para imprimir / salvar PDF."""
    c, prox, frm = d['pa'], d['prox'], d['frm'] or 0.28
    L = d['linhas']                                  # PA−12 … PA
    sr1, sf1 = d['janelas'][13]
    sr2, sf2 = d['janelas'][14]
    VERDE, VERM, CINZA = '#047857', '#b91c1c', '#64748b'

    def fr_de(sr, sf):
        return sf / sr if sr > 0 and sf > 0 else None

    fr1, fr2 = fr_de(sr1, sf1), fr_de(sr2, sf2)
    primeiro_ = d['n_ativ'] is not None and d['n_ativ'] <= 0
    jan1 = [L[12]] if primeiro_ else L[0:12]
    jan2 = L[1:13]
    cpp1 = r2(sum(x.get('cpp') or 0 for x in jan1 if not x['antes']))
    cpp2 = r2(sum(x.get('cpp') or 0 for x in jan2 if not x['antes']))
    n_cpp1 = sum(1 for x in jan1 if x.get('cpp'))
    n_cpp2 = sum(1 for x in jan2 if x.get('cpp'))
    faltam = [x['m'] for x in L if x.get('cpp_falta')]
    an1 = None if fr1 is None else ('III' if fr1 >= frm else 'V')
    an2 = None if fr2 is None else ('III' if fr2 >= frm else 'V')
    cor1 = CINZA if an1 is None else (VERDE if an1 == 'III' else VERM)
    cor2 = CINZA if an2 is None else (VERDE if an2 == 'III' else VERM)
    folha_pa = L[-1]['fol'] or 0
    folha_min = max(0.0, r2(frm * sr2 - (sf2 - folha_pa))) if sr2 > 0 else None
    primeiro = d['n_ativ'] is not None and d['n_ativ'] <= 0
    j1 = f"{nome_mes(mes_add(c, -12))} a {nome_mes(mes_add(c, -1))}" if not primeiro else f"1º mês: {nome_mes(c)}"
    j2 = f"{nome_mes(mes_add(c, -11))} a {nome_mes(c)}"

    def card(tit, jan, fr, an, sr, sf, cor):
        p = f"{pctN(fr)}" if fr is not None else ('sem folha' if sr > 0 else '—')
        badge = f'<span class="anx">Anexo {an}</span>' if an else ''
        return (f'<div class="card" style="--c:{cor}"><div class="topo"><span class="rot">{tit}</span><span class="jan">{jan}</span></div>'
                f'<div class="pct">{p}{badge}</div>'
                f'<div class="det"><div><span class="rot">Folha 12 meses (com CPP)</span><b>{valN(sf)}</b></div>'
                f'<div><span class="rot">Receita bruta 12 meses</span><b>{valN(sr)}</b></div></div></div>')

    o = []
    o.append('<div class="cab">' + (f'<img src="{Path(logo_path).as_uri()}" alt="Contrato">' if logo_path and os.path.exists(logo_path) else '<b>Contrato</b>')
             + '<div class="tit"><div class="sob">Simples Nacional · Apuração</div><h1>Fator R</h1>'
             '<div class="lei">LC 123/2006, art. 18, §§ 5º-J, 5º-M e 24 · Res. CGSN 140/2018, art. 26</div></div></div>')
    atv = ''.join(f"{'<b>Atividade:</b> ' if k == 0 else ' &nbsp;·&nbsp; <b>Também:</b> '}{esc(a['nome'])} <span style='color:#64748b'>— {esc(a['regra'])}</span>"
                  for k, a in enumerate(d.get('atividades') or []))
    o.append(f'<div class="emp"><div><div class="rot">Empresa</div><div class="v">{esc(d["nome"])}</div></div>'
             f'<div><div class="rot">CNPJ</div><div class="v">{esc(fmt_cnpj(d["cnpj"]))}</div></div>'
             f'<div><div class="rot">Período de apuração</div><div class="v">{esc(mes_longo(c))} de {c[:4]}</div></div>'
             f'<div><div class="rot">Início das atividades</div><div class="v">{esc(data_br(d["inicio"])) if d.get("inicio") else "—"}</div></div>'
             + (f'<div class="atv">{atv}</div>' if atv else '') + '</div>')
    o.append('<div class="cards">' + card(f'Fator R de {nome_mes(c)}', j1, fr1, an1, sr1, sf1, cor1)
             + card(f'Projeção para {nome_mes(prox)}', j2, fr2, an2, sr2, sf2, cor2) + '</div>')
    # mensagem principal
    if fr2 is None:
        o.append(f'<div class="call bad">Sem folha suficiente para projetar o Fator R de {nome_mes(prox)}: '
                 f'sem folha, as receitas do Fator R ficam no <b>Anexo V</b>.</div>')
    else:
        txt = (f'Em {nome_mes(prox)} a empresa {"permanece no" if an1 == an2 else "passa para o"} <b>Anexo {an2}</b> '
               f'(Fator R {pctN(fr2)} {"≥" if an2 == "III" else "<"} {pctN(frm, 0)}).')
        if folha_min is not None:
            txt += (f' Para ficar no Anexo III, a folha de {nome_mes(c)} (com o CPP) precisa ser de no mínimo <b>{brl(folha_min)}</b>'
                    f' — lançada: {brl(folha_pa)}' + (f', folga de {brl(folha_pa - folha_min)}.' if folha_pa >= folha_min
                                                     else f', faltam <b>{brl(folha_min - folha_pa)}</b>.'))
        o.append(f'<div class="call {"ok" if an2 == "III" else "bad"}">{txt}</div>')

    if faltam:
        o.append(f'<div class="call at">Sem apuração do Simples Nacional salva no Validador em <b>{", ".join(nome_mes(m) for m in faltam)}</b>: '
                 'o CPP desses meses não entrou na folha. Salve a apuração dessas competências para completar o cálculo.</div>')

    # tabela mês a mês
    o.append(f'<h2>Receita e folha mês a mês <small>— janela móvel de {nome_mes(mes_add(c, -12))} a {nome_mes(c)}</small></h2>')
    cab = ('<tr><th>Competência</th><th>Receita bruta</th><th>Proventos</th><th>FGTS</th><th>INSS/CPP</th><th>Total da folha</th>'
           f'<th style="text-align:left">Origem<br>receita / folha</th><th class="j">FR<br>{esc(nome_mes(c))}</th><th class="j">Proj.<br>{esc(nome_mes(prox))}</th></tr>')
    lin = []
    tp = tf = ti = 0.0
    for k, x in enumerate(L):
        tag = ('<span class="tag ant">antes</span>' if x['antes'] else '<span class="tag pa">PA</span>' if x['pa']
               else '<span class="tag sai">sai</span>' if k == 0 else '')
        cls = 'antes' if x['antes'] else ('pa' if x['pa'] else '')
        em1 = (k == 12) if primeiro else (k < 12)
        em2 = k >= 1
        if em2 and not x['antes']:
            tp, tf, ti = tp + (x['prov'] or 0), tf + (x['fgts'] or 0), ti + (x.get('cpp') or x['inss'] or 0)
        orig = ''.join(f'<span class="oi">{t}</span>' for t in filter(None, [
            _orig_html(x['orig_rec'], True), _orig_html(x['orig_fol'], True) if x['orig_fol'] != x['orig_rec'] else '']))
        fv_ = (lambda v: valN(v) if v else '<span style="color:#cbd5e1">—</span>')

        def inss_cel(x):
            if x.get('cpp'):
                return f'<span class="sn">SN</span>{valN(x["cpp"])}'
            if x.get('cpp_falta'):
                return '<span class="falta">SEM APUR.</span>—'
            return fv_(x['inss'])
        lin.append(f'<tr class="{cls}"><td>{esc(nome_mes(x["m"]))}{tag}</td><td>{fv_(x["rec"])}</td><td>{fv_(x["prov"])}</td>'
                   f'<td>{fv_(x["fgts"])}</td><td>{inss_cel(x)}</td><td><b>{fv_(x["fol"])}</b></td><td class="o">{orig}</td>'
                   f'<td class="j">{"●" if em1 else ""}</td><td class="j">{"●" if em2 else ""}</td></tr>')
    comp = (any(x['prov'] or x['fgts'] for x in L[1:])          # só soma as partes se todos os meses da janela as tiverem
            and all((x['prov'] or x['fgts']) for x in L[1:] if x['fol'] and not x['antes']))
    foot = (f'<tr style="--c:{cor1}"><td>Fator R {esc(nome_mes(c))} <span style="font-weight:400;color:#64748b">({j1})</span></td>'
            f'<td>{valN(sr1)}</td><td colspan="2"></td><td>{valN(cpp1) if cpp1 else ""}</td><td>{valN(sf1)}</td>'
            f'<td class="o r" colspan="3" style="text-align:right"><span class="r">{pctN(fr1) + " → Anexo " + an1 if fr1 is not None else "—"}</span></td></tr>'
            f'<tr style="--c:{cor2}"><td>Projeção {esc(nome_mes(prox))} <span style="font-weight:400;color:#64748b">({j2})</span></td>'
            f'<td>{valN(sr2)}</td><td>{valN(tp) if comp else ""}</td><td>{valN(tf) if comp else ""}</td><td>{valN(ti) if comp else (valN(cpp2) if cpp2 else "")}</td><td>{valN(sf2)}</td>'
            f'<td class="o" colspan="3" style="text-align:right"><span class="r">{pctN(fr2) + " → Anexo " + an2 if fr2 is not None else "—"}</span></td></tr>')
    o.append(f'<table class="t"><thead>{cab}</thead><tbody>{"".join(lin)}</tbody><tfoot>{foot}</tfoot></table>')
    o.append('<div class="leg">' + ''.join(f'<span>{_orig_html(k)}</span>' for k in ('PGDAS-D', 'Apuração salva', 'XML', 'Sócios e funcionários', 'Digitado'))
             + '<span><b style="color:#0e7490">SN</b> = CPP da apuração do Simples Nacional feita pelo Validador</span>'
             + '<span>● = mês que entra na janela</span></div>')

    # memória de cálculo
    def bx(tit, jan, sr, sf, cpp, n_cpp, fr, an, cor):
        res = f"{pctN(fr)} {'≥' if an == 'III' else '<'} {pctN(frm, 0)} → Anexo {an}" if fr is not None else 'sem folha → Anexo V'
        h = f'<div class="bx" style="--c:{cor}"><div class="h">{tit} <span style="font-weight:400;color:#64748b">· {jan}</span></div>'
        if cpp:
            h += (f'<div class="ln sub"><span><span class="op"></span>Salários, pró-labore e FGTS</span><span>{brl(r2(sf - cpp))}</span></div>'
                  f'<div class="ln sub"><span><span class="op">(+)</span>CPP da apuração do SN ({n_cpp} {"mês" if n_cpp == 1 else "meses"})</span><span>{brl(cpp)}</span></div>'
                  f'<div class="ln tot"><span><span class="op">(=)</span>Folha de salários 12 meses</span><span>{brl(sf)}</span></div>')
        else:
            h += f'<div class="ln"><span><span class="op"></span>Folha de salários 12 meses (com encargos)</span><span>{brl(sf)}</span></div>'
        h += (f'<div class="ln"><span><span class="op">(÷)</span>Receita bruta 12 meses (RBT12)</span><span>{brl(sr)}</span></div>'
              f'<div class="ln"><span><span class="op">(=)</span>Fator R</span><span>{res}</span></div></div>')
        return h
    o.append('<h2>Memória de cálculo</h2><div class="calc">' + bx(f'Fator R de {nome_mes(c)}', j1, sr1, sf1, cpp1, n_cpp1, fr1, an1, cor1)
             + bx(f'Projeção para {nome_mes(prox)}', j2, sr2, sf2, cpp2, n_cpp2, fr2, an2, cor2) + '</div>')

    # sócios e funcionários
    pj = d.get('pessoas') or []
    if pj:
        o.append(f'<h2>Sócios e funcionários <small>— {nome_mes(mes_add(c, -11))} a {nome_mes(c)}</small></h2>')
        rows = ''.join(f'<tr><td>{esc(p["nome"])}</td><td style="text-align:left">{"Sócio (pró-labore)" if p["tipo"] == "socio" else "Funcionário"}</td>'
                       f'<td>{p["meses"]}</td><td>{valN(p["prov"])}</td><td>{valN(p["fgts"])}</td><td>{valN(p["inss"])}</td><td><b>{valN(p["total"])}</b></td>'
                       f'<td>{valN(p["por_mes"][c]) if c in p["por_mes"] else "—"}</td></tr>' for p in pj)
        o.append('<table class="t"><thead><tr><th>Nome</th><th style="text-align:left">Tipo</th><th>Meses</th><th>Proventos</th><th>FGTS</th>'
                 f'<th>INSS/CPP</th><th>Total na janela</th><th>{esc(nome_mes(c))}</th></tr></thead><tbody>{rows}</tbody>'
                 f'<tfoot><tr><td colspan="3">Total</td><td>{valN(sum(p["prov"] for p in pj))}</td><td>{valN(sum(p["fgts"] for p in pj))}</td>'
                 f'<td>{valN(sum(p["inss"] for p in pj))}</td><td>{valN(sum(p["total"] for p in pj))}</td>'
                 f'<td>{valN(sum(p["por_mes"].get(c, 0) for p in pj))}</td></tr></tfoot></table>')

    notas = ['<b>Fator R</b> = folha de salários dos 12 meses anteriores (salários, pró-labore, FGTS e CPP) ÷ receita bruta dos 12 meses anteriores (RBT12). '
             f'Igual ou acima de {pctN(frm, 0)}, as atividades sujeitas ao Fator R são tributadas pelo Anexo III; abaixo, pelo Anexo V.',
             f'<b>Projeção {nome_mes(prox)}</b>: entra a folha e a receita de {nome_mes(c)} e sai {nome_mes(mes_add(c, -12))}.']
    if cpp1 or cpp2:
        notas.append('<b>INSS/CPP</b>: contribuição patronal previdenciária (CPP) de cada competência, tirada da apuração do Simples Nacional '
                     'feita pelo Validador, somada aos salários, pró-labore e FGTS do mês. Totais digitados como valor único são tratados como folha completa.')
    if primeiro:
        notas.append('1º mês de atividade: o Fator R usa a folha e a receita do próprio mês (proporcionalização do art. 18, § 2º, da LC 123/2006).')
    elif d['n_ativ'] is not None and d['n_ativ'] < 12:
        notas.append(f"Empresa com {d['n_ativ']} {'mês' if d['n_ativ'] == 1 else 'meses'} de atividade: RBT12 e folha são proporcionalizados "
                     '(média × 12); a relação entre eles não se altera.')
    if any(x['orig_fol'] == 'Digitado' or x['orig_rec'] == 'Digitado' for x in L):
        notas.append('Valores marcados como “Digitado” foram informados ou ajustados manualmente no Validador.')
    o.append('<div class="notas">' + ''.join(f'<p>{n}</p>' for n in notas) + '</div>')
    o.append(f'<div class="ass"><div>Elaborado por {esc(usuario)}</div><div>Conferido por</div></div>')
    o.append(f'<div class="rod"><span>Contrato · Contabilidade e Consultoria — Validador Tributário</span>'
             f'<span>Gerado em {datetime.now().strftime("%d/%m/%Y às %H:%M")}</span></div>')

    titulo = f'Fator R – {d["nome"]} – {nome_mes(c)}'
    html = (f'<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>{esc(titulo)}</title><style>{CSS_FR}</style></head><body>'
            '<div class="barra">Apuração do Fator R pronta. <button onclick="window.print()">Imprimir / salvar PDF</button></div>'
            f'<div class="folha">{"".join(o)}</div>'
            '<script>window.onload=()=>setTimeout(()=>window.print(),350)</script></body></html>')
    nome = ''.join(ch if ch.isalnum() or ch in ' -_' else '_' for ch in titulo)[:90] + '.html'
    arq = pasta_relatorios() / nome
    arq.write_text(html, 'utf-8')
    webbrowser.open(arq.as_uri())
    return arq
