"""Estado persistente do validador (formulários, importações, apurações, trilha)
e sincronização com a nuvem (tabela simples_dados do Supabase).

O formato das chaves e dos dados é o mesmo do painel HTML, então os dois
programas compartilham a mesma nuvem.
"""
from __future__ import annotations

import hashlib
import json
import os
import threading
from pathlib import Path

from .util import agora_iso

TAB_NUVEM = 'simples_dados'
CATS = ['forms', 'apur', 'imp', 'cancel', 'log']


def pasta_dados() -> Path:
    base = os.environ.get('APPDATA') or os.path.join(Path.home(), '.local', 'share')
    p = Path(base) / 'ValidadorTributario'
    p.mkdir(parents=True, exist_ok=True)
    return p


def cat_de(k: str) -> str:
    if k == 'cancel':
        return 'cancel'
    if k.startswith('form:'):
        return 'forms'
    return k.split(':')[0]


def juntar_log(a, b):
    vis, out = set(), []
    for x in (a or []) + (b or []):
        k = f"{x.get('em')}|{x.get('acao')}|{x.get('campo', '')}"
        if k not in vis:
            vis.add(k)
            out.append(x)
    out.sort(key=lambda x: x.get('em', ''))
    return out[-800:]


def _h(s: str) -> str:
    return hashlib.md5(s.encode('utf-8')).hexdigest()


def _dump(v) -> str:
    return json.dumps(v, ensure_ascii=False, separators=(',', ':'))


class Estado:
    """Dados do painel. Cada categoria fica num arquivo próprio em dados/; só a categoria
    alterada é regravada (e no máximo uma vez por segundo, via flush)."""

    def __init__(self):
        self.pasta = pasta_dados() / 'dados'
        self.pasta.mkdir(exist_ok=True)
        self.arquivo = pasta_dados() / 'dados.json'      # formato antigo (migrado)
        self.arq_cfg = pasta_dados() / 'config.json'
        self.forms: dict = {}
        self.imp: dict = {}
        self.cancel: set = set()
        self.apur: dict = {}
        self.log: dict = {}
        self.cfg: dict = {}
        self.lock = threading.RLock()
        self.ver = 0                 # muda a cada alteração: invalida os caches de cálculo
        self.disco_sujo: set = set()
        # nuvem
        self.sb = None
        self.nuvem_on = False
        self.sujo: set = set()
        self.hash: dict = {}
        self.ao_mudar_nuvem = None   # callback(estado_str, detalhe)
        self.carregar()

    # ---------- disco ----------
    def _arq(self, cat):
        return self.pasta / f'{cat}.json'

    def carregar(self):
        try:
            self.cfg = json.loads(self.arq_cfg.read_text('utf-8'))
        except Exception:
            self.cfg = {}
        if self.arquivo.exists() and not self._arq('forms').exists():
            try:
                d = json.loads(self.arquivo.read_text('utf-8'))
            except Exception:
                d = {}
            self._de_dict(d)
            self.disco_sujo = set(CATS) | {'hash'}
            self.gravar()
            try:
                self.arquivo.replace(self.arquivo.with_name('dados_antigo.json'))
            except Exception:
                pass
            return
        d = {}
        for c in CATS + ['hash']:
            try:
                d[c] = json.loads(self._arq(c).read_text('utf-8'))
            except Exception:
                pass
        self._de_dict(d)

    def _de_dict(self, d):
        self.ver = getattr(self, 'ver', 0) + 1
        self.forms = d.get('forms') or {}
        self.imp = d.get('imp') or {}
        self.cancel = set(d.get('cancel') or [])
        self.apur = d.get('apur') or {}
        self.log = d.get('log') or {}
        self.hash = d.get('hash') or {}

    def _valor(self, cat):
        return {'forms': self.forms, 'imp': self.imp, 'cancel': sorted(self.cancel), 'apur': self.apur, 'log': self.log, 'hash': self.hash}[cat]

    def gravar(self, cats=None):
        """Grava em disco as categorias pendentes (ou as indicadas). Pode rodar fora da thread da tela:
        o texto é montado sob trava e a escrita no disco (a parte lenta) acontece depois, sem segurar a tela."""
        with self.lock:
            alvo = set(cats) if cats else set(self.disco_sujo)
            self.disco_sujo -= alvo
            try:
                txts = {c: _dump(self._valor(c)) for c in alvo}
            except RuntimeError:             # dado mudou enquanto era lido: tenta de novo no próximo ciclo
                self.disco_sujo |= alvo
                return
        for c, txt in txts.items():
            try:
                tmp = self._arq(c).with_suffix('.tmp')
                tmp.write_text(txt, 'utf-8')
                tmp.replace(self._arq(c))
            except OSError:                  # arquivo preso (antivírus, OneDrive): grava depois
                with self.lock:
                    self.disco_sujo.add(c)

    def flush(self):
        if self.disco_sujo:
            self.gravar()

    def gravar_cfg(self):
        self.arq_cfg.write_text(json.dumps(self.cfg, ensure_ascii=False, indent=1), 'utf-8')

    def salvar(self, *cats):
        cats = cats or tuple(CATS)
        self.ver += 1
        self.disco_sujo.update(cats)
        for c in cats:
            self.marcar(c)

    # ---------- nuvem ----------
    def marcar(self, cat):
        if not self.nuvem_on:
            return
        self.sujo.add(cat)
        self._aviso('pendente')

    def _aviso(self, st, det=''):
        if self.ao_mudar_nuvem:
            try:
                self.ao_mudar_nuvem(st, det)
            except Exception:
                pass

    def linhas_de(self, cat):
        o = {}
        if cat == 'forms':
            for k, v in list(self.forms.items()):
                i = k.index('|')
                o.setdefault('form:' + k[i + 1:], {})[k[:i]] = v
        elif cat == 'apur':
            for r, v in list(self.apur.items()):
                if v:
                    o['apur:' + r] = v
        elif cat == 'imp':
            for r, v in list(self.imp.items()):
                o['imp:' + r] = v
        elif cat == 'cancel':
            if self.cancel:
                o['cancel'] = sorted(self.cancel)
        elif cat == 'log':
            for r, v in list(self.log.items()):
                if v:
                    o['log:' + r] = v
        return o

    def preparar_envio(self):
        """(Thread da interface) Monta só as linhas que mudaram desde o último envio."""
        if not self.nuvem_on or not self.sujo:
            return None
        cats = list(self.sujo)
        self.sujo.clear()
        try:
            return self._montar_envio(cats)
        except RuntimeError:                 # dado mudou durante a leitura (thread de fundo): fica para o próximo ciclo
            self.sujo.update(cats)
            return None

    def _montar_envio(self, cats):
        sobe, apaga = [], []
        agora = agora_iso()
        for cat in cats:
            rows = self.linhas_de(cat)
            for k, v in rows.items():
                txt = _dump(v)
                h = _h(txt)
                if self.hash.get(k) != h:
                    sobe.append(({'chave': k, 'txt': txt, 'atualizado_em': agora}, h, len(txt)))
            for k in list(self.hash):
                if cat_de(k) == cat and k not in rows:
                    apaga.append(k)
        return {'cats': cats, 'sobe': sobe, 'apaga': apaga}

    def enviar_preparado(self, pac):
        """(Pode rodar numa thread) Sobe o pacote montado por preparar_envio."""
        if not pac:
            return
        if not pac['sobe'] and not pac['apaga']:
            self._aviso('pendente' if self.sujo else 'ok')
            return
        self._aviso('salvando')
        sobe = pac['sobe']
        try:
            i = 0
            while i < len(sobe):
                lote, t = [], 0
                while i < len(sobe) and (not lote or t + sobe[i][2] < 1.5e6):
                    lote.append(sobe[i])
                    t += sobe[i][2]
                    i += 1
                corpo = '[' + ','.join('{"chave":%s,"dados":%s,"atualizado_em":%s}' % (json.dumps(x[0]['chave']), x[0]['txt'],
                                                                                     json.dumps(x[0]['atualizado_em'])) for x in lote) + ']'
                self.sb.upsert(TAB_NUVEM, corpo.encode('utf-8'))
                for x in lote:
                    self.hash[x[0]['chave']] = x[1]
            if pac['apaga']:
                self.sb.apagar_chaves(TAB_NUVEM, pac['apaga'])
                for k in pac['apaga']:
                    self.hash.pop(k, None)
            self.disco_sujo.add('hash')
            self._aviso('pendente' if self.sujo else 'ok')
        except Exception as e:  # noqa: BLE001
            for c in pac['cats']:
                self.sujo.add(c)
            m = str(e)
            self._aviso('semtabela' if ('does not exist' in m or 'Could not find the table' in m) else 'erro', m)
            raise

    def enviar_nuvem(self):
        """Envio completo e síncrono (usado ao fechar o programa)."""
        self.enviar_preparado(self.preparar_envio())

    def ler_nuvem(self):
        """(Thread) Baixa a tabela e já calcula o hash de cada linha, para não pesar na tela."""
        rows = self.sb.selecionar_tudo(TAB_NUVEM, 'chave,dados', ordem='chave', lote=200)
        for r in rows:
            r['_h'] = _h(_dump(r['dados']))
        return rows

    def aplicar_nuvem(self, rows, juntar):
        from .importacao import limpar_cache
        limpar_cache()
        with self.lock:
            F = dict(self.forms) if juntar else {}
            A = dict(self.apur) if juntar else {}
            I = dict(self.imp) if juntar else {}
            C = set(self.cancel) if juntar else set()
            L = dict(self.log) if juntar else {}
            self.hash = {}
            for row in rows:
                chave, dados = row['chave'], row['dados']
                self.hash[chave] = row.get('_h') or _h(_dump(dados))
                cat = cat_de(chave)
                id_ = chave[chave.index(':') + 1:] if ':' in chave else chave
                if cat == 'forms':
                    for c, v in (dados or {}).items():
                        F[c + '|' + id_] = v
                elif cat == 'apur':
                    A[id_] = {**(A.get(id_) or {} if juntar else {}), **(dados or {})}
                elif cat == 'imp':
                    if juntar and id_ in I:
                        I[id_] = {'notas': {**I[id_].get('notas', {}), **dados.get('notas', {})},
                                  'pgdas': {**I[id_].get('pgdas', {}), **dados.get('pgdas', {})},
                                  'compras': {**(I[id_].get('compras') or {}), **(dados.get('compras') or {})}}
                    else:
                        I[id_] = dados
                elif cat == 'cancel':
                    C.update(dados or [])
                elif cat == 'log':
                    L[id_] = juntar_log(L.get(id_), dados) if juntar and id_ in L else dados
            self.forms, self.apur, self.imp, self.cancel, self.log = F, A, I, C, L
            self.ver += 1
            self.disco_sujo.update(CATS + ['hash'])

    def ativar_nuvem(self, rows):
        """(Thread da interface) Aplica o que veio do banco e liga a sincronização.
        Só o que existe apenas neste computador sobe depois (comparação por hash)."""
        primeira = self.cfg.get('nuvem_user') != self.sb.user_id
        self.aplicar_nuvem(rows, primeira)
        self.nuvem_on = True
        self.cfg['nuvem_user'] = self.sb.user_id
        self.gravar_cfg()
        for c in CATS:
            self.sujo.add(c)
        return primeira

    # ---------- backup ----------
    def backup_dict(self):
        return {'versao': 1, 'geradoEm': agora_iso(), 'forms': self.forms, 'imp': self.imp,
                'cancel': sorted(self.cancel), 'apur': self.apur, 'log': self.log}

    def restaurar(self, d):
        """Junta um backup (do painel HTML ou deste programa) aos dados atuais.
        Retorna um resumo do que entrou."""
        d = normalizar_backup(d)
        with self.lock:
            self.forms.update(d.get('forms') or {})
            self.cancel.update(d.get('cancel') or [])
            for r, v in (d.get('imp') or {}).items():
                alvo = self.imp.setdefault(r, {'notas': {}, 'pgdas': {}})
                alvo.setdefault('notas', {}).update((v or {}).get('notas') or {})
                alvo.setdefault('pgdas', {}).update((v or {}).get('pgdas') or {})
                if (v or {}).get('compras'):
                    alvo.setdefault('compras', {}).update(v['compras'])
            for r, v in (d.get('apur') or {}).items():
                self.apur[r] = {**(self.apur.get(r) or {}), **(v or {})}
            for r, v in (d.get('log') or {}).items():
                self.log[r] = juntar_log(self.log.get(r), v)
        from .importacao import limpar_cache
        limpar_cache()
        self.salvar()
        self.gravar()
        return resumo_backup(d)


def normalizar_backup(d):
    """Aceita: backup do painel HTML ('Baixar backup'), backup deste programa, ou cópia do
    localStorage do navegador (chaves sn_forms, sn_import, sn_apur, sn_log)."""
    if not isinstance(d, dict):
        raise ValueError('arquivo não é um backup do Validador')
    if any(k in d for k in ('sn_forms', 'sn_import', 'sn_apur', 'sn_log')):
        def js(v):
            if isinstance(v, str):
                try:
                    return json.loads(v)
                except Exception:
                    return {}
            return v or {}
        im = js(d.get('sn_import'))
        d = {'versao': 1, 'forms': js(d.get('sn_forms')), 'imp': im.get('imp') or {}, 'cancel': im.get('cancel') or [],
             'apur': js(d.get('sn_apur')), 'log': js(d.get('sn_log'))}
    if d.get('versao') not in (1, None) or not any(k in d for k in ('forms', 'imp', 'apur', 'log')):
        raise ValueError('arquivo não é um backup do Validador (esperado o JSON do botão "Baixar backup")')
    return d


def resumo_backup(d):
    forms = d.get('forms') or {}
    empresas = {k.split('|', 1)[1] for k in forms if '|' in k and not k.endswith('|global')}
    return {'empresas': len(empresas), 'competencias': sum(1 for k in forms if '|' in k and k[:4].isdigit()),
            'apuracoes': sum(len(v or {}) for v in (d.get('apur') or {}).values()),
            'notas': sum(len((v or {}).get('notas') or {}) for v in (d.get('imp') or {}).values()),
            'pgdas': sum(len((v or {}).get('pgdas') or {}) for v in (d.get('imp') or {}).values()),
            'raizes': len(set(d.get('imp') or {}) | set(d.get('apur') or {}))}
