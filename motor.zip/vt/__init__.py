"""Validador Tributário — Contrato Contabilidade & Consultoria (versão desktop)."""
__version__ = "1.4.0"
