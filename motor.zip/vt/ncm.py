"""Classificação dos produtos pelo NCM: PIS/Cofins monofásico e ICMS-ST.

Monofásico (PIS/Cofins concentrado no fabricante/importador; revenda com alíquota zero) é definido
por lei federal a partir do NCM — por isso o NCM manda, não o CST que veio na nota.

ICMS-ST depende da UF e do produto. Sinais usados, nesta ordem:
  1. regra cadastrada pelo usuário (Configurações → Regras por NCM), opcionalmente por UF;
  2. CSOSN 500 / CST 60 na nota de venda (ICMS já retido anteriormente);
  3. compra do mesmo NCM com ICMS-ST retido/antecipado (XML de entrada importado);
  4. CEST preenchido (produto das listas do Convênio ICMS 142/2018) → só ALERTA, não muda o cálculo.

A tabela base é uma referência; ajuste e complete pelas regras do usuário.
"""
from __future__ import annotations

from .util import dig

VERSAO_BASE = 'NCM-2026.1'

L10147 = 'Lei 10.147/2000, art. 1º (farmacêuticos, perfumaria, higiene pessoal)'
L10485 = 'Lei 10.485/2002 (veículos, máquinas, autopeças — Anexos I e II, pneus e câmaras)'
L13097 = 'Lei 13.097/2015, arts. 14 e 25 (bebidas frias: água, refrigerantes, cervejas)'
L9718 = 'Lei 9.718/1998, arts. 4º a 6º; Lei 11.116/2005 (combustíveis, GLP, álcool, biodiesel)'

# prefixo do NCM → (nível, fundamento, descrição)
#   nível 'sim'       = aplica direto no cálculo
#   nível 'verificar' = NCM da lista, mas com "Ex"/destinação específica: só alerta até o usuário confirmar
MONO_BASE = {
    # farmacêuticos / perfumaria / higiene
    '3001': ('sim', L10147, 'Glândulas e órgãos para usos opoterápicos'),
    '30021': ('sim', L10147, 'Antissoros, frações do sangue, produtos imunológicos'),
    '30022': ('sim', L10147, 'Vacinas para medicina humana'),
    '30029020': ('sim', L10147, 'Culturas de microrganismos / toxinas'),
    '30029092': ('sim', L10147, 'Produtos do 30.02'),
    '30029099': ('sim', L10147, 'Produtos do 30.02'),
    '3003': ('sim', L10147, 'Medicamentos não acondicionados para venda a retalho'),
    '3004': ('sim', L10147, 'Medicamentos acondicionados para venda a retalho'),
    '30051010': ('sim', L10147, 'Curativos adesivos impregnados'),
    '300630': ('sim', L10147, 'Preparações opacificantes / reagentes de diagnóstico'),
    '300660': ('sim', L10147, 'Preparações químicas contraceptivas'),
    '3303': ('sim', L10147, 'Perfumes e águas-de-colônia'),
    '3304': ('sim', L10147, 'Maquiagem e cuidados da pele'),
    '3305': ('sim', L10147, 'Preparações capilares'),
    '3306': ('sim', L10147, 'Higiene bucal'),
    '3307': ('sim', L10147, 'Barbear, desodorantes, banho, depilatórios'),
    '34011190': ('sim', L10147, 'Sabões de toucador'),
    '34012010': ('sim', L10147, 'Sabões de toucador em outras formas'),
    '96032100': ('sim', L10147, 'Escovas de dentes'),
    # veículos e máquinas
    '8429': ('sim', L10485, 'Máquinas de terraplenagem'),
    '84324000': ('sim', L10485, 'Espalhadores de estrume / distribuidores de adubos'),
    '84328000': ('sim', L10485, 'Máquinas agrícolas'),
    '843320': ('sim', L10485, 'Ceifeiras'),
    '84333000': ('sim', L10485, 'Máquinas de colheita'),
    '84334000': ('sim', L10485, 'Enfardadeiras'),
    '84335': ('sim', L10485, 'Colheitadeiras'),
    '8701': ('sim', L10485, 'Tratores'),
    '8702': ('sim', L10485, 'Veículos para transporte de 10 pessoas ou mais'),
    '8703': ('sim', L10485, 'Automóveis'),
    '8704': ('sim', L10485, 'Veículos para transporte de mercadorias'),
    '8705': ('sim', L10485, 'Veículos para usos especiais'),
    '8706': ('sim', L10485, 'Chassis com motor'),
    '8711': ('sim', L10485, 'Motocicletas'),
    # pneus e câmaras
    '4011': ('sim', L10485, 'Pneus novos de borracha'),
    '4013': ('sim', L10485, 'Câmaras de ar de borracha'),
    # autopeças — partes exclusivas de veículos
    '8707': ('sim', L10485, 'Carroçarias para veículos'),
    '8708': ('sim', L10485, 'Partes e acessórios de veículos'),
    # autopeças — NCM também usado fora do setor (Anexo I com "Ex"/destinação): confirmar
    '40169990': ('verificar', L10485, 'Artefatos de borracha (autopeças, Anexo I)'),
    '68132': ('verificar', L10485, 'Guarnições de fricção (autopeças, Anexo I)'),
    '70071100': ('verificar', L10485, 'Vidros temperados para veículos'),
    '70072100': ('verificar', L10485, 'Vidros laminados para veículos'),
    '70091000': ('verificar', L10485, 'Espelhos retrovisores'),
    '73201000': ('verificar', L10485, 'Molas de folhas'),
    '83012000': ('verificar', L10485, 'Fechaduras para veículos'),
    '84073390': ('verificar', L10485, 'Motores de pistão (veículos)'),
    '84073490': ('verificar', L10485, 'Motores de pistão (veículos)'),
    '84082090': ('verificar', L10485, 'Motores diesel (veículos)'),
    '840991': ('verificar', L10485, 'Partes de motores de explosão'),
    '840999': ('verificar', L10485, 'Partes de motores diesel'),
    '841330': ('verificar', L10485, 'Bombas de combustível/óleo para motores'),
    '84212300': ('verificar', L10485, 'Filtros de óleo para motores'),
    '84213100': ('verificar', L10485, 'Filtros de entrada de ar para motores'),
    '8483': ('verificar', L10485, 'Árvores de transmissão, mancais, engrenagens'),
    '85052090': ('verificar', L10485, 'Embreagens e freios eletromagnéticos'),
    '85071000': ('verificar', L10485, 'Baterias de chumbo para arranque'),
    '8511': ('verificar', L10485, 'Ignição e arranque de motores'),
    '85122': ('verificar', L10485, 'Iluminação/sinalização para veículos'),
    '85123000': ('verificar', L10485, 'Sinalização acústica para veículos'),
    '85124': ('verificar', L10485, 'Limpadores de para-brisa'),
    '852721': ('verificar', L10485, 'Rádios para veículos'),
    '85443000': ('verificar', L10485, 'Jogos de fios para velas/veículos'),
    '9029': ('verificar', L10485, 'Contadores, velocímetros, tacômetros'),
    '94012000': ('verificar', L10485, 'Assentos para veículos'),
    # bebidas frias
    '2201': ('sim', L13097, 'Águas minerais e gaseificadas'),
    '2202': ('sim', L13097, 'Refrigerantes e outras bebidas não alcoólicas'),
    '2203': ('sim', L13097, 'Cervejas de malte'),
    '21069010': ('verificar', L13097, 'Preparações para elaboração de bebidas (Ex 02)'),
    # combustíveis
    '271012': ('verificar', L9718, 'Gasolinas e naftas'),
    '27101921': ('sim', L9718, 'Óleo diesel'),
    '27101911': ('sim', L9718, 'Querosene de aviação'),
    '27111910': ('sim', L9718, 'Gás liquefeito de petróleo (GLP)'),
    '220710': ('sim', L9718, 'Álcool etílico não desnaturado'),
    '220720': ('sim', L9718, 'Álcool etílico desnaturado'),
    '38260000': ('sim', L9718, 'Biodiesel'),
}
MONO_EXCECOES = {'30039056', '30049046'}     # fora do monofásico apesar do capítulo

ST_XML_CSOSN = {'500'}
ST_XML_CST = {'60'}
MONO_PIS_CST = {'04', '05'}


def ncm_limpo(n) -> str:
    return dig(n)[:8]


def cest_valido(c) -> str:
    c = dig(c)
    return c if len(c) == 7 and c != '0000000' else ''


def mono_base(ncm: str):
    """(nível, fundamento, descrição, prefixo) do prefixo mais longo que casa, ou None."""
    ncm = ncm_limpo(ncm)
    if not ncm or ncm in MONO_EXCECOES:
        return None
    for tam in range(8, 1, -1):
        x = MONO_BASE.get(ncm[:tam])
        if x:
            return (*x, ncm[:tam])
    return None


def regra_usuario(regras, ncm: str, uf: str = ''):
    """Regra do usuário de prefixo mais longo (a de UF específica vence a geral)."""
    ncm = ncm_limpo(ncm)
    melhor, chave = None, (-1, -1)
    for r in regras or []:
        p = ncm_limpo(r.get('ncm'))
        ruf = (r.get('uf') or '').upper().strip()
        if not p or not ncm.startswith(p) or (ruf and ruf != (uf or '').upper()):
            continue
        k = (len(p), 1 if ruf else 0)
        if k > chave:
            melhor, chave = r, k
    return melhor


def classificar(it: dict, uf: str = '', regras=None, compras: dict | None = None) -> dict:
    """it: {'ncm','cest','cst','pis'} → mono/st finais com a fonte de cada decisão e alertas."""
    ncm = ncm_limpo(it.get('ncm'))
    cst = str(it.get('cst') or '')
    mono_xml = str(it.get('pis') or '') in MONO_PIS_CST
    st_xml = cst in ST_XML_CSOSN or cst in ST_XML_CST
    r = regra_usuario(regras, ncm, uf)
    base = mono_base(ncm)
    alerta = []
    # ---- monofásico
    if r and r.get('mono') in ('S', 'N'):
        mono, f_mono = r['mono'] == 'S', 'regra do usuário'
    elif base and base[0] == 'sim':
        mono, f_mono = True, f'NCM {base[3]} — {base[1]}'
    elif base and base[0] == 'verificar':
        mono, f_mono = mono_xml, 'XML (NCM da lista a confirmar)'
        if not mono_xml:
            alerta.append('mono_verificar')
    elif ncm:
        mono, f_mono = False, 'NCM fora da lista do monofásico'
    else:
        mono, f_mono = mono_xml, 'XML (sem NCM)'
    decidido_pelo_ncm = bool(r and r.get('mono') in ('S', 'N')) or (ncm and not (base and base[0] == 'verificar'))
    if decidido_pelo_ncm and mono != mono_xml:
        alerta.append('mono_ncm' if mono else 'mono_xml')
    # ---- ICMS-ST
    comp = (compras or {}).get(ncm) if ncm else None
    if r and r.get('st') in ('S', 'N'):
        st, f_st = r['st'] == 'S', 'regra do usuário'
    elif st_xml:
        st, f_st = True, f'XML (CSOSN/CST {cst})'
    elif comp and comp.get('st'):
        st, f_st = True, f"compra com ICMS-ST (NF {comp.get('n', '')} de {comp.get('d', '')[:10]})"
        alerta.append('st_compra')
    else:
        st, f_st = False, 'XML'
        if cest_valido(it.get('cest')):
            alerta.append('cest_sem_st')
    return {'mono': mono, 'f_mono': f_mono, 'mono_xml': mono_xml, 'st': st, 'f_st': f_st, 'st_xml': st_xml,
            'base': base, 'regra': r, 'alertas': alerta}


def grupo(tipo: str, st: bool, mono: bool) -> str:
    if tipo != 'merc':
        return tipo
    return 'merc' + ('_st' if st else '') + ('_mono' if mono else '')


def checks(alertas: dict, ncm: dict, add, ef_mono: float, ef_st: float, lp: bool = False):
    """Validações da classificação por NCM (usadas no Simples e no Presumido)."""
    from .util import r2, brl

    def ncms(al):
        L = [a['ncm'] for a in (ncm or {}).values() if al in (a.get('alertas') or [])]
        return ', '.join(L[:6]) + ('…' if len(L) > 6 else '')
    tem = False
    v = alertas.get('mono_ncm')
    if v:
        tem = True
        add(id='NCM-MONO', cat='Produtos (NCM)', titulo='Produtos monofásicos pelo NCM vendidos como tributados no XML', sev='atencao',
            rotEnc='Receita reclassificada', encontrado=v, impacto=r2(abs(v) * ef_mono), resumo=f'NCM {ncms("mono_ncm")}',
            origem='Tabela de NCM do monofásico (Leis 10.147/2000, 10.485/2002, 13.097/2015, 9.718/1998)',
            causa=('O NCM está na lista do PIS/Cofins monofásico, mas a nota saiu com CST de PIS/Cofins tributado. O cálculo já segrega como '
                   'monofásico (PIS/Cofins zero na revenda). Corrija o cadastro do produto no emissor e confira a declaração.'), acao=['Ver por NCM', '1'])
    v = alertas.get('mono_xml')
    if v:
        tem = True
        add(id='NCM-MONO-XML', cat='Produtos (NCM)', titulo='CST monofásico no XML com NCM fora da lista', sev='atencao',
            rotEnc='Receita tratada como tributada', encontrado=v, impacto=r2(abs(v) * ef_mono), resumo=f'NCM {ncms("mono_xml")}',
            causa=('A nota informa PIS/Cofins monofásico (CST 04/05), mas o NCM não está na lista legal: o cálculo trata como tributado. '
                   'Se o produto for mesmo monofásico (ex.: código com "Ex"), cadastre a regra do NCM em Configurações → Regras por NCM.'),
            acao=['Ver por NCM', '1'])
    v = alertas.get('mono_verificar')
    if v:
        tem = True
        add(id='NCM-MONO-VER', cat='Produtos (NCM)', titulo='NCM da lista do monofásico que depende de destinação/"Ex"', sev='atencao',
            rotEnc='Receita a confirmar', encontrado=v, resumo=f'NCM {ncms("mono_verificar")}',
            causa=('Esse NCM aparece na lista de autopeças/combustíveis, mas só é monofásico em certos usos (ex.: peça para veículo). '
                   'Mantido como no XML. Confirme e, se for o caso, cadastre a regra do NCM em Configurações.'), acao=['Ver por NCM', '1'])
    if not lp:
        v = alertas.get('st_compra')
        if v:
            tem = True
            add(id='NCM-ST-COMPRA', cat='Produtos (NCM)', titulo='Vendido como tributado, mas comprado com ICMS-ST', sev='atencao',
                rotEnc='Receita segregada como ST', encontrado=v, impacto=r2(abs(v) * ef_st), resumo=f'NCM {ncms("st_compra")}',
                causa=('Há XML de compra desses NCM com ICMS retido/substituição. O cálculo segrega a receita como ICMS-ST. '
                       'Corrija o CSOSN no emissor (500) e confira a declaração.'), acao=['Ver por NCM', '1'])
        v = alertas.get('cest_sem_st')
        if v:
            tem = True
            add(id='NCM-CEST', cat='Produtos (NCM)', titulo='Produtos com CEST vendidos com ICMS tributado', sev='atencao',
                rotEnc='Receita a confirmar', encontrado=v, impacto=r2(abs(v) * ef_st), resumo=f'NCM {ncms("cest_sem_st")}',
                causa=('O CEST indica produto das listas de ICMS-ST/antecipação (Convênio ICMS 142/2018). Não veio CSOSN 500 nem compra com ST. '
                       'Se o ICMS foi retido na compra ou antecipado, cadastre o NCM como ST em Configurações → Regras por NCM; '
                       'se a UF não exige ST para esse produto, cadastre como "não ST" para encerrar o alerta.'), acao=['Ver por NCM', '1'])
    if not tem and ncm:
        add(id='NCM-OK', cat='Produtos (NCM)', titulo='Classificação dos produtos pelo NCM', sev='ok',
            resumo=f'{len(ncm)} NCM conferido(s) · tabela {VERSAO_BASE}')
